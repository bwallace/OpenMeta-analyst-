### Name: heatmap.2
### Title: Enhanced Heat Map
### Aliases: heatmap.2
### Keywords: hplot

### ** Examples

 library(gplots)
 data(mtcars)
 x  <- as.matrix(mtcars)
 rc <- rainbow(nrow(x), start=0, end=.3)
 cc <- rainbow(ncol(x), start=0, end=.3)

 ##
 ## demonstrate the effect of row and column dendogram options
 ##
 heatmap.2(x)  ## default - dendrogram plotted and reordering done. 
 heatmap.2(x, dendrogram="none") ##  no dendrogram plotted, but reordering done.
 heatmap.2(x, dendrogram="row") ## row dendrogram plotted and row reordering done.
 heatmap.2(x, dendrogram="col") ## col dendrogram plotted and col reordering done.

 heatmap.2(x, keysize=2)  ## default - dendrogram plotted and reordering done.

 heatmap.2(x, Rowv=FALSE, dendrogram="both") ## generate warning!
 heatmap.2(x, Rowv=NULL, dendrogram="both")  ## generate warning!
 heatmap.2(x, Colv=FALSE, dendrogram="both") ## generate warning!

 ## 
 ## Show effect of z-score scaling within columns, blue-red color scale
 ##
 hv <- heatmap.2(x, col=bluered, scale="column", tracecol="#303030")

 ###
 ## Look at the return values
 ###
 names(hv)

 ## Show the mapping of z-score values to color bins
 hv$colorTable

 ## Extract the range associated with white
 hv$colorTable[hv$colorTable[,"color"]=="#FFFFFF",]

 ## Determine the original data values that map to white
 whiteBin <- unlist(hv$colorTable[hv$colorTable[,"color"]=="#FFFFFF",1:2])
 rbind(whiteBin[1] * hv$colSDs + hv$colMeans,
       whiteBin[2] * hv$colSDs + hv$colMeans )
 ##
 ## A more decorative heatmap, with z-score scaling along columns
 ##
 hv <- heatmap.2(x, col=cm.colors(255), scale="column", 
               RowSideColors=rc, ColSideColors=cc, margin=c(5, 10), 
               xlab="specification variables", ylab= "Car Models", 
               main="heatmap(<Mtcars data>, ..., scale=\"column\")", 
               tracecol="green", density="density")
 ## Note that the breakpoints are now symmetric about 0

 



 data(attitude)
 round(Ca <- cor(attitude), 2)
 symnum(Ca) # simple graphic

 # with reorder
 heatmap.2(Ca,           symm=TRUE, margin=c(6, 6), trace="none" )

 # without reorder
 heatmap.2(Ca, Rowv=FALSE, symm=TRUE, margin=c(6, 6), trace="none" )

 ## Place the color key below the image plot
 heatmap.2(x, lmat=rbind( c(0, 3), c(2,1), c(0,4) ), lhei=c(1.5, 4, 2 ) )

 ## Place the color key to the top right of the image plot
 heatmap.2(x, lmat=rbind( c(0, 3, 4), c(2,1,0 ) ), lwid=c(1.5, 4, 2 ) )

 ## For variable clustering, rather use distance based on cor():
 data(USJudgeRatings)
 symnum( cU <- cor(USJudgeRatings) )

 hU <- heatmap.2(cU, Rowv=FALSE, symm=TRUE, col=topo.colors(16), 
              distfun=function(c) as.dist(1 - c), trace="none")

 ## The Correlation matrix with same reordering:
 hM <- format(round(cU, 2))
 hM

 # now with the correlation matrix on the plot itself

 heatmap.2(cU, Rowv=FALSE, symm=TRUE, col=rev(heat.colors(16)), 
             distfun=function(c) as.dist(1 - c), trace="none", 
             cellnote=hM)

 ## genechip data examples
 ## Not run: 
##D  library(affy)
##D  data(SpikeIn)
##D  pms <- SpikeIn@pm
##D 
##D  # just the data, scaled across rows
##D  heatmap.2(pms, col=rev(heat.colors(16)), main="SpikeIn@pm", 
##D               xlab="Relative Concentration", ylab="Probeset", 
##D               scale="row")
##D 
##D  # fold change vs "12.50" sample
##D  data <- pms / pms[, "12.50"]
##D  data <- ifelse(data>1, data, -1/data)
##D  heatmap.2(data, breaks=16, col=redgreen, tracecol="blue", 
##D                main="SpikeIn@pm Fold Changes\nrelative to 12.50 sample", 
##D                xlab="Relative Concentration", ylab="Probeset")
##D  
## End(Not run)




