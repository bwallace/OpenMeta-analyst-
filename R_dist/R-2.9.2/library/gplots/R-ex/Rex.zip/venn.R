### Name: venn
### Title: Plot a Venn diagram
### Aliases: venn
### Keywords: hplot

### ** Examples


##
## Example using a list of item indexes  belonging to the
## specified group.
##
A<- 1:20
B<- 1:20
C<- 2:20
D<- 3:21
input<-list(A,B,C,D)
input

venn(input)

##
## Example using a data frame of indicator columns
##
A<- as.logical(rbinom(100, 1, 0.2))
B<- as.logical(rbinom(100, 1, 0.7))
C<- as.logical(rbinom(100, 1, 0.2))
D<- as.logical(rbinom(100, 1, 0.1))
input<-data.frame(A,B,C,D)
venn(input)

## Omit un-observed groupings
tmp <- venn(input, simplify=TRUE)

## show details
tmp

## Show internal binary group labels
venn(input, showSetLogicLabel=TRUE)

## Specify universe
venn(input, universe=NULL, showSetLogicLabel=TRUE)



