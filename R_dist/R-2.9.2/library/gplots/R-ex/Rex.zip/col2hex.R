### Name: col2hex
### Title: Convert color names to hex RGB strings
### Aliases: col2hex
### Keywords: color

### ** Examples

col2hex(c("red","yellow","lightgrey"))



