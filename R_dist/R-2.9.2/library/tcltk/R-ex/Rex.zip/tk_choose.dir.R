### Name: tk_choose.dir
### Title: Choose a Folder Interactively
### Aliases: tk_choose.dir
### Keywords: file

### ** Examples
## Not run: 
##D tk_choose.dir(getwd(), "Choose a suitable folder")
## End(Not run)


