### Name: tk_choose.files
### Title: Choose a List of Files Interactively
### Aliases: tk_choose.files
### Keywords: file

### ** Examples

Filters <- matrix(c("R code", ".R", "R code", ".s",
                    "Text", ".txt", "All files", "*"),
                  4, 2, byrow = TRUE)
Filters
if(interactive()) tk_choose.files(filter = Filters)



