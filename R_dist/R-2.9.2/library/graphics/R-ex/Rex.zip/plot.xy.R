### Name: plot.xy
### Title: Basic Internal Plot Function
### Aliases: plot.xy
### Keywords: aplot

### ** Examples

points.default # to see how it calls "plot.xy(xy.coords(x, y), ...)"



