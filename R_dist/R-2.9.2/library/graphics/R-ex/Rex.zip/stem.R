### Name: stem
### Title: Stem-and-Leaf Plots
### Aliases: stem
### Keywords: univar distribution

### ** Examples

stem(islands)
stem(log10(islands))



