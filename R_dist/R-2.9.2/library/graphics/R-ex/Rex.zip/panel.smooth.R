### Name: panel.smooth
### Title: Simple Panel Plot
### Aliases: panel.smooth
### Keywords: hplot dplot

### ** Examples

pairs(swiss, panel = panel.smooth, pch = ".")# emphasize the smooths
pairs(swiss, panel = panel.smooth, lwd = 2, cex= 1.5, col="blue")# hmm...



