### Name: unit.pmin
### Title: Parallel Unit Minima and Maxima
### Aliases: unit.pmin unit.pmax
### Keywords: dplot

### ** Examples

max(unit(1:3, "cm"), unit(0.5, "npc"))
unit.pmax(unit(1:3, "cm"), unit(0.5, "npc"))



