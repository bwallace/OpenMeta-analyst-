### Name: gPath
### Title: Concatenate Grob Names
### Aliases: gPath
### Keywords: dplot

### ** Examples

gPath("g1", "g2")



