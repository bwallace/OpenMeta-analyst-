### Name: bupa
### Title: The Bupa dataset
### Aliases: bupa
### Keywords: datasets

### ** Examples

#---Sequential forward feature selection using the lda classifier---
data(bupa)
sfs(bupa,"lda",repet=10)



