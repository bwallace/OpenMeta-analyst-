### Name: relief
### Title: RELIEF Feature Selection
### Aliases: relief
### Keywords: methods

### ** Examples

##---- Feature Selection ---
data(my.iris)
relief(my.iris,150,0.01)



