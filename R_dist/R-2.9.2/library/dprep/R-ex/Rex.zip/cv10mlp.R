### Name: cv10mlp
### Title: 10-fold cross validation error estimation for the multilayer
###   perceptron classifier
### Aliases: cv10mlp
### Keywords: classif

### ** Examples

#-----cross validation using the MLP classifier---
data(heartc)
cv10mlp(heartc,25,decay=0.1,maxwts=1000,maxit=100,repet=2)



