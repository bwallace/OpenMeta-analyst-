### Name: disc.1r
### Title: Discretization using the Holte's 1R method
### Aliases: disc.1r
### Keywords: manip

### ** Examples

#-----Discretization using the Holte's 1r method
data(bupa)
disc.1r(bupa,1:6)


