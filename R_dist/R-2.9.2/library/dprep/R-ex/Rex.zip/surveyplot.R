### Name: surveyplot
### Title: Surveyplot
### Aliases: surveyplot
### Keywords: hplot

### ** Examples

#----Surveyplot examples
data(bupa)
surveyplot(bupa,"Bupa Dataset")
surveyplot(bupa,"Bupa Dataset",orderon=1,obs=c(6,74,121))



