### Name: znorm
### Title: Z-score normalization
### Aliases: znorm
### Keywords: manip

### ** Examples

##---- Z-norm normalization ----
data(diabetes)
diab.znorm=znorm(diabetes)
op=par(mfrow=c(2,1))
plot(diabetes[,1])
plot(diab.znorm[,1])
par(op)



