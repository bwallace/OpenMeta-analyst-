### Name: vvalen
### Title: The Van Valen test for equal covariance matrices
### Aliases: vvalen
### Keywords: misc

### ** Examples

#---------Testing homocedasticity-----
data(colon)
vvalen(colon)



