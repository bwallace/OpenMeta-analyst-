### Name: my.iris
### Title: The Iris dataset
### Aliases: my.iris
### Keywords: datasets

### ** Examples

#----Testing multivariate normality----
data(my.iris)
mardia(my.iris)



