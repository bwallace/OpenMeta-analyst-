### Name: moda
### Title: Calculating the Mode
### Aliases: moda
### Keywords: univar

### ** Examples

#---- Calculating the mode ----
x=c(1,4,2,3,4,6,3,7,8,5,4,3)
moda(x)



