### Name: mahaout
### Title: Multivariate outlier detection through the boxplot of the
###   Mahalanobis distance
### Aliases: mahaout
### Keywords: methods

### ** Examples

#---- Detecting outliers using the Mahalanobis distance----
data(bupa)
mahaout(bupa,1)



