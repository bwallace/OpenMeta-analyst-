### Name: disc.ew
### Title: Discretization using the equal width method
### Aliases: disc.ew
### Keywords: manip

### ** Examples

#----Discretization using the equal frequency method
data(bupa)
bupa.disc.ew=disc.ew(bupa,1:6)



