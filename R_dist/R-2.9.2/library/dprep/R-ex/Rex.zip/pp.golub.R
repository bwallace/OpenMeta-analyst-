### Name: pp.golub
### Title: The preprocessed Golub's dataset
### Aliases: pp.golub
### Keywords: datasets

### ** Examples

#----z-score Normalization---
data(pp.golub)
rangenorm(pp.golub,"znorm")



