### Name: maxlof
### Title: Detection of multivariate outliers using the LOF algorithm
### Aliases: maxlof
### Keywords: methods

### ** Examples

#Detecting top 10 outliers in class number 1 of Breastw using the LOF algorithm
data(breastw)
breastw1.lof=maxlof(breastw[breastw[,10]==1,],name="Breast-Wisconsin",30,40)
breastw1.lof[order(breastw1.lof,decreasing=TRUE)][1:10]



