### Name: inconsist
### Title: Computing the inconsistency measure
### Aliases: inconsist
### Keywords: misc

### ** Examples

##---- Calculating Inconsistency ----
data(bupa)
bupa.discew=disc.ew(bupa,1:6)
inconsist(bupa.discew)



