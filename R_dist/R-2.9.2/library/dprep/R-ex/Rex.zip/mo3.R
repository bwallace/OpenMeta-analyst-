### Name: mo3
### Title: The third moment of a multivariate distribution
### Aliases: mo3
### Keywords: multivariate

### ** Examples

data(my.iris)
mo3(my.iris)



