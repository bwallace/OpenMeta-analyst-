### Name: softmaxnorm
### Title: Softmax Normalization
### Aliases: softmaxnorm
### Keywords: manip

### ** Examples

#---- Softmax Normalization----
data(sonar)
sonar.sftnorm=softmaxnorm(sonar)
op=par(mfrow=c(2,1))
plot(sonar[,1])
plot(sonar.sftnorm[,1])
par(op)



