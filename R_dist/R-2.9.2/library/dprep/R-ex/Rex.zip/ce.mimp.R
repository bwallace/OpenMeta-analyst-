### Name: ce.mimp
### Title: Mean or median imputation
### Aliases: ce.mimp
### Keywords: manip

### ** Examples

data(hepatitis)
#--------Mean Imputation---------- 
hepa.mean.imp=ce.impute(hepatitis,"mean",1:19)



