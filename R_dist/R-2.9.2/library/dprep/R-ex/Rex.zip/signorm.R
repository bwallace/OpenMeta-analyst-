### Name: signorm
### Title: Sigmoidal Normalization
### Aliases: signorm
### Keywords: manip

### ** Examples

#---- Sigmoidal Normalization ---
data(vehicle)
vehicle.signorm=signorm(vehicle)
op=par(mfrow=c(2,1))
plot(vehicle[,1])
plot(vehicle.signorm[,1])
par(op)



