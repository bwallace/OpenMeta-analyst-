### Name: ce.impute
### Title: Imputation in supervised classification
### Aliases: ce.impute
### Keywords: manip

### ** Examples

data(hepatitis)
#--------Median Imputation-----------
#ce.impute(hepatitis,"median",1:19)
#--------knn Imputation--------------
hepa.imputed=ce.impute(hepatitis,"knn",k1=10)



