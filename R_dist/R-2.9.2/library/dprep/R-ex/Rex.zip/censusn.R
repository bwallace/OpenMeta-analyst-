### Name: censusn
### Title: The census dataset
### Aliases: censusn
### Keywords: datasets

### ** Examples

data(censusn)
#----knn imputation------
data(censusn)
imagmiss(censusn, "censusn")



