### Name: vehicle
### Title: The Vehicle dataset
### Aliases: vehicle
### Keywords: datasets

### ** Examples

#----feature selection using sequential floating selection with LDA----
data(vehicle)
mahaout(vehicle,nclass=3)



