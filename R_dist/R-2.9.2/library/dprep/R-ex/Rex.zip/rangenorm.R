### Name: rangenorm
### Title: range normalization
### Aliases: rangenorm
### Keywords: manip

### ** Examples

#----Several methods of range normalization ----
data(bupa)
bupa.znorm=rangenorm(bupa,method="znorm")
bupa.mmnorm=rangenorm(bupa,method="mmnorm")
bupa.decs=rangenorm(bupa,method="decscale")
bupa.signorm=rangenorm(bupa,method="signorm")
bupa.soft=rangenorm(bupa,method="softmaxnorm")
#----Plotting to see the effect of the normalization----
op=par(mfrow=c(2,3))
plot(bupa[,1])
plot(bupa.znorm[,1])
plot(bupa.mmnorm[,1])
plot(bupa.decs[,1])
plot(bupa.signorm[,1])
plot(bupa.soft[,1])
par(op)



