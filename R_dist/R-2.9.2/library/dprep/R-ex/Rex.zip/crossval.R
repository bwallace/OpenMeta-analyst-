### Name: crossval
### Title: Cross validation estimation of the misclassification error
### Aliases: crossval
### Keywords: classif

### ** Examples

#------10-fold crossvalidation error using the LDA classifier---
data(bupa)
crossval(bupa,method="lda",repet=10)
#------5-fold crossvalidation error using the knn classifier---
data(colon)
crossval(colon,nparts=5,method="knn",kvec=3,repet=5)



