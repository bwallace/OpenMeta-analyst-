### Name: breastw
### Title: The Breast Wisconsin dataset
### Aliases: breastw
### Keywords: datasets

### ** Examples

#Detecting outliers in class-1 using the LOF algorithms---
data(breastw)
maxlof(breastw[breastw[,10]==1,],name="",30,40)



