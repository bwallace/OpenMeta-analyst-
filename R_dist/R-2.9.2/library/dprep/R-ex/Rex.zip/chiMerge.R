### Name: chiMerge
### Title: Discretization using the Chi-Merge method
### Aliases: chiMerge
### Keywords: manip

### ** Examples

#-----Discretization using the ChiMerge method
data(my.iris)
iris.disc=chiMerge(my.iris,1:4,alpha=0.05)
#-----Applying chiMerge a dataset containing negative values 
#data(ionosphere)
#normionos=rangenorm(ionosphere,"mmnorm")
#ionos.disc=chiMerge(normionos,1:32)



