### Name: robout
### Title: Outlier Detection with Robust Mahalonobis distance
### Aliases: robout
### Keywords: methods

### ** Examples

#---- Outlier Detection in bupa-class 1 using MCD
data(bupa)
robout(bupa,1,"mcd")



