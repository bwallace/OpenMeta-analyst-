### Name: outbox
### Title: Detecting outliers through boxplots of the features.
### Aliases: outbox
### Keywords: methods

### ** Examples

#---- Identifying outliers in diabetes-class1 with boxplots----
data(diabetes)
outbox(diabetes,nclass=1)



