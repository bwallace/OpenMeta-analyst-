### Name: lofactor
### Title: Local Outlier Factor
### Aliases: lofactor
### Keywords: methods

### ** Examples

#---- Detecting the top 10 outliers using the LOF algorithm----
data(my.iris)
iris.lof=lofactor(my.iris,10)



