### Name: decscale
### Title: Decimal Scaling
### Aliases: decscale
### Keywords: manip

### ** Examples

data(sonar)
def=par(mfrow=c(2,1))
plot(sonar[,2])
dssonar=decscale(sonar)
plot(dssonar[,2])
par(def)



