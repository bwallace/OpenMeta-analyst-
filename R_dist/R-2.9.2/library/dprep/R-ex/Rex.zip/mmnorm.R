### Name: mmnorm
### Title: Min-max normalization
### Aliases: mmnorm
### Keywords: manip

### ** Examples

#---- Min-Max Normalization----
data(ionosphere)
ionos.minmax=mmnorm(ionosphere)
op=par(mfrow=c(2,1))
plot(ionosphere[,1])
plot(ionos.minmax[,1])
par(op)



