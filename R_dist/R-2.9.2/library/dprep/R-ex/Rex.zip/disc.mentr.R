### Name: disc.mentr
### Title: Discretization using the minimum entropy criterion
### Aliases: disc.mentr
### Keywords: manip

### ** Examples

data(my.iris)
iris.discme=disc.mentr(my.iris,1:5)



