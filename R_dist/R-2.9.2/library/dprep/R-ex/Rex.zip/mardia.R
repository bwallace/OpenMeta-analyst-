### Name: mardia
### Title: The Mardia's test of normality
### Aliases: mardia
### Keywords: multivariate

### ** Examples

#-----Mardia test for supervised data-----
data(my.iris)
mardia(my.iris)
#----Mardia test for unsupervised data-----
data(hawkins)
haw=cbind(hawkins[,-4],rep(1,75))
mardia(haw)



