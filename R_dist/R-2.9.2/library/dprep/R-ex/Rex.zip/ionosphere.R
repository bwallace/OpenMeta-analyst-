### Name: ionosphere
### Title: The Ionosphere dataset
### Aliases: ionosphere
### Keywords: datasets

### ** Examples

#---Outlier detection in  ionosphere class-1 using the Mahalanobis distiance----
data(ionosphere)
mahaout(ionosphere,1)



