### Name: colon
### Title: Alon et al.'s colon dataset
### Aliases: colon
### Keywords: datasets

### ** Examples

#Detecting the top 5 outliers in class-2 using the LOF algorithm
data(colon)
colon2.lof=maxlof(colon[colon[,2001]==2,],"colon-class2")
colon2.lof[order(colon2.lof,decreasing=TRUE)][1:5]



