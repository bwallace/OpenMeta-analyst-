### Name: parallelplot
### Title: Parallel Coordinate Plot
### Aliases: parallelplot
### Keywords: hplot

### ** Examples

#---Parallel Coordinate Plot----
data(bupa)
parallelplot(bupa,"Bupa Dataset")
parallelplot(bupa,"Bupa Dataset",comb=0)
#parallelplot(bupa,"Bupa Dataset",comb=1,c(1,22,50))



