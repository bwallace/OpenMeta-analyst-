### Name: eje1dis
### Title: Basic example for discriminant analysis
### Aliases: eje1dis
### Keywords: datasets

### ** Examples

#---- Performing 10-fold cross validation using the LDA classifier-----
data(eje1dis)
crossval(eje1dis,10,"lda",repet=5)



