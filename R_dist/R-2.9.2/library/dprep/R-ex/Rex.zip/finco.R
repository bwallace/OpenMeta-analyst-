### Name: finco
### Title: FINCO Feature Selection Algorithm
### Aliases: finco
### Keywords: methods

### ** Examples

#---- Feature Selection with FINCO
data(my.iris)
iris.discew=disc.ew(my.iris,1:6)
inconsist(iris.discew)
finco(iris.discew,0.05)



