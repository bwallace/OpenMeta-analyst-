### Name: ec.knnimp
### Title: KNN Imputation
### Aliases: ec.knnimp
### Keywords: manip

### ** Examples

#---- Performing knn imputation----
data(hepatitis)
hepa.knnimp=ec.knnimp(hepatitis,k=10)



