### Name: distancia
### Title: Vector-Vector Euclidiean Distance Function
### Aliases: distancia
### Keywords: math

### ** Examples

#---- Calculating distances
x=rnorm(4)
y=matrix(rnorm(12),4,3)
distancia(x,y[,1])
distancia(x,y)



