### Name: srbct
### Title: Khan et al.'s small round blood cells dataset
### Aliases: srbct
### Keywords: datasets

### ** Examples

#---z-score Normalization
data(srbct)
srbct.rnorm=rangenorm(srbct,"znorm")
#---feature selection using the RELIEF feature selection algorithm-----
#relief(srbct,63,0.12)



