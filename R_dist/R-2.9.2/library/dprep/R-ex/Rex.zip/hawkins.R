### Name: hawkins
### Title: The Hawkins-Bradu-Kass dataset
### Aliases: hawkins
### Keywords: datasets

### ** Examples

#---- Finding outliers using the LOF algorithm----
data(hawkins)
haw.lof=maxlof(hawkins[,1:3],"Hawkins")
haw.lof[order(haw.lof,decreasing=TRUE)]



