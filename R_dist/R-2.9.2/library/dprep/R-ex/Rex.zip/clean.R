### Name: clean
### Title: Dataset Cleaning
### Aliases: clean
### Keywords: manip

### ** Examples

#-----Dataset cleaning-----
data(hepatitis)
hepa.cl=clean(hepatitis,0.5,0.3,name="hepatitis-clean")



