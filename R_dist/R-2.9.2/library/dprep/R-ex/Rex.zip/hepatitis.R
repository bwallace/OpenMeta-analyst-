### Name: hepatitis
### Title: The hepatitis dataset
### Aliases: hepatitis
### Keywords: datasets

### ** Examples

#------Report and plot of missing values ------
data(hepatitis)
imagmiss(hepatitis,"Hepatitis")



