### Name: lvf
### Title: Las Vegas Filter
### Aliases: lvf
### Keywords: methods

### ** Examples

#---- LVF method ----
data(my.iris)
iris.discew=disc.ew(my.iris,1:6)
inconsist(iris.discew)
lvf(iris.discew,0,300)



