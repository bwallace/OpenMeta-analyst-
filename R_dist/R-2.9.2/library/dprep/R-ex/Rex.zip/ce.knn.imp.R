### Name: ce.knn.imp
### Title: Function that calls ec.knnimp to perform knn imputation
### Aliases: ce.knn.imp
### Keywords: manip

### ** Examples

data(hepatitis)
hepa.knnimp=ce.knn.imp(hepatitis,natr=c(1,3:14),k1=10)



