### Name: starcoord
### Title: The star coordinates plot
### Aliases: starcoord
### Keywords: hplot

### ** Examples

data(bupa)
starcoord(bupa, main="Bupa Dataset", class=TRUE, outliers=NULL,vars=0, scale=1,
cex=0.8, lwd = 0.25, lty = par("lty"))



