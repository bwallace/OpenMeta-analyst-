### Name: baysout
### Title: Outlier detection using Bay and Schwabacher's algorithm.
### Aliases: baysout
### Keywords: methods

### ** Examples

#---- Outliers detection using the Bay's algorithm----
data(bupa)
bupa.out=baysout(bupa[bupa[,7]==1,1:6],blocks=10,num.out=10)



