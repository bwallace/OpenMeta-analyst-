### Name: sffs
### Title: Sequential Floating Forward Method
### Aliases: sffs
### Keywords: methods

### ** Examples

#---- SFFS feature selection using the knn classifier ----
data(my.iris)
sffs(my.iris,method="knn",kvec=5,repet=5)



