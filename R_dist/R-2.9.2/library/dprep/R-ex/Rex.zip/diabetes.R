### Name: diabetes
### Title: The Pima Indian Diabetes dataset
### Aliases: diabetes
### Keywords: datasets

### ** Examples

#---Feature selection using SFS with the LDA classifier--
data(diabetes)
sfs(diabetes,"lda",repet=4)



