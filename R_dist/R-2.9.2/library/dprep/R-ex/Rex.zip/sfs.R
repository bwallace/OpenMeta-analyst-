### Name: sfs
### Title: Sequential Forward Selection
### Aliases: sfs
### Keywords: methods

### ** Examples

#---- Sequential forward selection using the knn classifier----
data(my.iris)
sfs(my.iris,method="knn",kvec=3,repet=10)



