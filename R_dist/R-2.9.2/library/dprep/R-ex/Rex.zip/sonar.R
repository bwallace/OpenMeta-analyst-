### Name: sonar
### Title: The Sonar dataset
### Aliases: sonar
### Keywords: datasets

### ** Examples

#Robust detection of outliers in sonar-class1 using MVE----
data(sonar)
robout(sonar,1,"mve",rep=10)



