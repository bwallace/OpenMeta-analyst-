### Name: mo4
### Title: The fourth moment of a multivariate distribution
### Aliases: mo4
### Keywords: multivariate

### ** Examples

data(my.iris)
mo4(my.iris)



