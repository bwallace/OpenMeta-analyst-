### Name: cv10log
### Title: 10-fold cross validation estimation error for the classifier
###   based on logistic regression
### Aliases: cv10log
### Keywords: classif

### ** Examples

#-----cross validation error for the logistic classifier-------
data(bupa)
cv10log(bupa,5)


