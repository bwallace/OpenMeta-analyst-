### Name: heartc
### Title: The Heart Cleveland dataset
### Aliases: heartc
### Keywords: datasets

### ** Examples

#----Detecting outliers using the Relief---
data(heartc)
relief(heartc,100,0.4,vnom=c(2,3,6,7,9,11:13))



