### Name: disc.ef
### Title: Discretization using the method of equal frequencies
### Aliases: disc.ef
### Keywords: manip

### ** Examples

#Discretization using the equal frequency method
data(bupa)
bupa.disc.ef=disc.ef(bupa,1:6,8)



