### Name: radviz2d
### Title: Radial Coordinate Visualization
### Aliases: radviz2d
### Keywords: hplot

### ** Examples

data(my.iris)
radviz2d(my.iris,"Iris")



