### Name: imagmiss
### Title: Visualization of Missing Data
### Aliases: imagmiss
### Keywords: hplot

### ** Examples

#---- Plotting datasets with missing values
data(censusn)
imagmiss(censusn, "censusn")



