### Name: straightarrow
### Title: adds straight arrow between two points
### Aliases: straightarrow
### Keywords: aplot

### ** Examples

    openplotmat(main="straightarrow")
    pos <-coordinates(c(2,3,1))
    for (i in 1:5) straightarrow(from=pos[i,],to=pos[i+1,],arr.pos=0.5)
    for (i in 1:6) textrect(pos[i,],lab=LETTERS[i],radx=0.05)



