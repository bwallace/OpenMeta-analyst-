### Name: textrect
### Title: adds lines of text in a rectangular-shaped box to a plot
### Aliases: textrect
### Keywords: aplot

### ** Examples

  openplotmat(xlim=c(-0.1,1.1),main="textrect")
  for (i in 1:10) textrect(mid=runif(2),col=i,radx=0.1,rady=0.1,
                           lab=LETTERS[i],cex=2)



