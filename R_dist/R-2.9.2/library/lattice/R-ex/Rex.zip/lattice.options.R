### Name: lattice.options
### Title: Low-level Options Controlling Behaviour of Lattice
### Aliases: lattice.options lattice.getOption
### Keywords: dplot

### ** Examples

str(lattice.options())
lattice.getOption("save.object")



