### Name: Lattice
### Title: Lattice Graphics
### Aliases: Lattice lattice lattice-package
### Keywords: dplot

### ** Examples

## Not run: 
##D RShowDoc("NEWS", package = "lattice")
## End(Not run)



