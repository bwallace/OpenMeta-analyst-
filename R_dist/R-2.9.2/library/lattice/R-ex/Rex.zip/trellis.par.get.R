### Name: trellis.par.get
### Title: Graphical Parameters for Trellis Displays
### Aliases: trellis.par.get trellis.par.set show.settings
### Keywords: dplot

### ** Examples

show.settings()



