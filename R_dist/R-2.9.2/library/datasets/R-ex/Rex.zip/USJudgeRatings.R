### Name: USJudgeRatings
### Title: Lawyers' Ratings of State Judges in the US Superior Court
### Aliases: USJudgeRatings
### Keywords: datasets

### ** Examples

require(graphics)
pairs(USJudgeRatings, main = "USJudgeRatings data")



