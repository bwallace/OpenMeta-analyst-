### Name: USPersonalExpenditure
### Title: Personal Expenditure Data
### Aliases: USPersonalExpenditure
### Keywords: datasets

### ** Examples

require(stats) # for medpolish
USPersonalExpenditure
medpolish(log10(USPersonalExpenditure))



