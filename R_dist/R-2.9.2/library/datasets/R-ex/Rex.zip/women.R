### Name: women
### Title: Average Heights and Weights for American Women
### Aliases: women
### Keywords: datasets

### ** Examples

require(graphics)
plot(women, xlab = "Height (in)", ylab = "Weight (lb)",
     main = "women data: American women aged 30-39")



