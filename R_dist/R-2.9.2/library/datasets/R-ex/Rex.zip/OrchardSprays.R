### Name: OrchardSprays
### Title: Potency of Orchard Sprays
### Aliases: OrchardSprays
### Keywords: datasets

### ** Examples

require(graphics)
pairs(OrchardSprays, main = "OrchardSprays data")



