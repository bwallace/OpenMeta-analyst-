### Name: USArrests
### Title: Violent Crime Rates by US State
### Aliases: USArrests
### Keywords: datasets

### ** Examples

require(graphics)
pairs(USArrests, panel = panel.smooth, main = "USArrests data")



