### Name: discoveries
### Title: Yearly Numbers of Important Discoveries
### Aliases: discoveries
### Keywords: datasets

### ** Examples

require(graphics)
plot(discoveries, ylab = "Number of important discoveries",
     las = 1)
title(main = "discoveries data set")



