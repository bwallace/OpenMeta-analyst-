### Name: sunspots
### Title: Monthly Sunspot Numbers, 1749-1983
### Aliases: sunspots
### Keywords: datasets

### ** Examples

require(graphics)
plot(sunspots, main = "sunspots data", xlab = "Year",
     ylab = "Monthly sunspot numbers")



