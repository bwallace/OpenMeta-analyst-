### Name: stackloss
### Title: Brownlee's Stack Loss Plant Data
### Aliases: stackloss stack.loss stack.x
### Keywords: datasets

### ** Examples

require(stats)
summary(lm.stack <- lm(stack.loss ~ stack.x))



