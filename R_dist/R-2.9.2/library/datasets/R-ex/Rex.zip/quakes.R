### Name: quakes
### Title: Locations of Earthquakes off Fiji
### Aliases: quakes
### Keywords: datasets

### ** Examples

require(graphics)
pairs(quakes, main = "Fiji Earthquakes, N = 1000", cex.main=1.2, pch=".")



