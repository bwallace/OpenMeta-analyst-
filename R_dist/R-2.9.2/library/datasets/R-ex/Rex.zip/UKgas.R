### Name: UKgas
### Title: UK Quarterly Gas Consumption
### Aliases: UKgas
### Keywords: datasets

### ** Examples

## maybe str(UKgas) ; plot(UKgas) ...



