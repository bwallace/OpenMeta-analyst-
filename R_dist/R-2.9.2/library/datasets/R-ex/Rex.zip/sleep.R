### Encoding: latin1

### Name: sleep
### Title: Student's Sleep Data
### Aliases: sleep
### Keywords: datasets

### ** Examples

require(stats)
## Student's paired t-test
t.test(extra ~ group, data = sleep, paired = TRUE)



