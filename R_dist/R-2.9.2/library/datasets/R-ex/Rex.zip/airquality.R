### Name: airquality
### Title: New York Air Quality Measurements
### Aliases: airquality
### Keywords: datasets

### ** Examples

require(graphics)
pairs(airquality, panel = panel.smooth, main = "airquality data")



