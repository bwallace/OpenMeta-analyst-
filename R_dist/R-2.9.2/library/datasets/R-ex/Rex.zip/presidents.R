### Name: presidents
### Title: Quarterly Approval Ratings of US Presidents
### Aliases: presidents
### Keywords: datasets

### ** Examples

require(stats); require(graphics)
plot(presidents, las = 1, ylab = "Approval rating (%)",
     main = "presidents data")



