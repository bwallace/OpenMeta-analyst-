### Name: bss.background
### Title: Background map for the BSS project
### Aliases: bss.background
### Keywords: datasets

### ** Examples

data(bss.background)
pbb()



