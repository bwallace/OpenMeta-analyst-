### Encoding: latin1

### Name: pkb
### Title: Kola background Plot
### Aliases: pkb
### Keywords: datasets

### ** Examples

example(map.plot)



