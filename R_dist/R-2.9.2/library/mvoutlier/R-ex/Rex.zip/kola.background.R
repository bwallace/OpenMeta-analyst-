### Encoding: latin1

### Name: kola.background
### Title: Background map for the Kola project
### Aliases: kola.background
### Keywords: datasets

### ** Examples

example(map.plot)



