### Encoding: latin1

### Name: moss
### Title: Moss Layer of the Kola Data
### Aliases: moss
### Keywords: datasets

### ** Examples

data(moss)
# classical versus robust correlation:
cor.plot(log(moss[,"Al"]), log(moss[,"Na"]))



