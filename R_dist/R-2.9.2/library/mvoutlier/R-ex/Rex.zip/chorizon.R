### Encoding: latin1

### Name: chorizon
### Title: C-horizon of the Kola Data
### Aliases: chorizon
### Keywords: datasets

### ** Examples

data(chorizon)
# classical versus robust correlation
cor.plot(log(chorizon[,"Al"]), log(chorizon[,"Na"]))



