### Name: labbe
### Title: L'Abbe plot
### Aliases: labbe
### Keywords: hplot

### ** Examples

data(Olkin95)
meta1 <- metabin(event.e, n.e, event.c, n.c,
                 data=Olkin95,
                 studlab=paste(author, year),
                 sm="RR")

##
## L'Abbe plot
##
labbe(meta1)



