### Name: ci
### Title: Calculation of confidence intervals (normal approximation)
### Aliases: ci
### Keywords: htest

### ** Examples

as.data.frame(ci(170, 10))
as.data.frame(ci(170, 10, 0.99))



