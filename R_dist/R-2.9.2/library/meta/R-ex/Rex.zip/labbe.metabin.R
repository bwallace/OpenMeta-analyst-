### Name: labbe.metabin
### Title: L'Abbe plot
### Aliases: labbe.metabin labbe.default
### Keywords: hplot

### ** Examples

data(Olkin95)
meta1 <- metabin(event.e, n.e, event.c, n.c,
                 data=Olkin95,
                 studlab=paste(author, year),
                 sm="RR", meth="I")

##
## L'Abbe plot
##
labbe(meta1)



