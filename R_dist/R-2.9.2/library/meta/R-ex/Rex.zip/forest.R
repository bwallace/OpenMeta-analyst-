### Name: forest
### Title: Forest plot (new plot function for objects of class meta)
### Aliases: forest
### Keywords: hplot

### ** Examples

data(Olkin95)
meta1 <- metabin(event.e, n.e, event.c, n.c,
                 data=Olkin95, subset=c(41,47,51,59),
                 sm="RR", meth="I",
                 studlab=paste(author, year))

grid.newpage()
##
## Do forest plot
##
forest(meta1, comb.fixed=TRUE, comb.random=TRUE)

grid.newpage()
##
## Change set of columns printed on left side
## of forest plot
##
forest(meta1, comb.fixed=TRUE, comb.random=FALSE,
       leftcols="studlab")

grid.newpage()
##
## 1. Change order of columns on left side
## 2. Attach labels to columns 'event.e' and 'event.c'
##    instead of columns 'n.e' and 'n.c'
##
forest(meta1,
       leftcols=c("studlab", "n.e", "event.e", "n.c", "event.c"),
       lab.e.attach.to.col="event.e",
       lab.c.attach.to.col="event.c",
       comb.fixed=TRUE)

Olkin95$studlab <- paste(Olkin95$author, Olkin95$year)
##
## Add variables 'year' and 'author' to meta-analysis object
##
meta1$year <- addvar(meta1, Olkin95, "year")
meta1$author <- addvar(meta1, Olkin95, "author")

grid.newpage()
##
## Specify column labels only for newly created variables
## 'year' and 'author'
##
forest(meta1,
       leftcols=c("studlab", "event.e", "n.e", "event.c", "n.c",
                  "author", "year"),
       leftlabs=c("Author", "Year of Publ"),
       comb.fixed=TRUE)



