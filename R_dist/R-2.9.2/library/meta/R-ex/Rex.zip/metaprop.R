### Name: metaprop
### Title: Meta-analysis of single proportions
### Aliases: metaprop
### Keywords: htest

### ** Examples

metaprop(0, 10)
metaprop(0, 10, freeman.tukey=FALSE)



