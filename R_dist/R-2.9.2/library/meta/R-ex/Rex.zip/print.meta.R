### Name: print.meta
### Title: Print and summary method for objects of class meta
### Aliases: print.meta print.metabias summary.meta print.summary.meta
### Keywords: print

### ** Examples

data(Fleiss93cont)
meta1 <- metacont(n.e, mean.e, sd.e, n.c, mean.c, sd.c, data=Fleiss93cont, sm="SMD")
summary(meta1)
summary(meta1, byvar=c(1,2,1,1,2), bylab="group")



