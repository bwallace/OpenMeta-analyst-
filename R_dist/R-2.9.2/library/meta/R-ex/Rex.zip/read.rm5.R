### Name: read.rm5
### Title: Import RevMan 5 data files (.csv)
### Aliases: read.rm5 Fleiss93_CR Fleiss93_CR_Windows
### Keywords: datagen

### ** Examples

## Locate export data file "Fleiss93_CR.csv" or "Fleiss93_CR_Windows.csv"
## in sub-directory of package "meta"
##
filename <- paste(searchpaths()[seq(along=search())[search()==
                  "package:meta"]], "/data/Fleiss93_CR",
                  if (Sys.info()[["sysname"]]=="Windows") "_Windows" else "",
                  ".csv", sep="")
Fleiss93_CR <- read.rm5(filename)

## Same result: example(Fleiss93)
##
metacr(Fleiss93_CR)

## Same result: example(Fleiss93cont)
##
metacr(Fleiss93_CR, 1, 2)



