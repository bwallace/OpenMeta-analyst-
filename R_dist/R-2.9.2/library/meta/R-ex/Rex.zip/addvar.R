### Name: addvar
### Title: Additional functions for objects of class meta
### Aliases: addvar as.data.frame.meta
### Keywords: print

### ** Examples

data(Fleiss93cont)
meta1 <- metacont(n.e, mean.e, sd.e, n.c, mean.c, sd.c, study,
                  data=Fleiss93cont, sm="SMD")
#
# Generate additional variable
#
Fleiss93cont$group <- c(1,2,1,1,2)
#
# Generate new variable by merging
# object 'meta1' and data frame 'Fleiss93cont'
#
meta1$group <- addvar(meta1, Fleiss93cont, "group", by.y="study")
as.data.frame(meta1)
summary(meta1, byvar=group)



