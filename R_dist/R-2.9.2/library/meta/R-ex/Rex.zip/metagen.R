### Name: metagen
### Title: Generic inverse variance meta-analysis
### Aliases: metagen
### Keywords: htest

### ** Examples

data(Fleiss93)
meta1 <- metabin(event.e, n.e, event.c, n.c, data=Fleiss93, sm="RR", meth="I")
meta1

##
## Identical results by using the following commands:
##
meta1
metagen(meta1$TE, meta1$seTE, sm="RR")

##
## Meta-analysis of survival data:
##
logHR <- log(c(0.95, 1.5))
selogHR <- c(0.25, 0.35)

metagen(logHR, selogHR, sm="HR")



