### Name: metacum
### Title: Cumulative meta-analysis
### Aliases: metacum
### Keywords: htest

### ** Examples

data(Fleiss93)
meta1 <- metabin(event.e, n.e, event.c, n.c,
                 data=Fleiss93, studlab=study,
                 sm="RR", meth="I")
meta1

metacum(meta1)
metacum(meta1, pooled="random")

grid.newpage()
forest(metacum(meta1, pooled="random"))



