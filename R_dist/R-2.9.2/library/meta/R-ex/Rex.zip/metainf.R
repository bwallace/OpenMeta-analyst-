### Name: metainf
### Title: Influence analysis in meta-analysis
### Aliases: metainf
### Keywords: htest

### ** Examples

data(Fleiss93)
meta1 <- metabin(event.e, n.e, event.c, n.c,
                 data=Fleiss93, studlab=study,
                 sm="RR", meth="I")
meta1

metainf(meta1)
metainf(meta1, pooled="random")

grid.newpage()
forest(metainf(meta1, pooled="random"), comb.random=TRUE)



