### Name: metabin
### Title: Meta-analysis of binary outcome data
### Aliases: metabin
### Keywords: htest

### ** Examples

metabin(10, 20, 15, 20, sm="OR")

##
## Different results:
##
metabin(0, 10, 0, 10, sm="OR")
metabin(0, 10, 0, 10, sm="OR", allstudies=TRUE)

data(Olkin95)

meta1 <- metabin(event.e, n.e, event.c, n.c,
                 data=Olkin95, subset=c(41,47,51,59),
                 sm="RR", meth="I")
summary(meta1)
funnel(meta1)

meta2 <- metabin(event.e, n.e, event.c, n.c,
                 data=Olkin95, subset=Olkin95$year<1970,
                 sm="RR", meth="I")
summary(meta2)



