### Name: plot.meta
### Title: Plot function for objects of class meta
### Aliases: plot.meta
### Keywords: hplot

### ** Examples

data(Olkin95)
meta1 <- metabin(event.e, n.e, event.c, n.c,
                 data=Olkin95, subset=c(41,47,51,59),
                 sm="RR", meth="I")

oldpar <- par(mfrow=c(2, 2))

plot(meta1)
plot(meta1, byvar=c(1,2,1,2), bylab="label")
plot(meta1, byvar=1:4, xlim=c(0.02, 10))

par(oldpar)



