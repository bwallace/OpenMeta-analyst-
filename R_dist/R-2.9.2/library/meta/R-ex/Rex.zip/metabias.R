### Name: metabias
### Title: Test for funnel plot asymmetry
### Aliases: metabias
### Keywords: htest

### ** Examples

data(Olkin95)
meta1 <- metabin(event.e, n.e, event.c, n.c,
                 data=Olkin95, subset=c(41,47,51,59),
                 sm="RR", meth="I")

metabias(meta1)
metabias(meta1, correct=TRUE)

metabias(meta1, method="linreg")
metabias(meta1, method="linreg", plotit=TRUE)

metabias(meta1, method="count")

##
## Same result:
##
metabias(meta1, method="linreg")$p.value
metabias(meta1$TE, meta1$seTE, method="linreg")$p.value

##
## Arcsine test:
##
meta1.as <- metabin(event.e, n.e, event.c, n.c,
                    data=Olkin95, subset=c(41,47,51,59),
                    sm="AS", meth="I")
metabias(meta1.as, method="linreg")




