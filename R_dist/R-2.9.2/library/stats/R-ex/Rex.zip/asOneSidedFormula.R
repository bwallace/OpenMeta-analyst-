### Name: asOneSidedFormula
### Title: Convert to One-Sided Formula
### Aliases: asOneSidedFormula
### Keywords: models

### ** Examples

asOneSidedFormula("age")
asOneSidedFormula(~ age)



