### Name: na.action
### Title: NA Action
### Aliases: na.action na.action.default
### Keywords: NA methods

### ** Examples

na.action(na.omit(c(1, NA)))



