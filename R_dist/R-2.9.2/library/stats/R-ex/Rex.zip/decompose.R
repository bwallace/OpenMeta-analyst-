### Name: decompose
### Title: Classical Seasonal Decomposition by Moving Averages
### Aliases: decompose plot.decomposed.ts
### Keywords: ts

### ** Examples

require(graphics)

m <- decompose(co2)
m$figure
plot(m)

## example taken from Kendall/Stuart
x <- c(-50, 175, 149, 214, 247, 237, 225, 329, 729, 809, 
       530, 489, 540, 457, 195, 176, 337, 239, 128, 102, 232, 429, 3, 
       98, 43, -141, -77, -13, 125, 361, -45, 184)
x <- ts(x, start = c(1951, 1), end = c(1958, 4), frequency = 4)
m <- decompose(x)
## seasonal figure: 6.25, 8.62, -8.84, -6.03
round(decompose(x)$figure / 10, 2)



