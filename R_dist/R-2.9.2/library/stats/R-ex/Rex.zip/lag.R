### Name: lag
### Title: Lag a Time Series
### Aliases: lag lag.default
### Keywords: ts

### ** Examples

lag(ldeaths, 12) # starts one year earlier



