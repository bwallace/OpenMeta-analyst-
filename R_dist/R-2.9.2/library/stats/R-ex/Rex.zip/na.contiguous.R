### Name: na.contiguous
### Title: Find Longest Contiguous Stretch of non-NAs
### Aliases: na.contiguous na.contiguous.default
### Keywords: ts

### ** Examples

na.contiguous(presidents)



