### Name: toeplitz
### Title: Form Symmetric Toeplitz Matrix
### Aliases: toeplitz
### Keywords: ts

### ** Examples

x <- 1:5
toeplitz (x)



