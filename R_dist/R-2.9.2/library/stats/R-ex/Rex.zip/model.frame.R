### Name: model.frame
### Title: Extracting the ``Environment'' of a Model Formula
### Aliases: model.frame model.frame.default model.frame.lm model.frame.glm
###   model.frame.aovlist get_all_vars
### Keywords: models

### ** Examples

data.class(model.frame(dist ~ speed, data = cars))



