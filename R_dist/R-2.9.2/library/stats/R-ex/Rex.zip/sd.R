### Name: sd
### Title: Standard Deviation
### Aliases: sd
### Keywords: univar

### ** Examples

sd(1:2) ^ 2



