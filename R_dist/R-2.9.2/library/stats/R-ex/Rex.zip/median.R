### Name: median
### Title: Median Value
### Aliases: median median.default
### Keywords: univar robust

### ** Examples

median(1:4)# = 2.5 [even number]
median(c(1:3,100,1000))# = 3 [odd, robust]



