### Name: biplot.princomp
### Title: Biplot for Principal Components
### Aliases: biplot.princomp biplot.prcomp
### Keywords: multivariate hplot

### ** Examples

require(graphics)
biplot(princomp(USArrests))



