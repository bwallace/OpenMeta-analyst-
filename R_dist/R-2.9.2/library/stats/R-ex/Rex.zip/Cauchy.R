### Name: Cauchy
### Title: The Cauchy Distribution
### Aliases: Cauchy dcauchy pcauchy qcauchy rcauchy
### Keywords: distribution

### ** Examples

dcauchy(-1:4)



