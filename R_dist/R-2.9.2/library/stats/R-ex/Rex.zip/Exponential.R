### Name: Exponential
### Title: The Exponential Distribution
### Aliases: Exponential dexp pexp qexp rexp
### Keywords: distribution

### ** Examples

dexp(1) - exp(-1) #-> 0



