### Name: Logistic
### Title: The Logistic Distribution
### Aliases: Logistic dlogis plogis qlogis rlogis
### Keywords: distribution

### ** Examples

var(rlogis(4000, 0, scale = 5))# approximately (+/- 3)
pi^2/3 * 5^2



