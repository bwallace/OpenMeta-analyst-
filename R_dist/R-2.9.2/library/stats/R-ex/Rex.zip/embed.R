### Name: embed
### Title: Embedding a Time Series
### Aliases: embed
### Keywords: ts

### ** Examples

x <- 1:10
embed (x, 3)



