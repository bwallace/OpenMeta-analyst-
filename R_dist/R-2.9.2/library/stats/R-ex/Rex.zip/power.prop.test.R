### Encoding: latin1

### Name: power.prop.test
### Title: Power calculations two sample test for proportions
### Aliases: power.prop.test
### Keywords: htest

### ** Examples

 power.prop.test(n = 50, p1 = .50, p2 = .75)
 power.prop.test(p1 = .50, p2 = .75, power = .90)
 power.prop.test(n = 50, p1 = .5, power = .90)



