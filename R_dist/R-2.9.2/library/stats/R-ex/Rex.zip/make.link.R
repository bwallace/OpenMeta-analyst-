### Name: make.link
### Title: Create a Link for GLM Families
### Aliases: make.link
### Keywords: models

### ** Examples

utils::str(make.link("logit"))



