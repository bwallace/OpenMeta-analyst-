### Name: fivenum
### Title: Tukey Five-Number Summaries
### Aliases: fivenum
### Keywords: univar robust distribution

### ** Examples

fivenum(c(rnorm(100),-1:1/0))



