### Name: power
### Title: Create a Power Link Object
### Aliases: power
### Keywords: models

### ** Examples

power()
quasi(link=power(1/3))[c("linkfun", "linkinv")]



