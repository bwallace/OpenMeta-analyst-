### Name: nls.control
### Title: Control the Iterations in nls
### Aliases: nls.control
### Keywords: nonlinear regression models

### ** Examples

nls.control(minFactor = 1/2048)



