### Name: acf2AR
### Title: Compute an AR Process Exactly Fitting an ACF
### Aliases: acf2AR
### Keywords: ts

### ** Examples

(Acf <- ARMAacf(c(0.6, 0.3, -0.2)))
acf2AR(Acf)



