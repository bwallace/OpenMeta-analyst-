### Name: print.ts
### Title: Printing Time-Series Objects
### Aliases: print.ts
### Keywords: ts

### ** Examples

print(ts(1:10, frequency = 7, start = c(12, 2)), calendar = TRUE)



