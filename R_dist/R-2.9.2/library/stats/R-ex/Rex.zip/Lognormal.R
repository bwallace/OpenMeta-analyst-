### Name: Lognormal
### Title: The Log Normal Distribution
### Aliases: Lognormal dlnorm plnorm qlnorm rlnorm
### Keywords: distribution

### ** Examples

dlnorm(1) == dnorm(0)



