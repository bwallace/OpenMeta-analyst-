### Name: setNames
### Title: Set the Names in an Object
### Aliases: setNames
### Keywords: list

### ** Examples

setNames( 1:3, c("foo", "bar", "baz") )
# this is just a short form of
tmp <- 1:3
names(tmp) <-  c("foo", "bar", "baz")
tmp



