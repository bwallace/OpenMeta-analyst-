### Name: kernapply
### Title: Apply Smoothing Kernel
### Aliases: kernapply kernapply.default kernapply.ts kernapply.tskernel
###   kernapply.vector
### Keywords: ts

### ** Examples

## see 'kernel' for examples



