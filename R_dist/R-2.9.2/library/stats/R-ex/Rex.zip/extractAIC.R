### Name: extractAIC
### Title: Extract AIC from a Fitted Model
### Aliases: extractAIC
### Keywords: models

### ** Examples

utils::example(glm)
extractAIC(glm.D93)#>>  5  15.129



