### Name: clearNames
### Title: Remove the Names from an Object
### Aliases: clearNames
### Keywords: list

### ** Examples

lapply( women, mean )               # has a names attribute
clearNames( lapply( women, mean ) ) # removes the names



