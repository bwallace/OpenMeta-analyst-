### Name: ppoints
### Title: Ordinates for Probability Plotting
### Aliases: ppoints
### Keywords: dplot arith distribution

### ** Examples

ppoints(4) # the same as  ppoints(1:4)
ppoints(10)
ppoints(10, a=1/2)



