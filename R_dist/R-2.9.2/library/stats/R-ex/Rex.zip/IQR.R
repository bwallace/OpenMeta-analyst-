### Name: IQR
### Title: The Interquartile Range
### Aliases: IQR
### Keywords: univar robust distribution

### ** Examples

IQR(rivers)



