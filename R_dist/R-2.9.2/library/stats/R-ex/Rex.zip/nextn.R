### Name: nextn
### Title: Highly Composite Numbers
### Aliases: nextn
### Keywords: math

### ** Examples

nextn(1001) # 1024
table(sapply(599:630, nextn))



