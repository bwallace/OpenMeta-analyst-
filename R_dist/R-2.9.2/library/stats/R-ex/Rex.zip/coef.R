### Name: coef
### Title: Extract Model Coefficients
### Aliases: coef coefficients
### Keywords: regression models

### ** Examples

x <- 1:5; coef(lm(c(1:3,7,6) ~ x))



