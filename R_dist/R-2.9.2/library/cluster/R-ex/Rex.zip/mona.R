### Name: mona
### Title: MONothetic Analysis Clustering of Binary Variables
### Aliases: mona
### Keywords: cluster

### ** Examples

data(animals)
ma <- mona(animals)
ma
## Plot similar to Figure 10 in Struyf et al (1996)
plot(ma)



