### Name: flower
### Title: Flower Characteristics
### Aliases: flower
### Keywords: datasets

### ** Examples

data(flower)
## Example 2 in ref
daisy(flower, type = list(asymm = 3))
daisy(flower, type = list(asymm = c(1, 3), ordratio = 7))



