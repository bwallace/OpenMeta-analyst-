### Name: cumul.rma.uni
### Title: Cumulative Meta-Analysis for rma.uni Objects
### Aliases: cumul.rma.uni
### Keywords: methods

### ** Examples

### load BCG vaccine data
data(dat.bcg)

### calculate log risk ratios and corresponding sampling variances
dat <- escalc(measure="RR", ai=tpos, bi=tneg, ci=cpos, di=cneg, data=dat.bcg)
dat <- cbind(dat.bcg, dat)

### random-effects model
res <- rma(yi, vi, data=dat, method="REML")

cumul(res, transf=exp, order=order(dat$year))



