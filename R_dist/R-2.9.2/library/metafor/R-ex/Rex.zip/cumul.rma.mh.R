### Name: cumul.rma.mh
### Title: Cumulative Meta-Analysis for rma.mh and rma.peto Objects
### Aliases: cumul.rma.mh cumul.rma.peto
### Keywords: methods

### ** Examples

### load BCG vaccine data
data(dat.bcg)

### meta-analysis of the (log) risk ratios using the Mantel-Haenszel method
res <- rma.mh(ai=tpos, bi=tneg, ci=cpos, di=cneg, data=dat.bcg, measure="RR")

cumul(res, order=order(dat.bcg$year))
cumul(res, order=order(dat.bcg$year), transf=TRUE)

### meta-analysis of the (log) odds ratios using Peto's method
res <- rma.mh(ai=tpos, bi=tneg, ci=cpos, di=cneg, data=dat.bcg)

cumul(res, order=order(dat.bcg$year))
cumul(res, order=order(dat.bcg$year), transf=TRUE)



