### Name: radial.rma
### Title: Radial Plots for rma Objects
### Aliases: radial.rma
### Keywords: hplot

### ** Examples

### load BCG vaccine data
data(dat.bcg)

### meta-analysis of the log risk ratios using a fixed-effects model
res <- rma(ai=tpos, bi=tneg, ci=cpos, di=cneg, 
           data=dat.bcg, measure="RR", method="FE")
radial(res)

### line from (0,0) with slope of the log risk ratio from the 4th study
abline(a=0, b=c(-1.44155119))

### meta-analysis of the log risk ratios using a random-effects model
res <- rma(ai=tpos, bi=tneg, ci=cpos, di=cneg, 
           data=dat.bcg, measure="RR", method="REML")
radial(res)



