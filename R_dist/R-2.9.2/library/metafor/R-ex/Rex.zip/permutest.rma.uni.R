### Name: permutest.rma.uni
### Title: Permutation Tests for rma.uni Objects
### Aliases: permutest.rma.uni
### Keywords: models

### ** Examples

### load BCG vaccine data
data(dat.bcg)

### calculate log risk ratios and corresponding sampling variances
dat <- escalc(measure="RR", ai=tpos, bi=tneg, ci=cpos, di=cneg, data=dat.bcg)
dat <- cbind(dat.bcg, dat)

### random-effects model 
res <- rma(yi, vi, data=dat, method="REML")
## Not run: permutest(res)

### mixed-effects model with two moderators (absolute latitude and publication year)
res1 <- rma(yi, vi, mods=cbind(ablat, year), data=dat, method="REML")
## Not run: permutest(res)



