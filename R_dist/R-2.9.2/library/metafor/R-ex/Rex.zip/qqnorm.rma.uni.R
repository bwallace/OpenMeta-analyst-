### Name: qqnorm.rma.uni
### Title: Normal QQ Plot for rma Objects
### Aliases: qqnorm.rma.uni qqnorm.rma.mh qqnorm.rma.peto
### Keywords: hplot

### ** Examples

### load BCG vaccine data
data(dat.bcg)

### meta-analysis of the log risk ratios using a random-effects model
res <- rma(ai=tpos, bi=tneg, ci=cpos, di=cneg, 
           data=dat.bcg, measure="RR", method="REML")
qqnorm(res)

### mixed-effects model with absolute latitude as a moderator
res <- rma(ai=tpos, bi=tneg, ci=cpos, di=cneg, mods=ablat, 
           measure="RR", data=dat.bcg, method="REML")
qqnorm(res)



