### Name: trimfill.rma.uni
### Title: Trim and Fill Method for rma.uni Objects
### Aliases: trimfill.rma.uni
### Keywords: models

### ** Examples

### load BCG vaccine data
data(dat.bcg)

### meta-analysis of the log risk ratios using a fixed-effects model
res <- rma(ai=tpos, bi=tneg, ci=cpos, di=cneg, 
           data=dat.bcg, measure="RR", method="FE")
trimfill(res)
funnel(trimfill(res))

### meta-analysis of the log risk ratios using a random-effects model
res <- rma(ai=tpos, bi=tneg, ci=cpos, di=cneg, 
           data=dat.bcg, measure="RR", method="REML")
trimfill(res)
funnel(trimfill(res))



