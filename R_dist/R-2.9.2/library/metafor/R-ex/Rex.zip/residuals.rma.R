### Name: residuals.rma
### Title: Residual Values based on rma Objects
### Aliases: residuals.rma rstandard.rma.uni rstandard.rma.mh
###   rstandard.rma.peto rstudent.rma.uni rstudent.rma.mh rstudent.rma.peto
### Keywords: models

### ** Examples

### load BCG vaccine data
data(dat.bcg)

### meta-analysis of the log risk ratios using a random-effects model
res <- rma(ai=tpos, bi=tneg, ci=cpos, di=cneg, 
           data=dat.bcg, measure="RR", method="REML")
rstudent(res)

### mixed-effects model with absolute latitude as a moderator
res <- rma(ai=tpos, bi=tneg, ci=cpos, di=cneg, mods=ablat, 
           measure="RR", data=dat.bcg, method="REML")
rstudent(res)



