### Name: hatvalues.rma.uni
### Title: Diagonal Elements of the Hat Matrix for rma.uni Objects
### Aliases: hatvalues.rma.uni
### Keywords: models

### ** Examples

### load BCG vaccine data
data(dat.bcg)

### meta-analysis of the log risk ratios using a mixed-effects model
### with two moderators (absolute latitude and publication year)
res <- rma(ai=tpos, bi=tneg, ci=cpos, di=cneg, mods=cbind(ablat, year),
           data=dat.bcg, measure="RR", method="REML")
hatvalues(res)



