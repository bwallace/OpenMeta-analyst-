### Name: forest.rma
### Title: Forest Plots for rma Objects
### Aliases: forest.rma
### Keywords: hplot

### ** Examples

### load BCG vaccine data
data(dat.bcg)

### meta-analysis of the log risk ratios using a random-effects model
res <- rma(ai=tpos, bi=tneg, ci=cpos, di=cneg, slab=paste(author, year),
           data=dat.bcg, measure="RR", method="REML")

### several forest plots illustrating the use of various arguments
forest(res, xlab="Log Relative Risk")
forest(res, xlab="Log Relative Risk", order=order(dat.bcg$ablat))
forest(res, transf=exp, alim=c(0,6), steps=4, xlim=c(-8,12), 
       xlab="Relative Risk", refline=1)
forest(res, atransf=exp, at=log(c(.05,.25,1,4,12)), xlim=c(-8,6), 
       xlab="Relative Risk (log scale)", order="prec")
forest(res, slab=paste(dat.bcg$author, ", ", dat.bcg$year, sep=""), 
       xlim=c(-14,6), ylim=c(-1.5,15.5), at=log(c(.05,.25,1,4)), 
       atransf=exp, xlab="Relative Risk (log scale)",
       ilab=cbind(dat.bcg$tpos, dat.bcg$tneg, dat.bcg$cpos, dat.bcg$cneg), 
       ilab.xpos=c(-8.5,-7,-5,-3.5), cex=.7)
text(c(-8.5,-7,-5,-3.5), 14.5, c("TB+", "TB-", "TB+", "TB-"), cex=.7)
text(c(-7.75,-4.25),     15.5, c("Vaccinated", "Control"),    cex=.7)
text(-14,                14.5, "Author(s) and Year",   pos=4, cex=.7)
text(6,                  14.5, "Observed RR [95% CI]", pos=2, cex=.7)

### mixed-effects model with absolute latitude in the model
res <- rma(ai=tpos, bi=tneg, ci=cpos, di=cneg, mods=ablat, slab=paste(author, year),
           data=dat.bcg, measure="RR", method="REML")

### forest plots with observed and fitted values
forest(res, xlim=c(-9,5), order="fit", xlab="Relative Risk (log scale)", cex=.8,
       ilab=dat.bcg$ablat, ilab.xpos=-4, atransf=exp, at=log(c(.05,.25,1,4)))
text(-9, 15, "Author(s) and Year", pos=4, cex=.8)
text(5,  15, "Observed RR [95% CI]", pos=2, cex=.8)
text(-4,  15, "Latitude", cex=.8)



