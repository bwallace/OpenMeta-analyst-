### Name: regtest.rma
### Title: Regression Tests for Funnel Plot Asymmetry for rma Objects
### Aliases: regtest.rma
### Keywords: htest

### ** Examples

### load BCG vaccine data
data(dat.bcg)

### calculate log risk ratios and corresponding sampling variances
dat <- escalc(measure="RR", ai=tpos, bi=tneg, ci=cpos, di=cneg, data=dat.bcg)
dat <- cbind(dat.bcg, dat)

### random-effects model
res <- rma(yi, vi, data=dat, method="FE")
regtest(res)

res <- rma(measure="RR", ai=tpos, bi=tneg, ci=cpos, di=cneg, 
           data=dat, method="REML")
regtest(res, model="lm", predictor="ni")

res <- rma(measure="PETO", ai=tpos, bi=tneg, ci=cpos, di=cneg, 
           data=dat, method="FE")
regtest(res, predictor="ninv")

res <- rma(measure="RR", ai=tpos, bi=tneg, ci=cpos, di=cneg, 
           data=dat, mods=cbind(ablat), method="REML")
regtest(res, predictor="ninv")



