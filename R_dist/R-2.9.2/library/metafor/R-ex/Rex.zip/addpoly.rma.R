### Name: addpoly.rma
### Title: Add Summary Estimate Polygon to Forest Plot
### Aliases: addpoly.rma
### Keywords: aplot

### ** Examples

### load BCG vaccine data
data(dat.bcg)

### meta-analysis of the log risk ratios using the Mantel-Haenszel method
res <- rma.mh(ai=tpos, bi=tneg, ci=cpos, di=cneg, slab=paste(author, year),
              data=dat.bcg, measure="RR")

### forest plot of the observer risk ratios with summary estimate
forest(res, atransf=exp, addrows=1, xlab="Relative Risk (log scale)")

### meta-analysis of the log risk ratios using a random-effects model
res <- rma(ai=tpos, bi=tneg, ci=cpos, di=cneg, 
           data=dat.bcg, measure="RR", method="REML")

### add summary estimate from the random-effects model to forest plot
addpoly(res, atransf=exp)



