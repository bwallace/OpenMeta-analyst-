### Name: rma.uni
### Title: Meta-Analysis via the General Linear (Mixed-Effects) Model
### Aliases: rma.uni rma
### Keywords: models

### ** Examples

### load BCG vaccine data
data(dat.bcg)

### calculate log risk ratios and corresponding sampling variances
dat <- escalc(measure="RR", ai=tpos, bi=tneg, ci=cpos, di=cneg, data=dat.bcg)
dat <- cbind(dat.bcg, dat)

### random-effects model
rma(yi, vi, data=dat, method="REML")

### mixed-effects model with two moderators (absolute latitude and publication year)
rma(yi, vi, mods=cbind(ablat, year), data=dat, method="REML")

### supplying the raw data directly to the function
rma(ai=tpos, bi=tneg, ci=cpos, di=cneg, mods=cbind(ablat, year), 
    data=dat, measure="RR", method="REML")

### dummy coding of the allocation factor
alloc.random     <- ifelse(dat$alloc == "random",     1, 0)
alloc.alternate  <- ifelse(dat$alloc == "alternate",  1, 0)
alloc.systematic <- ifelse(dat$alloc == "systematic", 1, 0)

### test the allocation factor (in the presence of the other moderators)
### note: "alternate" is the reference level of the allocation factor
### note: the intercept is the first coefficient, so btt=c(2,3)
rma(yi, vi, mods=cbind(alloc.random, alloc.systematic, year, ablat), 
    data=dat, method="REML", btt=c(2,3))

### use model.matrix() to code the factor and set up the design matrix
### careful: X already includes the intercept, so need to use intercept=FALSE
X <- model.matrix(~ factor(alloc) + year + ablat, data=dat)
rma(yi, vi, mods=X, intercept=FALSE, data=dat, method="REML", btt=c(2,3))



