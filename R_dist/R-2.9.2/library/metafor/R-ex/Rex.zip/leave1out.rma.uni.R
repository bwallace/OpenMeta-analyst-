### Name: leave1out.rma.uni
### Title: Leave-One-Out Diagnostics for rma.uni Objects
### Aliases: leave1out.rma.uni
### Keywords: methods

### ** Examples

### load BCG vaccine data
data(dat.bcg)

### calculate log risk ratios and corresponding sampling variances
dat <- escalc(measure="RR", ai=tpos, bi=tneg, ci=cpos, di=cneg, data=dat.bcg)
dat <- cbind(dat.bcg, dat)

### random-effects model
res <- rma(yi, vi, data=dat, method="REML")

leave1out(res)
leave1out(res, transf=exp)



