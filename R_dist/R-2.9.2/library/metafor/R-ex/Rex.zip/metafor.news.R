### Name: metafor.news
### Title: Read News File of the Metafor Package
### Aliases: metafor.news
### Keywords: IO

### ** Examples

metafor.news() 



