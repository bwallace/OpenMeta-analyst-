### Name: forest.default
### Title: Forest Plots
### Aliases: forest.default
### Keywords: hplot

### ** Examples

### load BCG vaccine data
data(dat.bcg)

### calculate log risk ratios and corresponding sampling variances
dat <- escalc(measure="RR", ai=tpos, bi=tneg, ci=cpos, di=cneg, data=dat.bcg)
dat <- cbind(dat.bcg, dat)

### forest plot of the observed risk ratios
forest(dat$yi, dat$vi, slab=paste(dat.bcg$author, dat$year), 
       atransf=exp, xlab="Risk Ratio (log scale)")



