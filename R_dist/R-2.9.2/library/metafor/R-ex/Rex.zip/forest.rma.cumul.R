### Name: forest.cumul.rma
### Title: Forest Plots for cumul.rma Objects
### Aliases: forest.cumul.rma
### Keywords: hplot

### ** Examples

### load BCG vaccine data
data(dat.bcg)

### calculate log risk ratios and corresponding sampling variances
dat <- escalc(measure="RR", ai=tpos, bi=tneg, ci=cpos, di=cneg, data=dat.bcg)
dat <- cbind(dat.bcg, dat)

### random-effects model
res <- rma(yi, vi, data=dat, method="REML")

x <- cumul(res, order=order(dat$year))
forest(x)

### meta-analysis of the (log) risk ratios using the Mantel-Haenszel method
res <- rma.mh(ai=tpos, bi=tneg, ci=cpos, di=cneg, data=dat.bcg, measure="RR")
x <- cumul(res, order=order(dat$year))
forest(x)



