### Name: rma.mh
### Title: Meta-Analysis via the Mantel-Haenszel Method
### Aliases: rma.mh
### Keywords: models

### ** Examples

### load BCG vaccine data
data(dat.bcg)

### meta-analysis of the (log) odds ratios using the Mantel-Haenszel method
rma.mh(ai=tpos, bi=tneg, ci=cpos, di=cneg, data=dat.bcg, measure="OR")

### meta-analysis of the (log) risk ratios using the Mantel-Haenszel method
rma.mh(ai=tpos, bi=tneg, ci=cpos, di=cneg, data=dat.bcg, measure="RR")



