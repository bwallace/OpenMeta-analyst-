### Name: transf
### Title: Transformation Functions
### Aliases: transf.rtoz transf.ztor transf.logit transf.ilogit
###   transf.ztor.int transf.exp.int
### Keywords: manip

### ** Examples

### load BCG vaccine data
data(dat.bcg)

### meta-analysis of the log risk ratios using a random-effects model
res <- rma(ai=tpos, bi=tneg, ci=cpos, di=cneg, 
           measure="RR", data=dat.bcg, method="REML")

### average risk ratio with 95% CI
predict(res, transf=exp)

### average risk ratio with 95% CI using integral transformation
predict(res, transf=transf.exp.int, targs=list(tau2=res$tau2, lower=-4, upper=4))



