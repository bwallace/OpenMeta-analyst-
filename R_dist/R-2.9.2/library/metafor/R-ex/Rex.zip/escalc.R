### Name: escalc
### Title: Calculate Effect Size and Outcome Measures
### Aliases: escalc
### Keywords: datagen

### ** Examples

### load BCG vaccine data
data(dat.bcg)

### calculate log risk ratios and corresponding sampling variances
dat <- escalc(measure="RR", ai=tpos, bi=tneg, ci=cpos, di=cneg, data=dat.bcg)

### add log risk ratios and sampling variances to the data frame
dat <- cbind(dat.bcg, dat)
dat



