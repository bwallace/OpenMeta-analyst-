### Name: ranktest.rma
### Title: Rank Correlation Test for Funnel Plot Asymmetry for rma Objects
### Aliases: ranktest.rma
### Keywords: htest

### ** Examples

### load BCG vaccine data
data(dat.bcg)

### calculate log risk ratios and corresponding sampling variances
dat <- escalc(measure="RR", ai=tpos, bi=tneg, ci=cpos, di=cneg, data=dat.bcg)
dat <- cbind(dat.bcg, dat)

### random-effects model
res <- rma(yi, vi, data=dat, method="REML")

ranktest(res)



