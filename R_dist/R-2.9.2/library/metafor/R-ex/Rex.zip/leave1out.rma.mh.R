### Name: leave1out.rma.mh
### Title: Leave-One-Out Diagnostics for rma.mh and rma.peto Objects
### Aliases: leave1out.rma.mh leave1out.rma.peto
### Keywords: methods

### ** Examples

### load BCG vaccine data
data(dat.bcg)

### meta-analysis of the (log) risk ratios using the Mantel-Haenszel method
res <- rma.mh(ai=tpos, bi=tneg, ci=cpos, di=cneg, data=dat.bcg, measure="RR")

leave1out(res)
leave1out(res, transf=TRUE)

### meta-analysis of the (log) odds ratios using Peto's method
res <- rma.mh(ai=tpos, bi=tneg, ci=cpos, di=cneg, data=dat.bcg)

leave1out(res)
leave1out(res, transf=TRUE)



