### Name: getS3method
### Title: Get An S3 Method
### Aliases: getS3method
### Keywords: data

### ** Examples

require(stats)
exists("predict.ppr") # false
getS3method("predict", "ppr")



