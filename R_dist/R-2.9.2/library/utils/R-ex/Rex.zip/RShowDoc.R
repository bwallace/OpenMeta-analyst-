### Name: RShowDoc
### Title: Show R Manuals and Other Documentation
### Aliases: RShowDoc
### Keywords: documentation

### ** Examples
## Not run: 
##D RShowDoc("R-lang")
##D RShowDoc("FAQ", type="html")
##D RShowDoc("frame", package="grid")
##D RShowDoc("changes.txt", package="grid")
##D RShowDoc("NEWS", package="MASS")
## End(Not run)


