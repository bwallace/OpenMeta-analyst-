### Name: SHLIB
### Title: Build a DLL for Dynamic Loading
### Aliases: SHLIB
### Keywords: utilities

### ** Examples
## Not run: 
##D rcmd SHLIB -o my.dll a.f b.f -L/AMD/acml3.5.0/gnu32/lib -lacml
## End(Not run)


