### Name: sessionInfo
### Title: Collect Information About the Current R Session
### Aliases: sessionInfo toLatex.sessionInfo print.sessionInfo
### Keywords: misc

### ** Examples

sessionInfo()
toLatex(sessionInfo())



