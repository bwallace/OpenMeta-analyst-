### Name: memory.size
### Title: Report on Memory Allocation
### Aliases: memory.size memory.limit
### Keywords: utilities

### ** Examples

memory.size()
memory.size(TRUE)
memory.limit()



