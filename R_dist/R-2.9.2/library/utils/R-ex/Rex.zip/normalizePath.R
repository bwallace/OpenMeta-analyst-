### Name: normalizePath
### Title: Express File Paths in Canonical Form
### Aliases: normalizePath
### Keywords: utilities

### ** Examples

cat(normalizePath(c(R.home(), tempdir())), sep = "\n")



