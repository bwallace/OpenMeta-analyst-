### Name: shortPathName
### Title: Express File Paths in Short Form
### Aliases: shortPathName
### Keywords: utilities

### ** Examples

cat(shortPathName(c(R.home(), tempdir())), sep = "\n")



