### Name: winDialog
### Title: Dialog Boxes under Windows
### Aliases: winDialog winDialogString
### Keywords: utilities

### ** Examples

## Not run: winDialog("yesno", "Is it OK to delete file blah")



