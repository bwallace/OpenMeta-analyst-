### Name: url.show
### Title: Display a text URL
### Aliases: url.show
### Keywords: file misc

### ** Examples

## Not run: url.show("http://lib.stat.cmu.edu/datasets/csb/ch3a.txt")



