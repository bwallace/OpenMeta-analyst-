### Name: dataentry
### Title: Spreadsheet Interface for Entering Data
### Aliases: data.entry dataentry de de.ncols de.restore de.setup
### Keywords: utilities file

### ** Examples

# call data entry with variables x and y
## Not run: data.entry(x,y)



