### Name: choose.files
### Title: Choose a List of Files Interactively
### Aliases: choose.files Filters
### Keywords: file

### ** Examples

  if (interactive()) 
        choose.files(filters = Filters[c("zip", "All"),])



