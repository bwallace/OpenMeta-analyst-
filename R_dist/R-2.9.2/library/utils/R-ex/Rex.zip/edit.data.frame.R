### Name: edit.data.frame
### Title: Edit Data Frames and Matrices
### Aliases: edit.data.frame edit.matrix
### Keywords: utilities

### ** Examples

## Not run: 
##D edit(InsectSprays)
##D edit(InsectSprays, factor.mode="numeric")
## End(Not run)



