### Name: compareVersion
### Title: Compare Two Package Version Numbers
### Aliases: compareVersion
### Keywords: utilities

### ** Examples

compareVersion("1.0", "1.0-1")
compareVersion("7.2-0","7.1-12")



