### Name: Rscript
### Title: Scripting Front-End for R
### Aliases: Rscript
### Keywords: utilities

### ** Examples
## Not run: 
##D # Note that Rscript is not by default in the PATH on Windows, so
##D # either put it there or use an explicit path to Rscript.
##D 
##D # at the standard Windows command line
##D Rscript -e "date()" -e "format(Sys.time(), \"%a %b %d %X %Y\")"
##D # in other shells, e.g. bash or tcsh, prefer
##D Rscript -e 'date()' -e 'format(Sys.time(), "%a %b %d %X %Y")'
##D 
##D ## example #! script for a Unix-alike
##D 
##D #! /path/to/Rscript --vanilla --default-packages=utils
##D args <- commandArgs(TRUE)
##D res <- try(install.packages(args))
##D if(inherits(res, "try-error")) q(status=1) else q()
##D 
## End(Not run)


