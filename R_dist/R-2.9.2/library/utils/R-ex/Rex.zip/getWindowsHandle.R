### Name: getWindowsHandle
### Title: Get a Windows Handle
### Aliases: getWindowsHandle
### Keywords: utilities

### ** Examples

getWindowsHandle()



