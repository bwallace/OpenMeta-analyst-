### Name: getAnywhere
### Title: Retrieve an R Object, Including from a Name Space
### Aliases: getAnywhere argsAnywhere [.getAnywhere print.getAnywhere
### Keywords: data

### ** Examples

getAnywhere("format.dist")
getAnywhere("simpleLoess") # not exported from stats
argsAnywhere(format.dist)



