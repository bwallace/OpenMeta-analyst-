### Name: help.start
### Title: Hypertext Documentation
### Aliases: help.start
### Keywords: documentation

### ** Examples

## Not run: 
##D help.start()
##D help.start(browser="C:\\Program Files\\Internet Explorer\\IEXPLORE.EXE")
##D help.start(browser="C:/Program Files/Opera/Opera.exe")
##D help.start(browser="C:/Program Files/mozilla.org/Mozilla/mozilla.exe")
##D help.start(browser="C:/Program Files/Mozilla Firefox/firefox.exe")
## End(Not run)


