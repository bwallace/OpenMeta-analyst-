### Name: localeToCharset
### Title: Select a Suitable Encoding Name from a Locale Name
### Aliases: localeToCharset
### Keywords: utilities

### ** Examples

localeToCharset()



