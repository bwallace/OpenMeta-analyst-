### Name: setWindowTitle
### Title: Set or get the Window Title, or Set the Statusbar
### Aliases: setWindowTitle getWindowTitle getIdentification setStatusBar
### Keywords: utilities

### ** Examples

## show the current working directory in the title, saving the old one
oldtitle <- setWindowTitle(getwd())
Sys.sleep(0.5)
## reset the title
setWindowTitle("")
Sys.sleep(0.5)
## restore the original title
setWindowTitle(title = oldtitle)



