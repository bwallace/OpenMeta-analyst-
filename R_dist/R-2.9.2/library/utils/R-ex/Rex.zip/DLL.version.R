### Name: DLL.version
### Title: DLL Version Information
### Aliases: DLL.version
### Keywords: utilities

### ** Examples

DLL.version(file.path(R.home(), "bin/R.dll"))
DLL.version(file.path(R.home(), "library/stats/libs/stats.dll"))



