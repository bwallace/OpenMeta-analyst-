### Name: Rwin configuration
### Title: R for Windows Configuration
### Aliases: Rconsole Rdevga loadRconsole
### Keywords: utilities

### ** Examples

ruser <- Sys.getenv("R_USER")
cat("\n\nLocation for personal configuration files is\n   R_USER = ",
    ruser, "\n\n", sep="")
## see if there are personal configuration files
file.exists(file.path(ruser, c("Rconsole", "Rdevga")))

## show the configuration files used
showConfig <- function(file)
{
    ruser <- Sys.getenv("R_USER")
    path <- file.path(ruser, file)
    if(!file.exists(path)) path <- file.path(R.home(), "etc", file)
    file.show(path, header=path)
}
showConfig("Rconsole")



