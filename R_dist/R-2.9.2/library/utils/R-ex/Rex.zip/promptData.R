### Name: promptData
### Title: Generate a Shell for Documentation of Data Sets
### Aliases: promptData
### Keywords: documentation

### ** Examples

promptData(sunspots)
unlink("sunspots.Rd")



