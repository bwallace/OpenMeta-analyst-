### Name: alarm
### Title: Alert the user
### Aliases: alarm
### Keywords: utilities

### ** Examples

alarm()



