### Name: file.edit
### Title: Edit One or More Files
### Aliases: file.edit
### Keywords: utilities

### ** Examples

## Not run: 
##D # open two R scripts for editing
##D file.edit("script1.R", "script2.R")
## End(Not run)



