### Name: setInternet2
### Title: Set or disable the use of Internet Explorer for Internet access.
### Aliases: setInternet2
### Keywords: utilities

### ** Examples

setInternet2(NA)



