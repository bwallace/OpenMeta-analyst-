### Name: packageStatus
### Title: Package Management Tools
### Aliases: packageStatus print.packageStatus summary.packageStatus
###   update.packageStatus upgrade.packageStatus upgrade
### Keywords: utilities

### ** Examples

## Not run: 
##D x <- packageStatus()
##D print(x)
##D summary(x)
##D upgrade(x)
##D x <- update(x)
##D print(x)
## End(Not run)


