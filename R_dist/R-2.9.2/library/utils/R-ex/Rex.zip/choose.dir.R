### Name: choose.dir
### Title: Choose a Folder Interactively
### Aliases: choose.dir
### Keywords: file

### ** Examples

  if (interactive()) 
        choose.dir(getwd(), "Choose a suitable folder")



