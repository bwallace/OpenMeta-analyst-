### Name: browseURL
### Title: Load URL into a WWW Browser
### Aliases: browseURL
### Keywords: file

### ** Examples

## Not run: 
##D browseURL("http://www.r-project.org")
##D browseURL("file://d:/R/R-2.5.1/doc/html/index.html",
##D           browser="C:/Program Files/Mozilla Firefox/firefox.exe")
## End(Not run)


