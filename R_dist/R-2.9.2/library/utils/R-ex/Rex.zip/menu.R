### Name: menu
### Title: Menu Interaction Function
### Aliases: menu
### Keywords: utilities programming

### ** Examples

## Not run: 
##D switch(menu(c("List letters", "List LETTERS")) + 1,
##D        cat("Nothing done\n"), letters, LETTERS)
## End(Not run)



