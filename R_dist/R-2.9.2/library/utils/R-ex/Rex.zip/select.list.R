### Name: select.list
### Title: Select Items from a List
### Aliases: select.list
### Keywords: utilities

### ** Examples
## Not run: 
##D select.list(sort(.packages(all.available = TRUE)))
## End(Not run)


