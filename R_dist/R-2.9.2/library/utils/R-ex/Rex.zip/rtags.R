### Name: rtags
### Title: An etags-like a tagging utility for R
### Aliases: rtags
### Keywords: programming utilities

### ** Examples


## Not run: 
##D rtags("/path/to/src/repository",
##D       pattern = "[.]*\\.[RrSs]$",
##D       keep.re = "/R/",
##D       verbose = TRUE,
##D       ofile = "TAGS",
##D       append = FALSE,
##D       recursive = TRUE)
## End(Not run)




