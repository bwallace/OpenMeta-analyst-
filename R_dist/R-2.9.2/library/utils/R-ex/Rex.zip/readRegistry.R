### Name: readRegistry
### Title: Read a Windows Registy Hive
### Aliases: readRegistry
### Keywords: utilities

### ** Examples
## No test: 
readRegistry("SOFTWARE\\R-core", maxdepth = 3)
gmt <- file.path("SOFTWARE", "Microsoft", "Windows NT",
                 "CurrentVersion", "Time Zones",
                 "GMT Standard Time", fsep="\\")
readRegistry(gmt, "HLM")
## End(No test)


