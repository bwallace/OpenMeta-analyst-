### Name: vignetteDepends
### Title: Retrieve Dependency Information for a Vignette
### Aliases: vignetteDepends
### Keywords: utilities

### ** Examples

gridEx <- system.file("doc", "grid.Snw", package = "grid")
vignetteDepends(gridEx)



