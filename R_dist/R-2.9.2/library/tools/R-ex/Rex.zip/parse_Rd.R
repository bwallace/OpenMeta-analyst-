### Name: parse_Rd
### Title: Parse an Rd file
### Aliases: parse_Rd
### Keywords: utilities documentation

### ** Examples

baseRd <- Rd_db("base")
con <- textConnection(baseRd[[1]], "rt")
parse_Rd(con)
close(con)



