### Name: dependsOnPkgs
### Title: Find Reverse Dependencies
### Aliases: dependsOnPkgs
### Keywords: utilities

### ** Examples

## there are few dependencies in a vanilla R installation
dependsOnPkgs("lattice")



