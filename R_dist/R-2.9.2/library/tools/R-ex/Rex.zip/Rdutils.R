### Name: Rdutils
### Title: Rd Utilities
### Aliases: Rd_db Rd_parse
### Keywords: utilities documentation

### ** Examples

## Build the Rd db for the (installed) base package.
db <- Rd_db("base")



