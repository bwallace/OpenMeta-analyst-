### Name: getDepList
### Title: Functions to Retrieve Dependency Information
### Aliases: getDepList pkgDepends
### Keywords: utilities

### ** Examples

pkgDepends("tools", local = FALSE)



