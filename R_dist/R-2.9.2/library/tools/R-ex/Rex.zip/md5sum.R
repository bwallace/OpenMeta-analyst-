### Name: md5sum
### Title: Compute MD5 Checksums
### Aliases: md5sum
### Keywords: utilities

### ** Examples

md5sum(dir(R.home(), pattern="^COPY", full.names=TRUE))



