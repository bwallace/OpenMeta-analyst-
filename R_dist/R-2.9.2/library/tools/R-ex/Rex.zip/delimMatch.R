### Name: delimMatch
### Title: Delimited Pattern Matching
### Aliases: delimMatch
### Keywords: character

### ** Examples

x <- c("\\value{foo}", "function(bar)")
delimMatch(x)
delimMatch(x, c("(", ")"))



