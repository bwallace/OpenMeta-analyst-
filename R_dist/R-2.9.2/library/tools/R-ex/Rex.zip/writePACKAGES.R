### Name: write_PACKAGES
### Title: Generate PACKAGES files
### Aliases: write_PACKAGES
### Keywords: file utilities

### ** Examples

## Not run: 
##D write_PACKAGES("c:/myFolder/myRepository")  # on Windows
##D write_PACKAGES("/pub/RWin/bin/windows/contrib/2.1",
##D                type="win.binary")  # on Linux
## End(Not run)


