### Name: Rd2HTML
### Title: Work with an Rd object
### Aliases: Rd2txt Rd2HTML Rd2ex Rd2latex checkRd findHTMLlinks
### Keywords: documentation

### ** Examples

## No test: 
toolsRd <- Rd_db("tools")
con <- textConnection(toolsRd[[grep("Rd2HTML.Rd", names(toolsRd))]], "rt")
outfile <- paste(tempfile(), ".html", sep="")
browseURL(Rd2HTML(con, outfile, package="tools"))
close(con)
 
con <- textConnection(toolsRd[["Rd2HTML.Rd"]], "rt")
checkRd(con) # A stricter test than Rd2HTML uses
close(con)
## End(No test)



