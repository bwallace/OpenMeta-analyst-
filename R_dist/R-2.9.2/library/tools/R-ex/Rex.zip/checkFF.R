### Name: checkFF
### Title: Check Foreign Function Calls
### Aliases: checkFF print.checkFF
### Keywords: programming utilities

### ** Examples

checkFF(package = "stats", verbose = TRUE)



