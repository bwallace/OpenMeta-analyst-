### Name: xgettext
### Title: Extract Translatable Messages from R Files in a Package
### Aliases: xgettext xngettext xgettext2pot
### Keywords: utilities

### ** Examples
## Not run: 
##D ## in a source-directory build of R:
##D xgettext(file.path(R.home(), "src", "library", "splines"))
## End(Not run)


