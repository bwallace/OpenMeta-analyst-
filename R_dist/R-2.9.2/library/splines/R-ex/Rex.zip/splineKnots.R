### Name: splineKnots
### Title: Knot Vector from a Spline
### Aliases: splineKnots
### Keywords: models

### ** Examples

ispl <- interpSpline( weight ~ height, women )
splineKnots( ispl )



