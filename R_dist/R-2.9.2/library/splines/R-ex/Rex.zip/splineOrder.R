### Name: splineOrder
### Title: Determine the Order of a Spline
### Aliases: splineOrder
### Keywords: models

### ** Examples

splineOrder( interpSpline( weight ~ height, women ) )



