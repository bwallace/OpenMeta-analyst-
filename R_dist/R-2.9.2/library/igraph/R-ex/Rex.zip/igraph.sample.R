### Name: igraph.sample
### Title: Sampling a random integer sequence
### Aliases: igraph.sample
### Keywords: datagen

### ** Examples

rs <- igraph.sample(1, 100000000, 10)
rs



