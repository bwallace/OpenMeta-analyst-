### Name: communities
### Title: Common functions supporting community detection algorithms
### Aliases: communities community.to.membership
### Keywords: graphs

### ** Examples

g <- graph.full(5) %du% graph.full(5) %du% graph.full(5)
g <- add.edges(g, c(0,5, 0,10, 5, 10))
wtc <- walktrap.community(g)
community.to.membership(g, wtc$merges, steps=12)



