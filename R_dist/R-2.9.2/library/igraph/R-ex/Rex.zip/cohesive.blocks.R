### Name: cohesive.blocks
### Title: Calculate Cohesive Blocks
### Aliases: cohesive.blocks structurally.cohesive.blocks is.bgraph
### Keywords: graphs

### ** Examples

## Create a graph with an interesting structure:
g <- graph.disjoint.union(graph.full(4), graph.empty(2,directed=FALSE))
g <- add.edges(g,c(3,4,4,5,4,2))
g <- graph.disjoint.union(g,g,g)
g <- add.edges(g,c(0,6,1,7,0,12,4,0,4,1))

## Find cohesive blocks:
gBlocks <- cohesive.blocks(g)

## Examine block membership and cohesion:
gBlocks$blocks
gBlocks$block.cohesion

## Plot the resulting graph with its block hierarchy:
## Not run: 
##D plot(gBlocks, vertex.size=7, layout=layout.kamada.kawai)
## End(Not run)

## Save the results as Pajek ".net" and ".clu" files:
## Not run: 
##D write.pajek.bgraph(gBlocks,file="gBlocks")
## End(Not run)

## An example that works better with the "kanevsky" cutset algorithm
## Not run: 
##D g <- read.graph(file="http://intersci.ss.uci.edu/wiki/Vlado/SanJuanSur.net", format="pajek")
##D gBlocks <- cohesive.blocks(g, cutsetAlgorithm="kanevsky")
## End(Not run)



