### Name: graph.kautz
### Title: Kautz graphs
### Aliases: graph.kautz
### Keywords: graphs

### ** Examples

line.graph(graph.kautz(2,1))
graph.kautz(2,2)



