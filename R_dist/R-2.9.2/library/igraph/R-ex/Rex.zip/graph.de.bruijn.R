### Name: graph.de.bruijn
### Title: De Bruijn graphs.
### Aliases: graph.de.bruijn
### Keywords: graphs

### ** Examples

# de Bruijn graphs can be created recursively by line graphs as well 
g <- graph.de.bruijn(2,1)
graph.de.bruijn(2,2)
line.graph(g)



