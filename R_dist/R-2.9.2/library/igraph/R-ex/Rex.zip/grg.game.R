### Name: grg.game
### Title: Geometric random graphs
### Aliases: grg.game
### Keywords: graphs

### ** Examples

g <- grg.game(1000, 0.05, torus=FALSE)
g2 <- grg.game(1000, 0.05, torus=TRUE)



