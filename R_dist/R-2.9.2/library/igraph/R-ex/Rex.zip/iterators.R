### Name: iterators
### Title: Vertex and edge sequences and iterators
### Aliases: iterators V E V<- E<- %--% %->% %<-% [<-.igraph.es [.igraph.es
###   $<-.igraph.es $.igraph.es [<-.igraph.vs [.igraph.vs $<-.igraph.vs
###   $.igraph.vs print.igraph.es print.igraph.vs
### Keywords: graphs

### ** Examples

# mean degree of vertices in the largest cluster in a random graph
g <- erdos.renyi.game(100, 2/100)
c <- clusters(g)
vsl <- which(which.max(c$csize)-1==c$membership)-1
mean(degree(g, vsl))

# set the color of these vertices to red, others greens
V(g)$color <- "green"
V(g)[vsl]$color <- "red"
## Not run: 
##D plot(g, vertex.size=3, labels=NA, vertex.color="a:color",
##D               layout=layout.fruchterman.reingold)
## End(Not run)

# the longest geodesic within the largest cluster
long <- numeric()
for (v in vsl) {
  paths <- get.shortest.paths(g, from=v, to=vsl)
  fl <- paths[[ which.max(sapply(paths, length)) ]]
  if (length(fl) > length(long)) {
    long <- fl
  }
}

# the mode argument of the nei() function
g <- graph( c(0,1, 1,2, 1,3, 3,1) )
V(g)[ nei( c(1,3) ) ]
V(g)[ nei( c(1,3), "in") ]
V(g)[ nei( c(1,3), "out") ]

# operators for edge sequences
g <- barabasi.game(100, power=0.3)
E(g) [ 0:2 %--% 1:5 ]
E(g) [ 0:2 %->% 1:5 ]
E(g) [ 0:2 %<-% 1:5 ]

# the edges along the diameter
g <- barabasi.game(100, directed=FALSE)
d <- get.diameter(g)
E(g, path=d)



