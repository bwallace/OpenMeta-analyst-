### Name: vertex.connectivity
### Title: Vertex connectivity.
### Aliases: vertex.connectivity vertex.disjoint.paths graph.cohesion
### Keywords: graphs

### ** Examples

g <- barabasi.game(100, m=1)
g <- delete.edges(g, E(g)[ 99 %--% 0 ])
g2 <- barabasi.game(100, m=5)
g2 <- delete.edges(g2, E(g2)[ 99 %--% 0])
vertex.connectivity(g, 99, 0)
vertex.connectivity(g2, 99, 0)
vertex.disjoint.paths(g2, 99, 0)

g <- erdos.renyi.game(50, 5/50)
g <- as.directed(g)
g <- subgraph(g, subcomponent(g, 1))
graph.cohesion(g)



