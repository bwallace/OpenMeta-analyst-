### Name: preference.game
### Title: Trait-based random generation
### Aliases: preference.game asymmetric.preference.game
### Keywords: graphs

### ** Examples

pf <- matrix( c(1, 0, 0, 1), nr=2)
g <- preference.game(20, 2, pref.matrix=pf)
## Not run: tkplot(g, layout=layout.fruchterman.reingold)

pf <- matrix( c(0, 1, 0, 0), nr=2)
g <- asymmetric.preference.game(20, 2, pref.matrix=pf)
## Not run: tkplot(g, layout=layout.circle)



