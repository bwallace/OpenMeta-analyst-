### Name: barabasi.game
### Title: Generate scale-free graphs according to the Barabasi-Albert
###   model
### Aliases: barabasi.game ba.game
### Keywords: graphs

### ** Examples

g <- barabasi.game(10000)
degree.distribution(g)



