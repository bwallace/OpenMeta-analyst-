### Name: permute.vertices
### Title: Permute the vertices of a graph
### Aliases: permute.vertices
### Keywords: graphs

### ** Examples

# Random permutation of a random graph
g <- random.graph.game(20, 50, type="gnm")
g2 <- permute.vertices(g, sample(vcount(g))-1)
graph.isomorphic(g, g2)



