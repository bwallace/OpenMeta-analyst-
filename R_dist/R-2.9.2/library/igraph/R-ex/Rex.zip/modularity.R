### Name: modularity
### Title: Modularity of a community structure of a graph
### Aliases: modularity
### Keywords: graphs

### ** Examples

g <- graph.full(5) %du% graph.full(5) %du% graph.full(5)
g <- add.edges(g, c(0,5, 0,10, 5, 10))
wtc <- walktrap.community(g)
memb <- community.to.membership(g, wtc$merges, steps=12)
modularity(g, memb$membership)



