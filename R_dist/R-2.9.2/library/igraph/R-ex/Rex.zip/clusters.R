### Name: clusters
### Title: Connected components of a graph
### Aliases: no.clusters clusters is.connected cluster.distribution
### Keywords: graphs

### ** Examples

g <- erdos.renyi.game(20, 1/20)
clusters(g)



