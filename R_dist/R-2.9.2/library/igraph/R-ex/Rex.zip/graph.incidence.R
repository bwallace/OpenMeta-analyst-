### Name: graph.incidence
### Title: Create graphs from an incidence matrix
### Aliases: graph.incidence
### Keywords: graphs

### ** Examples

inc <- matrix(sample(0:1, 15, repl=TRUE), 3, 5)
colnames(inc) <- letters[1:5]
rownames(inc) <- LETTERS[1:3]
graph.incidence(inc)



