### Name: subgraph
### Title: Subgraph of a graph
### Aliases: subgraph
### Keywords: graphs

### ** Examples

g <- graph.ring(10)
g2 <- subgraph(g, 1:7)



