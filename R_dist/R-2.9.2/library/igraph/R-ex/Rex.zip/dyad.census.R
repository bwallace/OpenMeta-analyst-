### Name: dyad.census
### Title: Dyad census of a graph
### Aliases: dyad.census
### Keywords: graphs

### ** Examples

g <- ba.game(100)
dyad.census(g)



