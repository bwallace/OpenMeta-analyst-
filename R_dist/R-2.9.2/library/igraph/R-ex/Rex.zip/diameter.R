### Name: diameter
### Title: Diameter of a graph
### Aliases: diameter get.diameter farthest.nodes
### Keywords: graphs

### ** Examples

g <- graph.ring(10)
g2 <- delete.edges(g, c(0,1,0,9))
diameter(g2, unconnected=TRUE)
diameter(g2, unconnected=FALSE)



