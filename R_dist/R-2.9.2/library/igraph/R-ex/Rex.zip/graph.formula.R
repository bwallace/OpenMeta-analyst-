### Name: graph.formula
### Title: Creating (small) graphs via a simple interface
### Aliases: graph.formula
### Keywords: graphs

### ** Examples

# A simple undirected graph
g <- graph.formula( Alice-Bob-Cecil-Alice, Daniel-Cecil-Eugene, Cecil-Gordon )
g

# Another undirected graph, ":" notation
g2 <- graph.formula( Alice-Bob:Cecil:Daniel, Cecil:Daniel-Eugene:Gordon )
g2

# A directed graph
g3 <- graph.formula( Alice +-+ Bob --+ Cecil +-- Daniel,
                     Eugene --+ Gordon:Helen )
g3

# A graph with isolate vertices
g4 <- graph.formula( Alice -- Bob -- Daniel, Cecil:Gordon, Helen )
g4
V(g4)$name

# "Arrows" can be arbitrarily long
g5 <- graph.formula( Alice +---------+ Bob )
g5

# Special vertex names
g6 <- graph.formula( "+" -- "-", "*" -- "/", "%%" -- "%/%" )
g6



