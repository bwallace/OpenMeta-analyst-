### Name: topological.sort
### Title: Topological sorting of vertices in a graph
### Aliases: topological.sort
### Keywords: graphs

### ** Examples

g <- barabasi.game(100)
topological.sort(g)



