### Name: graph.bipartite
### Title: Create a bipartite graph
### Aliases: graph.bipartite
### Keywords: graphs

### ** Examples

g <- graph.bipartite( rep(0:1,length=10), c(0:9))
print(g, v=TRUE)



