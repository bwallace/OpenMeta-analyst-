### Name: leading.eigenvector.community
### Title: Community structure detecting based on the leading eigenvector
###   of the community matrix
### Aliases: leading.eigenvector.community
###   leading.eigenvector.community.step
###   leading.eigenvector.community.naive community.le.to.membership
### Keywords: graphs

### ** Examples

g <- graph.full(5) %du% graph.full(5) %du% graph.full(5)
g <- add.edges(g, c(0,5, 0,10, 5, 10))
leading.eigenvector.community(g)

lec <- leading.eigenvector.community.step(g)
lec$membership
# Try one more split
leading.eigenvector.community.step(g, fromhere=lec, community=0)
leading.eigenvector.community.step(g, fromhere=lec, community=1)



