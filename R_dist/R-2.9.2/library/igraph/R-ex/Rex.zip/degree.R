### Name: degree
### Title: Degree and degree distribution of the vertices
### Aliases: degree degree.distribution
### Keywords: graphs

### ** Examples

g <- graph.ring(10)
degree(g)
g2 <- erdos.renyi.game(1000, 10/1000)
degree.distribution(g2)



