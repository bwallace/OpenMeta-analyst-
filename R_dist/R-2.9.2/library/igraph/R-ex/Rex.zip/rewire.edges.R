### Name: rewire.edges
### Title: Rewires the endpoints of the edges of a graph randomly
### Aliases: rewire.edges
### Keywords: graphs

### ** Examples

# Some random shortcuts shorten the distances on a lattice
g <- graph.lattice( length=100, dim=1, nei=5 )
average.path.length(g)
g <- rewire.edges( g, prob=0.05 )
average.path.length(g)



