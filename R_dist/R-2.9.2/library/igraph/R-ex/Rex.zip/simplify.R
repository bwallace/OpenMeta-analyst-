### Name: simplify
### Title: Simple graphs
### Aliases: simplify is.simple
### Keywords: graphs

### ** Examples

g <- graph( c(1,2,1,2,3,3) )
is.simple(g)
is.simple(simplify(g, remove.loops=FALSE))
is.simple(simplify(g, remove.multiple=FALSE))
is.simple(simplify(g))



