### Name: plot.igraph
### Title: Plotting of graphs
### Aliases: plot.igraph
### Keywords: graphs

### ** Examples

g <- graph.ring(10)
## Not run: plot(g, layout=layout.kamada.kawai, vertex.color="green")



