### Name: graph.graphdb
### Title: Load a graph from the graph database for testing graph
###   isomorphism.
### Aliases: graph.graphdb
### Keywords: graphs

### ** Examples

## Not run: 
##D g <- graph.graphdb(prefix="iso", type="r001", nodes=20, pair="A",
##D   which=10, compressed=TRUE)
##D g2 <- graph.graphdb(prefix="iso", type="r001", nodes=20, pair="B",
##D   which=10, compressed=TRUE)
##D graph.isomorphic.vf2(g, g2)     
##D g3 <- graph.graphdb(url="http://cneurocvs.rmki.kfki.hu/graphdb/gzip/iso/bvg/b06m/iso_b06m_m200.A09.gz")
## End(Not run)


