### Name: layout
### Title: Generate coordinates for plotting graphs
### Aliases: layout layout.random layout.circle layout.sphere
###   layout.fruchterman.reingold layout.fruchterman.reingold.grid
###   layout.kamada.kawai layout.spring layout.reingold.tilford layout.lgl
###   layout.mds layout.svd layout.graphopt layout.norm
### Keywords: graphs

### ** Examples

g <- graph.ring(10)
layout.random(g)
layout.kamada.kawai(g)



