### Name: evcent
### Title: Find Eigenvector Centrality Scores of Network Positions
### Aliases: evcent
### Keywords: graphs

### ** Examples

#Generate some test data
g <- graph.ring(10, directed=FALSE)
#Compute eigenvector centrality scores
evcent(g)



