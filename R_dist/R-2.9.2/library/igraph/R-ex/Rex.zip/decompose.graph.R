### Name: decompose.graph
### Title: Decompose a graph into components
### Aliases: decompose.graph
### Keywords: graphs

### ** Examples

# the diameter of each component in a random graph
g <- erdos.renyi.game(1000, 1/1000)
comps <- decompose.graph(g, min.vertices=2)
sapply(comps, diameter)



