### Name: independent.vertex.sets
### Title: Independent vertex sets
### Aliases: independent.vertex.sets largest.independent.vertex.sets
###   maximal.independent.vertex.sets independence.number
### Keywords: graphs

### ** Examples

# A quite dense graph
g <- erdos.renyi.game(100, 0.8)
independence.number(g)
independent.vertex.sets(g, min=independence.number(g))
largest.independent.vertex.sets(g)
# Empty graph
subgraph(g, largest.independent.vertex.sets(g)[[1]])

length(maximal.independent.vertex.sets(g))



