### Name: graph.coreness
### Title: K-core decomposition of graphs
### Aliases: graph.coreness
### Keywords: graphs

### ** Examples

g <- graph.ring(10)
g <- add.edges(g, c(0,1, 1,2, 0,2))
graph.coreness(g)               



