### Name: watts.strogatz.game
### Title: The Watts-Strogatz small-world model
### Aliases: watts.strogatz.game
### Keywords: graphs

### ** Examples

g <- watts.strogatz.game(1, 100, 5, 0.05)
average.path.length(g)
transitivity(g, type="average")



