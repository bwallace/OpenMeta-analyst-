### Encoding: UTF-8

### Name: graph.famous
### Title: Creating named graphs
### Aliases: graph.famous
### Keywords: graphs

### ** Examples

solids <- list(graph.famous("Tetrahedron"),
               graph.famous("Cubical"),
               graph.famous("Octahedron"),
               graph.famous("Dodecahedron"),
               graph.famous("Icosahedron"))



