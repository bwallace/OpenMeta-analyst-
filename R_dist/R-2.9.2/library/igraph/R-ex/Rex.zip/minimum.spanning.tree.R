### Name: minimum.spanning.tree
### Title: Minimum spanning tree
### Aliases: minimum.spanning.tree
### Keywords: graphs

### ** Examples

g <- erdos.renyi.game(100, 3/100)
mst <- minimum.spanning.tree(g)



