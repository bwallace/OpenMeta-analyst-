### Name: rewire
### Title: Graph rewiring
### Aliases: rewire
### Keywords: graphs

### ** Examples

g <- graph.ring(20)
g2 <- rewire(g, niter=3)



