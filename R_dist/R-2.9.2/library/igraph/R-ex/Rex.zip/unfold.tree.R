### Name: unfold.tree
### Title: Convert a general graph into a forest
### Aliases: unfold.tree
### Keywords: graphs

### ** Examples

g <- graph.tree(10) 
V(g)$id <- seq_len(vcount(g))-1
roots <- sapply(decompose.graph(g), function(x) {
            V(x)$id[ topological.sort(x)[1]+1 ] })
tree <- unfold.tree(g, roots=roots)



