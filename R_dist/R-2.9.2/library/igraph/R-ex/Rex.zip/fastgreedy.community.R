### Name: fastgreedy.community
### Title: Community structure via greedy optimization of modularity
### Aliases: fastgreedy.community
### Keywords: graphs

### ** Examples

g <- graph.full(5) %du% graph.full(5) %du% graph.full(5)
g <- add.edges(g, c(0,5, 0,10, 5, 10))
fastgreedy.community(g)
# The highest value of modularity is before performing the last two
# merges. So this network naturally has three communities.



