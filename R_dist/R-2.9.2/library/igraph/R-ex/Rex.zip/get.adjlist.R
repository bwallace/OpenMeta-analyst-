### Name: get.adjlist
### Title: Adjacency lists
### Aliases: get.adjlist get.adjedgelist
### Keywords: graphs

### ** Examples

g <- graph.ring(10)
get.adjlist(g)
get.adjedgelist(g)



