### Name: similarity
### Title: Similarity measures of two vertices
### Aliases: similarity.jaccard similarity.dice similarity.invlogweighted
### Keywords: graphs

### ** Examples

g <- graph.ring(5)
similarity.dice(g)
similarity.jaccard(g)



