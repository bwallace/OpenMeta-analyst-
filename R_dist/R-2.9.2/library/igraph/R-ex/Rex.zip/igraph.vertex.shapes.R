### Name: Vertex shapes
### Title: Various vertex shapes when plotting igraph graphs
### Aliases: igraph.vertex.shapes
### Keywords: graphs

### ** Examples

## Not run: 
##D g <- graph.ring(10, dir=TRUE, mut=TRUE)
##D plot(g, vertex.shape="rectangle", layout=layout.circle)
## End(Not run)



