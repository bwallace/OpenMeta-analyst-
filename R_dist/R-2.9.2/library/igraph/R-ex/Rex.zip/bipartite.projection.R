### Name: bipartite.projection
### Title: Project a bipartite graph
### Aliases: bipartite.projection bipartite.projection.size
### Keywords: graphs

### ** Examples

## Projection of a full bipartite graph is a full graph
g <- graph.full.bipartite(10,5)
proj <- bipartite.projection(g)
graph.isomorphic(proj[[1]], graph.full(10))
graph.isomorphic(proj[[2]], graph.full(5))



