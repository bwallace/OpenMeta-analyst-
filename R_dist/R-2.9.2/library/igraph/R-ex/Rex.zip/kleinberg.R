### Name: kleinberg
### Title: Kleinberg's centrality scores.
### Aliases: authority.score hub.score
### Keywords: graphs

### ** Examples

## An in-star
g <- graph.star(10)
hub.score(g)$vector
authority.score(g)$vector

## A ring
g2 <- graph.ring(10)
hub.score(g2)$vector
authority.score(g2)$vector



