### Name: as.directed
### Title: Convert between directed and undirected graphs
### Aliases: as.directed as.undirected
### Keywords: graphs

### ** Examples

g <- graph.ring(10)
as.directed(g, "mutual")
g2 <- graph.star(10)
as.undirected(g)



