### Name: plot.bgraph
### Title: Plot graphs and their cohesive block hierarchy
### Aliases: plot.bgraph
### Keywords: graphs

### ** Examples

## Create a graph with an interesting structure:
g <- graph.disjoint.union(graph.full(4),graph.empty(2,directed=FALSE))
g <- add.edges(g,c(3,4,4,5,4,2))
g <- graph.disjoint.union(g,g,g)
g <- add.edges(g,c(0,6,1,7,0,12,4,0,4,1))

## Find cohesive blocks:
gBlocks <- cohesive.blocks(g)

## Plot:
## Not run: 
##D plot.bgraph(gBlocks,layout=layout.kamada.kawai)
## End(Not run)

## There are two two-cohesive blocks. To differentiate the block 
## that contains both the three- and four-cohesive sub-blocks use:
## Not run: 
##D plot(gBlocks,emph=3,layout=layout.kamada.kawai)
## End(Not run)



