### Name: transitivity
### Title: Transitivity of a graph
### Aliases: transitivity
### Keywords: graphs

### ** Examples

g <- graph.ring(10)
transitivity(g)
g2 <- erdos.renyi.game(1000, 10/1000)
transitivity(g2)   # this is about 10/1000



