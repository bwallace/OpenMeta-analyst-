### Name: graph.laplacian
### Title: Graph Laplacian
### Aliases: graph.laplacian
### Keywords: graphs

### ** Examples

g <- graph.ring(10)
graph.laplacian(g)
graph.laplacian(g, norm=TRUE)



