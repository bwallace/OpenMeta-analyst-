### Name: attributes
### Title: Graph, vertex and edge attributes
### Aliases: attributes set.graph.attribute get.graph.attribute
###   remove.graph.attribute list.graph.attributes set.vertex.attribute
###   get.vertex.attribute remove.vertex.attribute list.vertex.attributes
###   set.edge.attribute get.edge.attribute remove.edge.attribute
###   list.edge.attributes
### Keywords: graphs

### ** Examples

g <- graph.ring(10)
g <- set.graph.attribute(g, "name", "RING")
# It is the same as
g$name <- "RING"
g$name

g <- set.vertex.attribute(g, "color", value=c("red", "green"))
get.vertex.attribute(g, "color")

g <- set.edge.attribute(g, "weight", value=runif(ecount(g)))
get.edge.attribute(g, "weight")

# The following notation is more convenient

g <- graph.star(10)

V(g)$color <- c("red", "green")
V(g)$color

E(g)$weight <- runif(ecount(g))
E(g)$weight

print(g, g=TRUE, v=TRUE, e=TRUE)



