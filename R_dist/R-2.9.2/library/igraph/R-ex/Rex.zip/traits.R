### Name: traits
### Title: Graph generation based on different vertex types
### Aliases: callaway.traits.game establishment.game
### Keywords: graphs

### ** Examples

# two types of vertices, they like only themselves
g1 <- callaway.traits.game(1000, 2, pref.matrix=matrix( c(1,0,0,1), nc=2))
g2 <- establishment.game(1000, 2, k=2, pref.matrix=matrix( c(1,0,0,1), nc=2))



