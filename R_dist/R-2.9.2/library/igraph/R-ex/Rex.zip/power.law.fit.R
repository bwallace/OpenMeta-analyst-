### Name: power.law.fit
### Title: Fitting a power-law distribution function to discrete data
### Aliases: power.law.fit
### Keywords: graphs

### ** Examples

# This should approximately yield the correct exponent 3
g <- barabasi.game(1000)    # increase this number to have a better estimation
d <- degree(g, mode="in")
power.law.fit(d+1, 20)



