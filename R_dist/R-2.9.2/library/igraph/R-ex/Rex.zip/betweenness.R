### Name: betweenness
### Title: Vertex and edge betweenness centrality
### Aliases: betweenness edge.betweenness betweenness.estimate
###   edge.betweenness.estimate
### Keywords: graphs

### ** Examples

g <- random.graph.game(10, 3/10)
betweenness(g)
edge.betweenness(g)



