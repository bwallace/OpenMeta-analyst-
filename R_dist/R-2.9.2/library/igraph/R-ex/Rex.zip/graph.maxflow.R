### Name: graph.maxflow
### Title: Maximum flow in a network
### Aliases: graph.maxflow graph.mincut
### Keywords: graphs

### ** Examples

g <- graph.ring(100)
graph.mincut(g, capacity=rep(1,vcount(g)))
graph.mincut(g, value.only=FALSE, capacity=rep(1,vcount(g)))



