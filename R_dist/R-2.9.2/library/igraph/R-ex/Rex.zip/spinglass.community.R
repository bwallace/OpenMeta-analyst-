### Name: spinglass.community
### Title: Finding communities in graphs based on statistical meachanics
### Aliases: spinglass.community
### Keywords: graphs

### ** Examples

  g <- erdos.renyi.game(10, 5/10) %du% erdos.renyi.game(9, 5/9)
  g <- add.edges(g, c(0, 11))
  g <- subgraph(g, subcomponent(g, 0))
  spinglass.community(g, spins=2)
  spinglass.community(g, vertex=0)



