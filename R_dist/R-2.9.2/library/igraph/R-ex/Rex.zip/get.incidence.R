### Name: get.incidence
### Title: Incidence matrix of a bipartite graph
### Aliases: get.incidence
### Keywords: graphs

### ** Examples

g <- graph.bipartite( c(0,1,0,1,0,0), c(0,1,1,2,2,3) )
get.incidence(g)



