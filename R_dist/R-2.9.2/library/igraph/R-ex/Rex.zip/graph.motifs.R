### Name: graph-motifs
### Title: Graph motifs
### Aliases: graph.motifs graph.motifs.no graph.motifs.est
### Keywords: graphs

### ** Examples

g <- barabasi.game(100)
graph.motifs(g, 3)
graph.motifs.no(g, 3)
graph.motifs.est(g, 3)



