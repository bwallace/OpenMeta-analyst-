### Name: is.multiple
### Title: Find the multiple or loop edges in a graph
### Aliases: is.loop is.multiple count.multiple
### Keywords: graphs

### ** Examples

# Loops
g <- graph( c(0,0,1,1,2,2,3,4) )
is.loop(g)

# Multiple edges
g <- barabasi.game(10, m=3)
is.multiple(g)
count.multiple(g)
is.multiple(simplify(g))
all(count.multiple(simplify(g)) == 1)

# Direction of the edge is important
is.multiple(graph( c(0,1, 1,0) ))
is.multiple(graph( c(0,1, 1,0), dir=FALSE ))

# Remove multiple edges but keep multiplicity
g <- barabasi.game(10, m=3)
E(g)$weight <- count.multiple(g)
g <- simplify(g)
any(is.multiple(g))
E(g)$weight



