### Name: growing.random.game
### Title: Growing random graph generation
### Aliases: growing.random.game
### Keywords: graphs

### ** Examples

g <- growing.random.game(500, citation=FALSE)
g2 <- growing.random.game(500, citation=TRUE)



