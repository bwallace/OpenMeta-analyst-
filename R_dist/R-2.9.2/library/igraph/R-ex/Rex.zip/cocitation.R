### Name: cocitation
### Title: Cocitation coupling
### Aliases: cocitation bibcoupling
### Keywords: graphs

### ** Examples

g <- graph.ring(10)
cocitation(g)
bibcoupling(g)



