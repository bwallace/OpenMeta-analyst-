### Name: graph.automorphisms
### Title: Number of automorphisms
### Aliases: graph.automorphisms
### Keywords: graphs

### ** Examples

## A ring has n*2 automorphisms, you can "turn" it by 0-9 vertices
## and each of these graphs can be "flipped"
g <- graph.ring(10)
graph.automorphisms(g)



