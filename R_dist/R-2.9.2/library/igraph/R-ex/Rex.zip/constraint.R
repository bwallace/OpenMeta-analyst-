### Name: constraint
### Title: Burt's constraint
### Aliases: constraint
### Keywords: graphs

### ** Examples

g <- erdos.renyi.game(20, 5/20)
constraint(g)



