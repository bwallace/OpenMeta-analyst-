### Name: tkplot
### Title: Interactive plotting of graphs
### Aliases: tkplot tkplot.close tkplot.off tkplot.fit.to.screen
###   tkplot.reshape tkplot.export.postscript tkplot.getcoords
###   tkplot.center tkplot.rotate
### Keywords: graphs

### ** Examples

g <- graph.ring(10)
## Not run: tkplot(g)



