### Name: Graphs from adjacency lists
### Title: Create graphs from adjacency lists
### Aliases: graph.adjlist
### Keywords: graphs

### ** Examples

## Directed
g <- graph.ring(10, dir=TRUE)
al <- get.adjlist(g, mode="out")
g2 <- graph.adjlist(al)
graph.isomorphic(g, g2)

## Undirected
g <- graph.ring(10)
al <- get.adjlist(g)
g2 <- graph.adjlist(al, dir=FALSE)
graph.isomorphic(g, g2)
ecount(g2)
g3 <- graph.adjlist(al, dir=FALSE, duplicate=FALSE)
ecount(g3)
is.multiple(g3)



