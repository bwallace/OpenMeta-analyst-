### Name: igraph from/to graphNEL conversion
### Title: Convert igraph graphs to graphNEL objects or back
### Aliases: igraph.from.graphNEL igraph.to.graphNEL
### Keywords: graphs

### ** Examples

g <- graph.ring(10)
V(g)$name <- letters[1:10]
GNEL <- igraph.to.graphNEL(g)
g2 <- igraph.from.graphNEL(GNEL)
g2



