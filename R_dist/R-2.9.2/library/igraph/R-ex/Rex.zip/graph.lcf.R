### Name: graph.lcf
### Title: Creating a graph from LCF notation
### Aliases: graph.lcf
### Keywords: graphs

### ** Examples

# This is the Franklin graph:
g1 <- graph.lcf(12, c(5,-5), 6)
g2 <- graph.famous("Franklin")
graph.isomorphic.vf2(g1, g2)



