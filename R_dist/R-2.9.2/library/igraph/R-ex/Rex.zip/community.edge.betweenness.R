### Name: edge.betweenness.community
### Title: Community structure detection based on edge betweenness
### Aliases: edge.betweenness.community edge.betweenness.community.merges
### Keywords: graphs

### ** Examples

g <- barabasi.game(100,m=2)
eb <- edge.betweenness.community(g)

g <- graph.full(10) %du% graph.full(10)
g <- add.edges(g, c(0,10))
eb <- edge.betweenness.community(g)
E(g) [ eb$removed.edges[1] ]            



