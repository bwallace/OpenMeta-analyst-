### Name: structure.info
### Title: Gaining information about graph structure
### Aliases: vcount ecount neighbors is.directed are.connected get.edge
###   get.edges
### Keywords: graphs

### ** Examples

g <- graph.ring(10)
vcount(g)
ecount(g)
neighbors(g, 5)
are.connected(g, 1, 2)
are.connected(g, 2, 4)
get.edges(g, 0:5)



