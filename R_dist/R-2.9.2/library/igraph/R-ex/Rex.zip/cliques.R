### Name: cliques
### Title: The functions find cliques, ie. complete subgraphs in a graph
### Aliases: cliques largest.cliques maximal.cliques clique.number
### Keywords: graphs

### ** Examples

# this usually contains cliques of size six
g <- erdos.renyi.game(100, 0.3)
clique.number(g)
cliques(g, min=6)
largest.cliques(g)

# To have a bit less maximal cliques, about 100-200 usually
g <- erdos.renyi.game(100, 0.03)
maximal.cliques(g)




