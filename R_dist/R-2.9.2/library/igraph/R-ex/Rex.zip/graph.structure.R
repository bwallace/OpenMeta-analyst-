### Name: graph.structure
### Title: Method for structural manipulation of graphs
### Aliases: add.edges add.vertices delete.edges delete.vertices
### Keywords: graphs

### ** Examples

g <- graph.ring(10)
add.edges(g, c(1,5,2,6) )
delete.edges(g, E(g, P=c(0,9, 1,2)) )
delete.vertices(g, c(1,6,7) )



