### Name: graph-operators
### Title: Graph operators
### Aliases: graph.union graph.disjoint.union graph.intersection
###   graph.compose graph.difference graph.complementer %c% %du% %m% %s%
###   %u%
### Keywords: graphs

### ** Examples

g1 <- graph.ring(10)
g2 <- graph.star(10, mode="undirected")
graph.union(g1, g2)
graph.disjoint.union(g1, g2)
graph.intersection(g1, g2)
graph.difference(g1, g2)
graph.complementer(g2)
graph.compose(g1, g2)



