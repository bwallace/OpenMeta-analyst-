### Name: edge.connectivity
### Title: Edge connectivity.
### Aliases: edge.connectivity edge.disjoint.paths graph.adhesion
### Keywords: graphs

### ** Examples

g <- barabasi.game(100, m=1)
g2 <- barabasi.game(100, m=5)
edge.connectivity(g, 99, 0)
edge.connectivity(g2, 99, 0)
edge.disjoint.paths(g2, 99, 0)

g <- erdos.renyi.game(50, 5/50)
g <- as.directed(g)
g <- subgraph(g, subcomponent(g, 1))
graph.adhesion(g)



