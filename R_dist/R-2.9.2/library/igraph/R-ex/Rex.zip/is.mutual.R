### Name: is.mutual
### Title: Find mutual edges in a directed graph
### Aliases: is.mutual
### Keywords: graphs

### ** Examples

g <- erdos.renyi.game(10,50,type="gnm",directed=TRUE)
reciprocity(g)
dyad.census(g)
is.mutual(g)
sum(is.mutual(g))/2 == dyad.census(g)$mut



