### Name: running.mean
### Title: Running mean of a time series
### Aliases: running.mean
### Keywords: manip

### ** Examples

running.mean(1:100, 10)



