### Name: walktrap.community
### Title: Community strucure via short random walks
### Aliases: walktrap.community
### Keywords: graphs

### ** Examples

g <- graph.full(5) %du% graph.full(5) %du% graph.full(5)
g <- add.edges(g, c(0,5, 0,10, 5, 10))
walktrap.community(g)



