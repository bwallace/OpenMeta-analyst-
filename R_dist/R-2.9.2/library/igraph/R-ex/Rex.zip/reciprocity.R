### Name: reciprocity
### Title: Reciprocity of graphs
### Aliases: reciprocity
### Keywords: graphs

### ** Examples

g <- random.graph.game(20, 5/20, directed=TRUE)
reciprocity(g)



