### Name: label.propagation.community
### Title: Finding communities based on propagating labels
### Aliases: label.propagation.community
### Keywords: graphs

### ** Examples

  g <- erdos.renyi.game(10, 5/10) %du% erdos.renyi.game(9, 5/9)
  g <- add.edges(g, c(0, 11))
  label.propagation.community(g)



