### Name: graph.full.bipartite
### Title: Create a full bipartite graph
### Aliases: graph.full.bipartite
### Keywords: graphs

### ** Examples

g <- graph.full.bipartite(2, 3)
g2 <- graph.full.bipartite(2, 3, dir=TRUE)
g3 <- graph.full.bipartite(2, 3, dir=TRUE, mode="in")
g4 <- graph.full.bipartite(2, 3, dir=TRUE, mode="all")



