### Name: print.igraph
### Title: Print graphs to the terminal
### Aliases: print.igraph print.bgraph summary.igraph
### Keywords: graphs

### ** Examples

g <- graph.ring(10)
g
summary(g)



