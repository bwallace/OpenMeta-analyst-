### Name: is.igraph
### Title: Is this object a graph?
### Aliases: is.igraph
### Keywords: graphs

### ** Examples

g <- graph.ring(10)
is.igraph(g)
is.igraph(numeric(10))



