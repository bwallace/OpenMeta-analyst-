### Name: igraph-parameters
### Title: Parameters for the igraph package
### Aliases: igraph.par
### Keywords: graphs

### ** Examples

igraph.par("verbose", FALSE)
layout.kamada.kawai( graph.ring(10) )
igraph.par("verbose", TRUE)



