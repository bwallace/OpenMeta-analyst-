### Name: closeness
### Title: Closeness centrality of vertices
### Aliases: closeness closeness.estimate
### Keywords: graphs

### ** Examples

g <- graph.ring(10)
g2 <- graph.star(10)
closeness(g)
closeness(g2, mode="in")
closeness(g2, mode="out")
closeness(g2, mode="all")



