### Name: is.bipartite
### Title: Decide whether a graph is bipartite
### Aliases: is.bipartite
### Keywords: graphs

### ** Examples

## A ring has just one loop, so it is fine
g <- graph.ring(10)
is.bipartite(g)

## A star is fine, too
g2 <- graph.star(10)
is.bipartite(g2)

## A graph containing a triangle is not fine
g3 <- graph.ring(10)
g3 <- add.edges(g3, c(0,2))
is.bipartite(g3)



