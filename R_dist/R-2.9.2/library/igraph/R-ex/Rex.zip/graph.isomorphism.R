### Name: graph-isomorphism
### Title: Graph Isomorphism
### Aliases: graph.isoclass graph.isocreate graph.isomorphic
###   graph.isomorphic.vf2 graph.count.isomorphisms.vf2
###   graph.count.subisomorphisms.vf2 graph.get.isomorphisms.vf2
###   graph.get.subisomorphisms.vf2 graph.isoclass.subgraph
###   graph.isomorphic.34 graph.isomorphic.bliss graph.subisomorphic.vf2
### Keywords: graphs

### ** Examples

# create some non-isomorphic graphs
g1 <- graph.isocreate(3, 10)
g2 <- graph.isocreate(3, 11)
graph.isoclass(g1)
graph.isoclass(g2)
graph.isomorphic(g1, g2)

# create two isomorphic graphs, by
# permuting the vertices of the first 
g1 <- simplify(barabasi.game(30, m=2, directed=FALSE))
g2 <- permute.vertices(g1, sample(vcount(g1))-1)
# should be TRUE
graph.isomorphic(g1, g2)
graph.isomorphic.bliss(g1, g2)
graph.isomorphic.vf2(g1, g2)



