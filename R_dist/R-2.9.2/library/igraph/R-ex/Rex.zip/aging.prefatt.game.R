### Name: aging.prefatt.game
### Title: Generate an evolving random graph with preferential attachment
###   and aging
### Aliases: aging.prefatt.game aging.barabasi.game aging.ba.game
### Keywords: graphs

### ** Examples

# The maximum degree for graph with different aging exponents
g1 <- aging.prefatt.game(10000, pa.exp=1, aging.exp=0, aging.bin=1000)
g2 <- aging.prefatt.game(10000, pa.exp=1, aging.exp=-1,   aging.bin=1000)
g3 <- aging.prefatt.game(10000, pa.exp=1, aging.exp=-3,   aging.bin=1000)
max(degree(g1))
max(degree(g2))
max(degree(g3))



