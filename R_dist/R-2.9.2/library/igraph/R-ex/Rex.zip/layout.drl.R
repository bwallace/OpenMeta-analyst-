### Name: layout.drl
### Title: The DrL graph layout generator
### Aliases: layout.drl igraph.drl.default igraph.drl.coarsen
###   igraph.drl.coarsest igraph.drl.refine igraph.drl.final
### Keywords: graphs

### ** Examples

g <- as.undirected(ba.game(100, m=1))
l <- layout.drl(g, options=list(simmer.attraction=0))
## Not run: 
##D plot(g, layout=l, vertex.size=3, vertex.label=NA)
## End(Not run)



