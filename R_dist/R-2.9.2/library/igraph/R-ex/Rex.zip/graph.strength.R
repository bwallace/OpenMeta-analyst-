### Name: graph.strength
### Title: Strength or weighted vertex degree
### Aliases: graph.strength
### Keywords: graphs

### ** Examples

g <- graph.star(10)
E(g)$weight <- seq(ecount(g))
graph.strength(g)
graph.strength(g, mode="out")
graph.strength(g, mode="in")

# No weights, a warning is given
g <- graph.ring(10)
graph.strength(g)



