### Name: conversion
### Title: Convert a graph to an adjacency matrix or an edge list
### Aliases: get.adjacency get.edgelist
### Keywords: graphs

### ** Examples

g <- erdos.renyi.game(10, 2/10)
get.edgelist(g)
get.adjacency(g)
V(g)$name <- letters[1:vcount(g)]
get.adjacency(g)
E(g)$weight <- runif(ecount(g))
get.adjacency(g, attr="weight")



