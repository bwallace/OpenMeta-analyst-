### Name: write.graph
### Title: Writing the graph to a file in some format
### Aliases: write.graph
### Keywords: graphs

### ** Examples

g <- graph.ring(10)
## Not run: write.graph(g, "/tmp/g.txt", "edgelist")



