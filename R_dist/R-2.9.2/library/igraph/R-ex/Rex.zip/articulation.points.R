### Name: articulation.points
### Title: Articulation points of a graph
### Aliases: articulation.points
### Keywords: graphs

### ** Examples

g <- graph.disjoint.union( graph.full(5), graph.full(5) )
clu <- clusters(g)$membership
g <- add.edges(g, c(which(clu==0), which(clu==1))-1)
articulation.points(g)



