### Name: layout.merge
### Title: Merging graph layouts
### Aliases: layout.merge piecewise.layout
### Keywords: graphs

### ** Examples

# create 20 scale-free graphs and place them in a common layout
graphs <- lapply(sample(5:20, 20, replace=TRUE),
          barabasi.game, directed=FALSE)
layouts <- lapply(graphs, layout.kamada.kawai)
lay <- layout.merge(graphs, layouts)
g <- graph.disjoint.union(graphs)
## Not run: plot(g, layout=lay, vertex.size=3, labels=NA, edge.color="black")



