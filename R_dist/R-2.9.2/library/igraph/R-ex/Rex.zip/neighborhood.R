### Name: neighborhood
### Title: Neighborhood of graph vertices
### Aliases: neighborhood neighborhood.size graph.neighborhood
###   connect.neighborhood
### Keywords: graphs

### ** Examples

g <- graph.ring(10)
neighborhood.size(g, 0, 1:3)
neighborhood.size(g, 1, 1:3)
neighborhood.size(g, 2, 1:3)
neighborhood(g, 0, 1:3)
neighborhood(g, 1, 1:3)
neighborhood(g, 2, 1:3)

# attributes are preserved
V(g)$name <- c("a", "b", "c", "d", "e", "f", "g", "h", "i", "j")
graph.neighborhood(g, 2, 1:3)

# connecting to the neighborhood
g <- graph.ring(10)
g <- connect.neighborhood(g, 2)



