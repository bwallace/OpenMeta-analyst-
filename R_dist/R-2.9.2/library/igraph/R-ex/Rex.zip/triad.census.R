### Name: triad.census
### Title: Triad census, subgraphs with three vertices
### Aliases: triad.census
### Keywords: graphs

### ** Examples

g <- erdos.renyi.game(15, 45, type="gnm", dir=TRUE)
triad.census(g)



