### Name: page.rank
### Title: The Page Rank algorithm
### Aliases: page.rank page.rank.old
### Keywords: graphs

### ** Examples

g <- random.graph.game(20, 5/20, directed=TRUE)
page.rank(g)$vector

g2 <- graph.star(10)
page.rank(g2)$vector



