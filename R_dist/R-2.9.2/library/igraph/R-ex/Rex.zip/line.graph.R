### Name: line.graph
### Title: Line graph of a graph
### Aliases: line.graph
### Keywords: graphs

### ** Examples

# generate the first De-Bruijn graphs
g <- graph.full(2, directed=TRUE, loops=TRUE)
line.graph(g)
line.graph(line.graph(g))
line.graph(line.graph(line.graph(g)))



