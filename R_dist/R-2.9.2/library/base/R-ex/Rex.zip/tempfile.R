### Name: tempfile
### Title: Create Names for Temporary Files
### Aliases: tempfile tempdir
### Keywords: file

### ** Examples

tempfile(c("ab", "a b c"))   # give file name with spaces in!

tempdir() # working on all platforms with quite platform dependent result



