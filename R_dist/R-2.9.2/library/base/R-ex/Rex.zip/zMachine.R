### Name: .Machine
### Title: Numerical Characteristics of the Machine
### Aliases: .Machine
### Keywords: sysdata programming math

### ** Examples

.Machine
## or for a neat printout
noquote(unlist(format(.Machine)))



