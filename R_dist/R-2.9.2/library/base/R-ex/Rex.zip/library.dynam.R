### Name: library.dynam
### Title: Loading DLLs from Packages
### Aliases: library.dynam library.dynam.unload .dynLibs
### Keywords: data

### ** Examples

## Which DLLs were "dynamically loaded" by packages?
library.dynam() 



