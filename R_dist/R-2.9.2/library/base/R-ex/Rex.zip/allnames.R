### Name: all.names
### Title: Find All Names in an Expression
### Aliases: all.names all.vars
### Keywords: programming

### ** Examples

all.names(expression(sin(x+y)))
all.vars(expression(sin(x+y)))



