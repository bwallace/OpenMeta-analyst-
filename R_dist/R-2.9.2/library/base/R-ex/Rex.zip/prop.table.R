### Name: prop.table
### Title: Express Table Entries as Fraction of Marginal Table
### Aliases: prop.table
### Keywords: array

### ** Examples

m <- matrix(1:4,2)
m
prop.table(m,1)



