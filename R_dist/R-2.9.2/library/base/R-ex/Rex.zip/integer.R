### Name: integer
### Title: Integer Vectors
### Aliases: integer as.integer is.integer
### Keywords: classes

### ** Examples

  ## as.integer() truncates:
  x <- pi * c(-1:1,10)
  as.integer(x)



