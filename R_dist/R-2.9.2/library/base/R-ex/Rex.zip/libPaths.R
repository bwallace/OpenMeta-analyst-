### Name: libPaths
### Title: Search Paths for Packages
### Aliases: .Library .Library.site .libPaths R_LIBS R_LIBS_SITE
###   R_LIBS_USER .expand_R_libs_env_var
### Keywords: data

### ** Examples

.libPaths()                 # all library trees R knows about



