### Name: typeof
### Title: The Type of an Object
### Aliases: typeof type
### Keywords: attribute

### ** Examples

typeof(2)
mode(2)



