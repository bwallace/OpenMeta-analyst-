### Name: Sys.glob
### Title: Wildcard Expansion on File Paths
### Aliases: Sys.glob
### Keywords: utilities file

### ** Examples

## Not run: 
##D Sys.glob(file.path(R.home(), "library", "*", "R", "*.rdx"))
## End(Not run)


