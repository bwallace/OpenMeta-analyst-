### Name: args
### Title: Argument List of a Function
### Aliases: args
### Keywords: documentation

### ** Examples

args(c)
args(graphics::plot.default)



