### Name: margin.table
### Title: Compute table margin
### Aliases: margin.table
### Keywords: array

### ** Examples

m <- matrix(1:4,2)
margin.table(m,1)
margin.table(m,2)



