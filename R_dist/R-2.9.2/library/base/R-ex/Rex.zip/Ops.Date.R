### Name: Ops.Date
### Title: Operators on the Date Class
### Aliases: +.Date -.Date Ops.Date
### Keywords: utilities chron

### ** Examples

(z <- Sys.Date())
z + 10
z < c("2006-06-01", "2007-01-01", "2010-01-01")



