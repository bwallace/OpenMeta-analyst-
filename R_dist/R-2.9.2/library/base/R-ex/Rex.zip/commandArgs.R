### Name: commandArgs
### Title: Extract Command Line Arguments
### Aliases: commandArgs
### Keywords: environment sysdata programming

### ** Examples

commandArgs()
## Spawn a copy of this application as it was invoked,
## subject to shell quoting issues
## system(paste(commandArgs(), collapse=" "))



