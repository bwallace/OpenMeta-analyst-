### Name: mat.or.vec
### Title: Create a Matrix or a Vector
### Aliases: mat.or.vec
### Keywords: array

### ** Examples

mat.or.vec(3, 1)
mat.or.vec(3, 2)



