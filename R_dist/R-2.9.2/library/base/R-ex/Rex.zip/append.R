### Name: append
### Title: Vector Merging
### Aliases: append
### Keywords: manip

### ** Examples

append(1:5, 0:1, after=3)



