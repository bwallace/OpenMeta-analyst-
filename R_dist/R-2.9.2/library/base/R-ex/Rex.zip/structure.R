### Name: structure
### Title: Attribute Specification
### Aliases: structure
### Keywords: attribute manip

### ** Examples

structure(1:6, dim = 2:3)



