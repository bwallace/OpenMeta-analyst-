### Name: prod
### Title: Product of Vector Elements
### Aliases: prod
### Keywords: arith

### ** Examples

print(prod(1:7)) == print(gamma(8))



