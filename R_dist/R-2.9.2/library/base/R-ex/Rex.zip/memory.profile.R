### Name: memory.profile
### Title: Profile the Usage of Cons Cells
### Aliases: memory.profile
### Keywords: utilities

### ** Examples

memory.profile()



