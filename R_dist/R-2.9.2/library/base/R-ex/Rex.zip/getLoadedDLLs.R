### Name: getLoadedDLLs
### Title: Get DLLs Loaded in Current Session
### Aliases: getLoadedDLLs print.DLLInfo print.DLLInfoList $.DLLInfo
### Keywords: interface

### ** Examples

getLoadedDLLs()



