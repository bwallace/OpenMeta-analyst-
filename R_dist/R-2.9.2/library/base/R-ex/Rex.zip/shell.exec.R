### Name: shell.exec
### Title: Open a File or URL using Windows File Associations
### Aliases: shell.exec
### Keywords: utilities

### ** Examples
## Not run: 
##D ## the space should not be encoded here
##D shell.exec("C:\\Program Files\\BreezeSys\\BreezeBrowser\\Breezebrowser.htm")
##D shell.exec("C:/Program Files/BreezeSys/BreezeBrowser/Breezebrowser.htm")
##D shell.exec("file://C:/Program Files/BreezeSys/BreezeBrowser/Breezebrowser.htm")
## End(Not run)


