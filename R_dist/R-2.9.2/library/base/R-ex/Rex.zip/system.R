### Name: system
### Title: Invoke a System Command
### Aliases: system
### Keywords: interface file utilities

### ** Examples

# launch an editor, wait for it to quit
## Not run: system("notepad myfile.txt")
# launch your favourite shell:
## Not run: system(Sys.getenv("COMSPEC"))
## Not run: 
##D ## note the two sets of quotes here:
##D system(paste('"c:/Program Files/Mozilla Firefox/firefox.exe"',
##D              '-url cran.r-project.org'), wait = FALSE)
## End(Not run)



