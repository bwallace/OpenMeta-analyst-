### Name: ns-dblcolon
### Title: Double Colon and Triple Colon Operators
### Aliases: :: :::
### Keywords: programming

### ** Examples

base::log
base::"+"

## Beware --  use ':::' at your own risk! (see "Details")
stats:::coef.default



