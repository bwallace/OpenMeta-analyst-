### Name: charmatch
### Title: Partial String Matching
### Aliases: charmatch
### Keywords: character

### ** Examples

charmatch("", "")                             # returns 1
charmatch("m",   c("mean", "median", "mode")) # returns 0
charmatch("med", c("mean", "median", "mode")) # returns 2



