### Name: sign
### Title: Sign Function
### Aliases: sign
### Keywords: arith

### ** Examples

sign(pi) # == 1
sign(-2:3)# -1 -1 0 1 1 1



