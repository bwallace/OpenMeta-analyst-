### Name: double
### Title: Double-Precision Vectors
### Aliases: double as.double is.double single as.single as.single.default
### Keywords: classes

### ** Examples

is.double(1)
all(double(3) == 0)



