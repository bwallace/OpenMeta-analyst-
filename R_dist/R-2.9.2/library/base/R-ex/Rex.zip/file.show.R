### Name: file.show
### Title: Display One or More Files
### Aliases: file.show
### Keywords: file

### ** Examples

file.show(file.path(R.home("doc"), "COPYRIGHTS"))



