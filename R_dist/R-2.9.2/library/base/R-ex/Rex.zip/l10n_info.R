### Name: l10n_info
### Title: Localization Information
### Aliases: l10n_info
### Keywords: utilities

### ** Examples

l10n_info()



