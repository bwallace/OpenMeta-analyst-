### Name: search
### Title: Give Search Path for R Objects
### Aliases: search searchpaths
### Keywords: data

### ** Examples

search()
searchpaths()



