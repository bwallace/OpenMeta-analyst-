### Name: gc.time
### Title: Report Time Spent in Garbage Collection
### Aliases: gc.time
### Keywords: utilities

### ** Examples

gc.time()



