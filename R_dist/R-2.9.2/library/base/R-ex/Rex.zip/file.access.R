### Name: file.access
### Title: Ascertain File Accessibility
### Aliases: file.access
### Keywords: file

### ** Examples

fa <- file.access(dir("."))
table(fa) # count successes & failures
d <- dir(file.path(R.home(), "bin"))
df <- dir(file.path(R.home(), "bin"), full.names = TRUE)
d[file.access(df, 0) == 0] # all exist
d[file.access(df, 1) == 0] # some are executable, some are not
d[file.access(df, 2) == 0] # hopefully all are readable
d[file.access(df, 4) == 0] # they may or may not be writable



