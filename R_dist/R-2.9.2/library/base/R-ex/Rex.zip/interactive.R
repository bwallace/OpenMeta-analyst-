### Name: interactive
### Title: Is R Running Interactively?
### Aliases: interactive
### Keywords: environment programming

### ** Examples

 .First <- function() if(interactive()) x11()



