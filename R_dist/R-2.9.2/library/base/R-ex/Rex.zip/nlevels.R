### Name: nlevels
### Title: The Number of Levels of a Factor
### Aliases: nlevels
### Keywords: category

### ** Examples

nlevels(gl(3,7)) # = 3



