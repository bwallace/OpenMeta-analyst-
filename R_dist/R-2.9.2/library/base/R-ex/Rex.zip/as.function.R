### Name: as.function
### Title: Convert Object to Function
### Aliases: as.function as.function.default
### Keywords: programming

### ** Examples

as.function(alist(a=,b=2,a+b))
as.function(alist(a=,b=2,a+b))(3)



