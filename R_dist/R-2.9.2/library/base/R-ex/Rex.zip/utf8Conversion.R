### Name: utf8Conversion
### Title: Convert to or from UTF-8-encoded Character Vectors
### Aliases: utf8ToInt intToUtf8
### Keywords: character utilities

### ** Examples
## Not run: 
##D ## will only display in some locales and fonts
##D intToUtf8(0x03B2L) # Greek beta
## End(Not run)


