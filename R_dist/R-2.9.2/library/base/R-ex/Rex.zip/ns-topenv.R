### Name: ns-topenv
### Title: Top Level Environment
### Aliases: topenv
### Keywords: programming

### ** Examples

topenv(.GlobalEnv)
topenv(new.env())



