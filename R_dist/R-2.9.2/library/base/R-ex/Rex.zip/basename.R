### Name: basename
### Title: Manipulate File Paths
### Aliases: basename dirname
### Keywords: file

### ** Examples

basename(file.path("","p1","p2","p3", c("file1", "file2")))
dirname(file.path("","p1","p2","p3","filename"))



