### Name: paste
### Title: Concatenate Strings
### Aliases: paste
### Keywords: character

### ** Examples

paste(1:12) # same as as.character(1:12)
paste("A", 1:6, sep = "")
paste("Today is", date())



