### Name: files
### Title: File Manipulation
### Aliases: files file.append file.copy file.create file.exists file.rcopy
###   file.remove file.rename file.symlink
### Keywords: file

### ** Examples

cat("file A\n", file="A")
cat("file B\n", file="B")
file.append("A", "B")
file.create("A")
file.append("A", rep("B", 10))
if(interactive()) file.show("A")
file.copy("A", "C")
dir.create("tmp")
file.copy(c("A", "B"), "tmp")
list.files("tmp")
unlink("tmp", recursive=TRUE)
file.remove("A", "B", "C")



