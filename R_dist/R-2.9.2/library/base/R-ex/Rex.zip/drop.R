### Name: drop
### Title: Drop Redundant Extent Information
### Aliases: drop
### Keywords: array

### ** Examples

dim(drop(array(1:12, dim=c(1,3,1,1,2,1,2))))# = 3 2 2
drop(1:3 %*% 2:4)# scalar product



