### Name: getCallingDLL
### Title: Compute DLL for Native Interface Call
### Aliases: getCallingDLL getCallingDLLe
### Keywords: internal

### ** Examples

if(exists("ansari.test"))
   getCallingDLL(ansari.test)



