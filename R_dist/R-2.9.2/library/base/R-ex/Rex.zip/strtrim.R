### Name: strtrim
### Title: Trim Character Strings to Specified Widths
### Aliases: strtrim
### Keywords: character utilities

### ** Examples

strtrim(c("abcdef", "abcdef", "abcdef"), c(1,5,10))



