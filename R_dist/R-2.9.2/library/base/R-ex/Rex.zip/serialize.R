### Name: serialize
### Title: Simple Serialization Interface
### Aliases: serialize unserialize
### Keywords: file connection

### ** Examples

x <- serialize(list(1,2,3), NULL)
unserialize(x)



