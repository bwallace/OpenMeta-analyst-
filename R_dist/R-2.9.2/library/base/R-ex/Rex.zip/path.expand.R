### Name: path.expand
### Title: Expand File Paths
### Aliases: path.expand
### Keywords: file

### ** Examples

path.expand("~/foo")



