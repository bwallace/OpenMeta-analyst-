### Name: Arithmetic
### Title: Arithmetic Operators
### Aliases: + - * ** / ^ %% %/% Arithmetic
### Keywords: arith

### ** Examples

x <- -1:12
x + 1
2 * x + 3
x %% 2 #-- is periodic
x %/% 5



