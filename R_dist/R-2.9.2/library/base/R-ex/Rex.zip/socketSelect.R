### Name: socketSelect
### Title: Wait on Socket Connections
### Aliases: socketSelect
### Keywords: connection

### ** Examples

## Not run: 
##D ## test whether socket connection s is available for writing or reading
##D socketSelect(list(s,s),c(TRUE,FALSE),timeout=0)
## End(Not run)



