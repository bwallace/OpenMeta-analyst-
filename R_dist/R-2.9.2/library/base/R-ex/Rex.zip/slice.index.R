### Name: slice.index
### Title: Slice Indexes in an Array
### Aliases: slice.index
### Keywords: array

### ** Examples

x <- array(1 : 24, c(2, 3, 4))
slice.index(x, 2)



