### Name: attr
### Title: Object Attributes
### Aliases: attr attr<-
### Keywords: attribute

### ** Examples

# create a 2 by 5 matrix
x <- 1:10
attr(x,"dim") <- c(2, 5)



