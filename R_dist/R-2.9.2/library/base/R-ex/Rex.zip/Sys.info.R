### Name: Sys.info
### Title: Extract System and User Information
### Aliases: Sys.info
### Keywords: utilities

### ** Examples

Sys.info()
## An alternative (and probably better) way to get the login name on Unix
Sys.getenv("LOGNAME")



