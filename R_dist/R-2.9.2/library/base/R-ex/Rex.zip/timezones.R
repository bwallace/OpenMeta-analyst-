### Name: timezones
### Title: Time Zones
### Aliases: Sys.timezone timezone 'time zone' 'time zones' TZ TZDIR
### Keywords: utilities chron

### ** Examples

Sys.timezone()



