### Name: sequence
### Title: Create A Vector of Sequences
### Aliases: sequence
### Keywords: manip

### ** Examples

sequence(c(3,2))# the concatenated sequences 1:3 and 1:2.
#> [1] 1 2 3 1 2



