### Name: is.object
### Title: Is an Object ``internally classed''?
### Aliases: is.object
### Keywords: methods classes

### ** Examples

is.object(1) # FALSE
is.object(as.factor(1:3)) # TRUE



