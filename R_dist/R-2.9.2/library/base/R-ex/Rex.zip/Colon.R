### Name: Colon
### Title: Colon Operator
### Aliases: : colon
### Keywords: manip

### ** Examples

1:4
pi:6 # real
6:pi # integer

f1 <- gl(2,3); f1
f2 <- gl(3,2); f2
f1:f2 # a factor, the "cross"  f1 x f2



