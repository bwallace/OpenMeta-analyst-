### Name: plotcircle
### Title: adds part of a colored circle to a plot
### Aliases: plotcircle
### Keywords: aplot

### ** Examples

  emptyplot(c(0,1),c(0,2),main="plotcircle")
  plotcircle(mid=c(0.5,0.5),r=0.25,from=0,to=3*pi/2,
             arrow=TRUE,arr.pos=0.5,col="red")



