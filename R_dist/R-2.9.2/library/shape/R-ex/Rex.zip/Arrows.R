### Name: Arrows
### Title: adds arrows with improved arrowhead to a plot
### Aliases: Arrows
### Keywords: aplot

### ** Examples

  xlim <- c(-5 ,5)
  ylim <- c(-10,10)
  plot(0,type="n",xlim=xlim,ylim=ylim,main="Arrows")
  x0<-runif(100,xlim[1],xlim[2])
  y0<-runif(100,ylim[1],ylim[2])
  x1<-x0+runif(100,-1,1)
  y1<-y0+runif(100,-1,1)
  Arrows(x0,y0,x1,y1,arr.length=runif(100),code=2,arr.type="curved",
         arr.col=1:100,lcol=1:100)
  
  plot(0,type="n",xlim=xlim,ylim=ylim,main="Arrows")
  x0<-runif(100,xlim[1],xlim[2])
  y0<-runif(100,ylim[1],ylim[2])
  x1<-x0+runif(100,-1,1)
  y1<-y0+runif(100,-1,1)
  Arrows(x0,y0,x1,y1,arr.length=0.2,code=3,arr.type="circle",
         arr.col="grey")
  
  curve(expr=sin(x),0,2*pi+0.25,main="Arrows")
  x  <- seq(0,2*pi,length.out=10)
  xd <- x+0.025
  Arrows(x,sin(x),xd,sin(xd),type="triangle",arr.length=0.5,segment=FALSE)
  
  xx <- seq(0,10*pi,length.out=1000)
  plot(sin(xx)*xx,cos(xx)*xx,type="l",axes=FALSE,xlab="",ylab="",main="Arrows")
  x  <- seq(0,10*pi,length.out=20)
  x1 <- sin(x)*x
  y1 <- cos(x)*x
  xd <- x+0.01
  x2 <- sin(xd)*xd
  y2 <- cos(xd)*xd
  Arrows(x1,y1,x2,y2,arr.type="curved",arr.length=0.4,segment=FALSE,
         code=1,arr.adj=0.5 )



