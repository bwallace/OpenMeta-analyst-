### Name: testInheritedMethods
### Title: Test for and Report about Selection of Inherited Methods
### Aliases: testInheritedMethods MethodSelectionReport-class .Other-class
### Keywords: programming classes methods

### ** Examples

## if no other attached  packages have methods for `+` or its group generic 
## functions, this returns a 16 by 2 matrix of selection patterns (in R 2.9.0)
 testInheritedMethods("+")



