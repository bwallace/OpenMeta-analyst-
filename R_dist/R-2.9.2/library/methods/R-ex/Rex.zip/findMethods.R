### Name: findMethods
### Title: Descriptions of the Methods Defined for a Generic Function
### Aliases: findMethods findMethodSignatures hasMethods getMethods
### Keywords: programming classes methods

### ** Examples

mm <-  findMethods("Ops")
findMethodSignatures(methods = mm)



