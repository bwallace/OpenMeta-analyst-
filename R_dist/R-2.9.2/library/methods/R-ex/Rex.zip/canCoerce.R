### Name: canCoerce
### Title: Can an Object be Coerced to a Certain S4 Class?
### Aliases: canCoerce
### Keywords: classes methods

### ** Examples

m <- matrix(pi, 2,3)
canCoerce(m, "numeric") # TRUE
canCoerce(m, "array")   # TRUE



