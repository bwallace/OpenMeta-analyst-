### Name: permute
### Title: Randomly Permute the Elements of a Vector
### Aliases: permute
### Keywords: distribution

### ** Examples

  x <- 1:10
  permute(x)



