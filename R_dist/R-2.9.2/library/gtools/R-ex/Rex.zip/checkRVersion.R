### Name: checkRVersion
### Title: Check if a newer version of R is available
### Aliases: checkRVersion
### Keywords: utilities

### ** Examples


checkRVersion()

ver <- checkRVersion()
print(ver)




