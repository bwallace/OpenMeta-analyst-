### Name: odd
### Title: Detect odd/even integers
### Aliases: odd even
### Keywords: arith

### ** Examples


odd(4)
even(4)

odd(1:10)
even(1:10)




