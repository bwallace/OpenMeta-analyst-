### Name: cement
### Title: Heat Evolved by Setting Cements
### Aliases: cement
### Keywords: datasets

### ** Examples

lm(y ~ x1 + x2 + x3 + x4, cement)



