### Name: area
### Title: Adaptive Numerical Integration
### Aliases: area
### Keywords: nonlinear

### ** Examples

area(sin, 0, pi)  # integrate the sin function from 0 to pi.



