### Name: bcv
### Title: Biased Cross-Validation for Bandwidth Selection
### Aliases: bcv
### Keywords: dplot

### ** Examples

bcv(geyser$duration)



