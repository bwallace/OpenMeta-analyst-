### Name: width.SJ
### Title: Bandwidth Selection by Pilot Estimation of Derivatives
### Aliases: width.SJ
### Keywords: dplot

### ** Examples

attach(geyser)
width.SJ(duration, method = "dpi")
width.SJ(duration)
detach()

width.SJ(galaxies, method = "dpi")
width.SJ(galaxies)



