### Name: ucv
### Title: Unbiased Cross-Validation for Bandwidth Selection
### Aliases: ucv
### Keywords: dplot

### ** Examples

ucv(geyser$duration)



