### Name: contr.sdif
### Title: Successive Differences Contrast Coding
### Aliases: contr.sdif
### Keywords: models

### ** Examples

contr.sdif(6)



