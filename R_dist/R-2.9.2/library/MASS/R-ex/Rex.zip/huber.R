### Name: huber
### Title: Huber M-estimator of Location with MAD Scale
### Aliases: huber
### Keywords: robust

### ** Examples

huber(chem)



