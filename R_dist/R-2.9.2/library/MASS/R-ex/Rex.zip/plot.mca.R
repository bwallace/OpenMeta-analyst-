### Name: plot.mca
### Title: Plot Method for Objects of Class 'mca'
### Aliases: plot.mca
### Keywords: hplot multivariate

### ** Examples

plot(mca(farms, abbrev = TRUE))



