### Name: waders
### Title: Counts of Waders at 15 Sites in South Africa
### Aliases: waders
### Keywords: datasets

### ** Examples

plot(corresp(waders, nf=2))



