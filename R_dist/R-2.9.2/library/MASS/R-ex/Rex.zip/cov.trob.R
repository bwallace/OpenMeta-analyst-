### Name: cov.trob
### Title: Covariance Estimation for Multivariate t Distribution
### Aliases: cov.trob
### Keywords: multivariate

### ** Examples

cov.trob(stackloss)



