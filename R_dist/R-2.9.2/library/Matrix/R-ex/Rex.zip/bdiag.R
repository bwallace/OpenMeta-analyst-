### Name: bdiag
### Title: Construct a Block Diagonal Matrix
### Aliases: bdiag
### Keywords: array

### ** Examples

bdiag(matrix(1:4, 2), diag(3))
## combine "Matrix" class and traditional matrices:
bdiag(Diagonal(2), matrix(1:3, 3,4), diag(3:2))

mlist <- list(1, 2:3, diag(x=5:3), 27, cbind(1,3:6), 100:101)
bdiag(mlist)

stopifnot(identical(bdiag(mlist), 
                    bdiag(lapply(mlist, as.matrix))))



