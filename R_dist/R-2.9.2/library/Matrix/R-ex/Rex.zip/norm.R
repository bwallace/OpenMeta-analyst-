### Name: norm
### Title: Matrix Norms
### Aliases: norm norm,ANY,missing-method norm,matrix,character-method
###   norm,Matrix,character-method
### Keywords: algebra

### ** Examples

x <- Hilbert(9)
norm(x, "1")
norm(x, "I")
norm(x, "F")
norm(x, "M")



