### Name: sparseLU-class
### Title: Sparse LU decomposition of a square sparse matrix
### Aliases: sparseLU-class expand,sparseLU-method
### Keywords: classes

### ** Examples

  ## see  examples(lu)



