### Name: BunchKaufman-methods
### Title: Bunch-Kaufman Decomposition Methods
### Aliases: BunchKaufman BunchKaufman-methods
###   BunchKaufman,dspMatrix-method BunchKaufman,dsyMatrix-method
### Keywords: methods

### ** Examples

data(CAex)
dim(CAex)
isSymmetric(CAex)# TRUE
CAs <- as(CAex, "symmetricMatrix")
if(FALSE) # no method defined yet for *sparse* :
   bk. <- BunchKaufman(CAs)
## does apply to *dense* symmetric matrices:
bkCA <- BunchKaufman(as(CAs, "denseMatrix"))
bkCA



