### Name: Unused-classes
### Title: Virtual Classes Not Yet Really Implemented and Used
### Aliases: iMatrix-class zMatrix-class
### Keywords: classes

### ** Examples

showClass("iMatrix")
showClass("zMatrix")



