### Name: ddenseMatrix-class
### Title: Virtual Class "ddenseMatrix" of Numeric Dense Matrices
### Aliases: ddenseMatrix-class %*%,ddenseMatrix,ddenseMatrix-method
###   show,ddenseMatrix-method coerce,ddenseMatrix,matrix-method
###   coerce,ddenseMatrix,dgeMatrix-method
###   coerce,ddenseMatrix,CsparseMatrix-method
###   Arith,ddenseMatrix,ddenseMatrix-method
###   Arith,ddenseMatrix,numeric-method Arith,numeric,ddenseMatrix-method
###   Math,ddenseMatrix-method Summary,ddenseMatrix-method
###   as.numeric,ddenseMatrix-method crossprod,ddenseMatrix,missing-method
###   diag,ddenseMatrix-method determinant,ddenseMatrix,missing-method
###   determinant,ddenseMatrix,logical-method lu,ddenseMatrix-method
###   norm,ddenseMatrix,missing-method norm,ddenseMatrix,character-method
###   rcond,ddenseMatrix,missing-method rcond,ddenseMatrix,character-method
###   solve,ddenseMatrix,missing-method solve,ddenseMatrix,ANY-method
###   t,ddenseMatrix-method tcrossprod,ddenseMatrix,missing-method
### Keywords: classes

### ** Examples

showClass("ddenseMatrix")

showMethods(class = "ddenseMatrix", where = "package:Matrix")



