### Name: image-methods
### Title: Methods for image() in Package 'Matrix'
### Aliases: image-methods image,ANY-method image,CHMfactor-method
###   image,Matrix-method image,dgRMatrix-method image,dgCMatrix-method
###   image,dgTMatrix-method image,dsparseMatrix-method
###   image,lsparseMatrix-method image,nsparseMatrix-method
### Keywords: methods hplot

### ** Examples

showMethods(image)
## If you want to see all the methods' implementations:
showMethods(image, incl=TRUE, inherit=FALSE)

data(CAex)
image(CAex, main = "image(CAex)")
image(CAex, useAbs=TRUE, main = "image(CAex, useAbs=TRUE)")

cCA <- Cholesky(crossprod(CAex), Imult = .01)
image(cCA, main="Cholesky(crossprod(CAex), Imult = .01)")
image(cCA, useAbs=TRUE)

data(USCounties)
image(USCounties)# huge
image(sign(USCounties))## just the pattern
    # how the result looks, may depend heavily on
    # the device, screen resolution, antialiasing etc
    # e.g. x11(type="Xlib") may show very differently than cairo-based

## Drawing borders around each rectangle;
    # again, viewing depends very much on the device:
image(USCounties[1:400,1:200], lwd=.1)
image(USCounties[1:200,1:200], lwd=.5)
image(USCounties[1:200,1:200], lwd=.01)



