### Name: Hilbert
### Title: Generate a Hilbert matrix
### Aliases: Hilbert
### Keywords: array algebra

### ** Examples

Hilbert(6)



