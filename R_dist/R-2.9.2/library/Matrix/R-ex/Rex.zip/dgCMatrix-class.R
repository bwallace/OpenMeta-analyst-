### Name: dgCMatrix-class
### Title: Compressed, sparse, column-oriented numeric matrices
### Aliases: dgCMatrix-class %*%,dgCMatrix,dgeMatrix-method
###   %*%,dgCMatrix,matrix-method %*%,numeric,dgCMatrix-method
###   %*%,ddenseMatrix,dgCMatrix-method %*%,dgeMatrix,dgCMatrix-method
###   %*%,matrix,dgCMatrix-method coerce,matrix,dgCMatrix-method
###   coerce,dgeMatrix,dgCMatrix-method coerce,dgCMatrix,dgTMatrix-method
###   coerce,dgCMatrix,dsCMatrix-method coerce,dgCMatrix,dtCMatrix-method
###   coerce,dgCMatrix,lgCMatrix-method coerce,dgCMatrix,ngCMatrix-method
###   coerce,dgCMatrix,matrix-method coerce,dgCMatrix,dgeMatrix-method
###   coerce,factor,dgCMatrix-method crossprod,dgCMatrix,missing-method
###   crossprod,dgCMatrix,matrix-method
###   crossprod,dgCMatrix,dgeMatrix-method diag,dgCMatrix-method
###   dim,dgCMatrix-method lu,dgCMatrix-method t,dgCMatrix-method
###   solve,dgCMatrix,matrix-method solve,dgCMatrix,missing-method
###   solve,dgCMatrix,ddenseMatrix-method
###   solve,dgCMatrix,dsparseMatrix-method Arith,numeric,dgCMatrix-method
###   Arith,dgCMatrix,numeric-method Arith,dgCMatrix,dgCMatrix-method
###   Math,dgCMatrix-method round,dgCMatrix,numeric-method
###   signif,dgCMatrix,numeric-method log,dgCMatrix-method
###   gamma,dgCMatrix-method lgamma,dgCMatrix-method
### Keywords: classes algebra

### ** Examples

(m <- Matrix(c(0,0,2:0), 3,5))
str(m)
m[,1]
## Don't show: 
## regression test: this must give a validity-check error:
stopifnot(inherits(try(new("dgCMatrix", i = 0:1, p = 0:2,
                           x = c(2,3), Dim = 3:4)),
          "try-error"))
## End Don't show



