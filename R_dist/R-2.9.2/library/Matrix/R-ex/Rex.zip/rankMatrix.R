### Name: rankMatrix
### Title: Rank of a Matrix
### Aliases: rankMatrix
### Keywords: algebra array

### ** Examples

rankMatrix(cbind(1, 0, 1:3)) # 2

(meths <- eval(formals(rankMatrix)$method))

## a "border" case:
H12 <- Hilbert(12)
rankMatrix(H12, tol = 1e-20) # 12;  but  11  with default method & tol.
sapply(meths, function(.m.) rankMatrix(H12, method = .m.))
## tolNorm2 qrLINPACK   useGrad maybeGrad
##       11        12        11        11



