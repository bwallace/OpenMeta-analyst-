### Name: replValue-class
### Title: Virtual Class "replValue" - Simple Class for subassignment
###   Values
### Aliases: replValue-class
### Keywords: classes

### ** Examples

showClass("replValue")



