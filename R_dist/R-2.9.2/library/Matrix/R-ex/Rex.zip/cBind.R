### Name: cBind
### Title: Versions of 'cbind' and 'rbind' recursively built on
###   cbind2/rbind2
### Aliases: cBind rBind
### Keywords: array manip

### ** Examples

(a <- matrix(c(2:1,1:2), 2,2))
cbind(0, rBind(a, 7)) # remains traditional matrix

D <- Diagonal(2)
cBind(4, a, D, -1, D, 0) # a sparse Matrix



