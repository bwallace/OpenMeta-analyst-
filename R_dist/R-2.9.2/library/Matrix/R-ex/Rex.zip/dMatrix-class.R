### Name: dMatrix-class
### Title: (Virtual) Class "dMatrix" of "double" Matrices
### Aliases: dMatrix-class lMatrix-class show,dMatrix-method
###   coerce,dMatrix,lMatrix-method coerce,lMatrix,dMatrix-method
###   coerce,lMatrix,dgCMatrix-method coerce,matrix,lMatrix-method
###   [,dMatrix,lMatrix,missing,ANY-method
###   [,dMatrix,logical,missing,ANY-method Arith,dMatrix,dMatrix-method
###   Arith,lMatrix,numeric-method Ops,lMatrix,numeric-method
###   Arith,numeric,lMatrix-method Ops,numeric,lMatrix-method
###   Ops,dMatrix,dMatrix-method Ops,dMatrix,lMatrix-method
###   Ops,lMatrix,dMatrix-method Ops,lMatrix,lMatrix-method
###   Ops,dMatrix,nMatrix-method Ops,nMatrix,dMatrix-method
###   Compare,dMatrix,numeric-method Compare,numeric,dMatrix-method
###   Logic,logical,lMatrix-method Logic,lMatrix,logical-method
###   Summary,lMatrix-method Math2,dMatrix-method log,dMatrix-method
###   gamma,dMatrix-method lgamma,dMatrix-method zapsmall,dMatrix-method
###   crossprod,dMatrix,integer-method crossprod,integer,dMatrix-method
###   solve,dMatrix,integer-method %*%,dMatrix,integer-method
###   %*%,integer,dMatrix-method
### Keywords: classes algebra

### ** Examples

 showClass("dMatrix")

 set.seed(101)
 round(Matrix(rnorm(28), 4,7), 2)
 (M <- zapsmall(Matrix(rlnorm(56, sd=10), 4,14)))
 table(as.logical(M == 0))



