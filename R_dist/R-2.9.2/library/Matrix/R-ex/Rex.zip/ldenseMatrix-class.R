### Name: ldenseMatrix-class
### Title: Virtual Class "ldenseMatrix" of Dense Logical Matrices
### Aliases: ldenseMatrix-class !,ldenseMatrix-method
###   Ops,ldenseMatrix,ldenseMatrix-method
###   Logic,ldenseMatrix,lsparseMatrix-method
###   Logic,lsparseMatrix,ldenseMatrix-method
###   as.logical,ldenseMatrix-method as.vector,ldenseMatrix,missing-method
###   coerce,matrix,ldenseMatrix-method coerce,ldenseMatrix,matrix-method
###   diag,ldenseMatrix-method norm,ldenseMatrix,character-method
### Keywords: classes

### ** Examples

showClass("ldenseMatrix")

as(diag(3) > 0, "ldenseMatrix")



