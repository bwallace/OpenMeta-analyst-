### Name: dtpMatrix-class
### Title: Packed triangular dense matrices
### Aliases: dtpMatrix-class %*%,dtpMatrix,ddenseMatrix-method
###   %*%,dgeMatrix,dtpMatrix-method %*%,dtpMatrix,matrix-method
###   %*%,matrix,dtpMatrix-method coerce,dtpMatrix,dtTMatrix-method
###   coerce,dtpMatrix,dtrMatrix-method coerce,dtpMatrix,ltpMatrix-method
###   coerce,dtpMatrix,matrix-method coerce,matrix,dtpMatrix-method
###   determinant,dtpMatrix,missing-method
###   determinant,dtpMatrix,logical-method diag,dtpMatrix-method
###   norm,dtpMatrix,character-method norm,dtpMatrix,missing-method
###   rcond,dtpMatrix,character-method rcond,dtpMatrix,missing-method
###   solve,dtpMatrix,missing-method solve,dtpMatrix,matrix-method
###   solve,dtpMatrix,ddenseMatrix-method t,dtpMatrix-method
###   unpack,dtpMatrix-method
### Keywords: classes

### ** Examples

showClass("dtrMatrix")

example("dtrMatrix-class")
(p1 <- as(T2, "dtpMatrix"))
str(p1)
(pp <- as(T, "dtpMatrix"))
stopifnot(length(p1@x) == 3, length(pp@x) == 3,
          p1 @ uplo == T2 @ uplo, pp @ uplo == T @ uplo)



