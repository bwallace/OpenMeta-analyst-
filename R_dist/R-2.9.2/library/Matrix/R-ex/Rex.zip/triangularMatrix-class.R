### Name: triangularMatrix-class
### Title: Virtual Class of Triangular Matrices in package:Matrix
### Aliases: triangularMatrix-class
###   coerce,triangularMatrix,symmetricMatrix-method
###   coerce,lgeMatrix,triangularMatrix-method
###   coerce,ngeMatrix,triangularMatrix-method
### Keywords: classes

### ** Examples

showClass("triangularMatrix")

## The names of direct subclasses:
scl <- getClass("triangularMatrix")@subclasses
directly <- sapply(lapply(scl, slot, "by"), length) == 0
names(scl)[directly]



