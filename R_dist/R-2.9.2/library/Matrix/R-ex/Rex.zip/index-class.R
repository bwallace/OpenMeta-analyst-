### Name: index-class
### Title: Virtual Class "index" - Simple Class for Matrix Indices
### Aliases: index-class
### Keywords: classes

### ** Examples

showClass("index")



