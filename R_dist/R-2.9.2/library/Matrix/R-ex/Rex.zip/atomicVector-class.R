### Name: atomicVector-class
### Title: Virtual Class "atomicVector" of Atomic Vectors
### Aliases: atomicVector-class
### Keywords: classes

### ** Examples

showClass("atomicVector")



