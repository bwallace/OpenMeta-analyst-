### Name: sparseVector-class
### Title: Sparse Vector Classes
### Aliases: sparseVector-class dsparseVector-class isparseVector-class
###   lsparseVector-class nsparseVector-class zsparseVector-class
###   xsparseVector-class Arith,sparseVector,sparseVector-method
###   Arith,dsparseVector,dsparseVector-method
###   -,dsparseVector,missing-method Logic,sparseVector,sparseVector-method
###   Logic,lsparseVector,lsparseVector-method Ops,ANY,sparseVector-method
###   Ops,sparseVector,ANY-method Ops,sparseVector,atomicVector-method
###   Ops,atomicVector,sparseVector-method coerce,ANY,sparseVector-method
###   coerce,TsparseMatrix,sparseVector-method
###   coerce,diagonalMatrix,sparseVector-method
###   coerce,sparseMatrix,sparseVector-method
###   coerce,atomicVector,sparseVector-method
###   coerce,atomicVector,dsparseVector-method
###   coerce,triangularVector,sparseVector-method
###   coerce,sparseVector,vector-method
###   coerce,xsparseVector,dsparseVector-method
###   coerce,xsparseVector,isparseVector-method
###   coerce,xsparseVector,lsparseVector-method
###   coerce,xsparseVector,zsparseVector-method
###   coerce,xsparseVector,nsparseVector-method
###   as.numeric,sparseVector-method as.vector,sparseVector,missing-method
###   as.vector,sparseVector,character-method dim<-,sparseVector-method
###   length,sparseVector-method rep,sparseVector-method
###   show,sparseVector-method %*%,Matrix,sparseVector-method
###   %*%,sparseVector,Matrix-method crossprod,Matrix,sparseVector-method
###   crossprod,sparseVector,Matrix-method solve,Matrix,sparseVector-method
###   tcrossprod,Matrix,sparseVector-method
###   tcrossprod,sparseVector,Matrix-method
###   [,sparseVector,index,ANY,ANY-method
###   [<-,sparseVector,index,missing,replValue-method
### Keywords: classes

### ** Examples

getClass("sparseVector")
getClass("dsparseVector")
getClass("xsparseVector")# those with an 'x' slot

sx <- c(0,0,3, 3.2, 0,0,0,-3:1,0,0,2,0,0,5,0,0)
(ss <- as(sx, "sparseVector"))

ix <- as.integer(round(sx))
(is <- as(ix, "sparseVector"))
## an "isparseVector" (!)

## rep() works too:
rep(is, length.out= 25)

## Using `dim<-`  as in base R :
r <- ss
dim(r) <- c(4,5) # becomes a sparse Matrix:
r




