### Name: unpack
### Title: Full Storage Representation of Packed Matrices
### Aliases: unpack
### Keywords: array algebra

### ** Examples

showMethods("unpack")
(cp4 <- chol(Hilbert(4))) # is triangular
tp4 <- as(cp4,"dtpMatrix")# [t]riangular [p]acked
str(tp4)
(unpack(tp4))

## Not run: 
##D ## once we have Diagonal() :
##D unpack(Diagonal( 1:3))
## End(Not run)



