### Name: TsparseMatrix-class
### Title: Class "TsparseMatrix" of Sparse Matrices in Triplet Form
### Aliases: TsparseMatrix-class coerce,TsparseMatrix,CsparseMatrix-method
###   coerce,TsparseMatrix,lsparseMatrix-method
###   coerce,TsparseMatrix,lMatrix-method
###   coerce,TsparseMatrix,nsparseMatrix-method
###   coerce,TsparseMatrix,nMatrix-method
###   coerce,TsparseMatrix,matrix-method coerce,Matrix,TsparseMatrix-method
###   coerce,matrix,TsparseMatrix-method
###   coerce,numeric,TsparseMatrix-method %*%,TsparseMatrix,ANY-method
###   %*%,ANY,TsparseMatrix-method %*%,TsparseMatrix,Matrix-method
###   %*%,Matrix,TsparseMatrix-method crossprod,TsparseMatrix,ANY-method
###   crossprod,ANY,TsparseMatrix-method
###   crossprod,TsparseMatrix,Matrix-method
###   crossprod,Matrix,TsparseMatrix-method
###   crossprod,TsparseMatrix,missing-method
###   tcrossprod,TsparseMatrix,ANY-method
###   tcrossprod,ANY,TsparseMatrix-method
###   tcrossprod,TsparseMatrix,Matrix-method
###   tcrossprod,Matrix,TsparseMatrix-method
###   tcrossprod,TsparseMatrix,missing-method
###   solve,TsparseMatrix,ANY-method solve,TsparseMatrix,missing-method
###   t,TsparseMatrix-method
### Keywords: classes

### ** Examples

showClass("TsparseMatrix")
## or just the subclasses' names
names(getClass("TsparseMatrix")@subclasses)



