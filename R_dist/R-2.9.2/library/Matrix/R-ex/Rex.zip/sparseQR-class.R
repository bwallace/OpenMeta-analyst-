### Name: sparseQR-class
### Title: Sparse QR decomposition of a sparse matrix
### Aliases: sparseQR-class qr.R,sparseQR-method
###   qr.coef,sparseQR,dgeMatrix-method qr.coef,sparseQR,matrix-method
###   qr.coef,sparseQR,numeric-method qr.fitted,sparseQR,dgeMatrix-method
###   qr.fitted,sparseQR,matrix-method qr.fitted,sparseQR,numeric-method
###   qr.qty,sparseQR,dgeMatrix-method qr.qty,sparseQR,matrix-method
###   qr.qty,sparseQR,numeric-method qr.qy,sparseQR,dgeMatrix-method
###   qr.qy,sparseQR,matrix-method qr.qy,sparseQR,numeric-method
###   qr.resid,sparseQR,dgeMatrix-method qr.resid,sparseQR,matrix-method
###   qr.resid,sparseQR,numeric-method solve,sparseQR,ANY-method
### Keywords: classes algebra array

### ** Examples

data(KNex); mm <- KNex$mm
str(mmQR <- qr(mm))



