### Name: CsparseMatrix-class
### Title: Class "CsparseMatrix" of Sparse Matrices in Column-compressed
###   Form
### Aliases: CsparseMatrix-class %*%,CsparseMatrix,CsparseMatrix-method
###   %*%,CsparseMatrix,ddenseMatrix-method %*%,CsparseMatrix,matrix-method
###   %*%,CsparseMatrix,numeric-method
###   %*%,ddenseMatrix,CsparseMatrix-method %*%,matrix,CsparseMatrix-method
###   %*%,numeric,CsparseMatrix-method
###   coerce,CsparseMatrix,lsparseMatrix-method
###   coerce,CsparseMatrix,lMatrix-method
###   coerce,CsparseMatrix,nsparseMatrix-method
###   coerce,CsparseMatrix,nMatrix-method
###   coerce,CsparseMatrix,TsparseMatrix-method
###   coerce,CsparseMatrix,denseMatrix-method
###   coerce,CsparseMatrix,matrix-method coerce,matrix,CsparseMatrix-method
###   coerce,numeric,CsparseMatrix-method
###   crossprod,CsparseMatrix,missing-method
###   crossprod,CsparseMatrix,CsparseMatrix-method
###   crossprod,CsparseMatrix,ddenseMatrix-method
###   crossprod,CsparseMatrix,matrix-method
###   crossprod,CsparseMatrix,numeric-method
###   crossprod,ddenseMatrix,CsparseMatrix-method
###   crossprod,matrix,CsparseMatrix-method diag,CsparseMatrix-method
###   t,CsparseMatrix-method tcrossprod,CsparseMatrix,CsparseMatrix-method
###   tcrossprod,CsparseMatrix,missing-method
###   Compare,CsparseMatrix,CsparseMatrix-method
###   Arith,CsparseMatrix,CsparseMatrix-method
###   Arith,CsparseMatrix,numeric-method Arith,numeric,CsparseMatrix-method
###   Logic,CsparseMatrix,CsparseMatrix-method Math,CsparseMatrix-method
###   .validateCsparse
### Keywords: classes

### ** Examples

getClass("CsparseMatrix")

## The common validity check function (based on C code):
getValidity(getClass("CsparseMatrix"))

## This behavior has been changed
# un-sorted i-slot on input is automatically "sorted" :
#M <- new("dgCMatrix", Dim = 2:3, p = as.integer(c(0,1,1,3)),
#         i = c(1L, 1:0), x= c(2,2,1))
#stopifnot(M@i == c(1L, 0:1), M@x == c(2,1,2))



