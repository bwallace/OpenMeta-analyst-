### Name: dsparseMatrix-class
### Title: Virtual Class "dsparseMatrix" of Numeric Sparse Matrices
### Aliases: dsparseMatrix-class Summary,dsparseMatrix-method
###   %*%,ddenseMatrix,dsparseMatrix-method
###   %*%,dgeMatrix,dsparseMatrix-method
###   %*%,dsparseMatrix,ddenseMatrix-method
###   %*%,dsparseMatrix,dgeMatrix-method
###   crossprod,ddenseMatrix,dsparseMatrix-method
###   crossprod,dgeMatrix,dsparseMatrix-method
###   crossprod,dsparseMatrix,ddenseMatrix-method
###   crossprod,dsparseMatrix,dgeMatrix-method lu,dsparseMatrix-method
### Keywords: classes

### ** Examples

showClass("dsparseMatrix")



