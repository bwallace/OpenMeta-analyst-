### Name: MatrixFactorization-class
### Title: Class "MatrixFactorization" of Matrix Factorizations
### Aliases: MatrixFactorization-class dim,MatrixFactorization-method
###   expand,MatrixFactorization-method show,MatrixFactorization-method
###   solve,MatrixFactorization,numeric-method
###   solve,MatrixFactorization,ANY-method
###   solve,MatrixFactorization,missing-method
### Keywords: classes

### ** Examples

showClass("MatrixFactorization")



