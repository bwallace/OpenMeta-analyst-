### Name: symmetricMatrix-class
### Title: Virtual Class of Symmetric Matrices in package:Matrix
### Aliases: symmetricMatrix-class coerce,matrix,symmetricMatrix-method
###   coerce,denseMatrix,symmetricMatrix-method
###   coerce,CsparseMatrix,symmetricMatrix-method
### Keywords: classes

### ** Examples

showClass("symmetricMatrix")

## The names of direct subclasses:
scl <- getClass("symmetricMatrix")@subclasses
directly <- sapply(lapply(scl, slot, "by"), length) == 0
names(scl)[directly]



