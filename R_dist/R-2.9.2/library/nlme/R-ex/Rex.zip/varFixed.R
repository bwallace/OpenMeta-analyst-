### Name: varFixed
### Title: Fixed Variance Function
### Aliases: varFixed
### Keywords: models

### ** Examples

vf1 <- varFixed(~age)



