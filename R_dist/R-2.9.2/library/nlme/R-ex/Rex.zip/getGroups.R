### Name: getGroups
### Title: Extract Grouping Factors from an Object
### Aliases: getGroups
### Keywords: models

### ** Examples

## see the method function documentation



