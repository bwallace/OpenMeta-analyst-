### Name: random.effects
### Title: Extract Random Effects
### Aliases: random.effects ranef print.ranef
### Keywords: models

### ** Examples

## see the method function documentation



