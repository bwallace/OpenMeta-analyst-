### Name: recalc
### Title: Recalculate Condensed Linear Model Object
### Aliases: recalc
### Keywords: models

### ** Examples

## see the method function documentation



