### Name: glsStruct
### Title: Generalized Least Squares Structure
### Aliases: glsStruct
### Keywords: models

### ** Examples

gls1 <- glsStruct(corAR1(), varPower())



