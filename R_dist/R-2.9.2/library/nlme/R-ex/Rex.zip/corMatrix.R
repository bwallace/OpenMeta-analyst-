### Name: corMatrix
### Title: Extract Correlation Matrix
### Aliases: corMatrix
### Keywords: models

### ** Examples

## see the method function documentation



