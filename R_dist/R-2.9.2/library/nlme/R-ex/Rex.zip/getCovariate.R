### Name: getCovariate
### Title: Extract Covariate from an Object
### Aliases: getCovariate
### Keywords: models

### ** Examples

## see the method function documentation



