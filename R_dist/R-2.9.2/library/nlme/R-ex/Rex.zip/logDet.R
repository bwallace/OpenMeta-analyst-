### Name: logDet
### Title: Extract the Logarithm of the Determinant
### Aliases: logDet
### Keywords: models

### ** Examples

## see the method function documentation



