### Name: collapse
### Title: Collapse According to Groups
### Aliases: collapse
### Keywords: models

### ** Examples

## see the method function documentation



