### Name: getResponse
### Title: Extract Response Variable from an Object
### Aliases: getResponse getResponse.data.frame
### Keywords: models

### ** Examples

getResponse(Orthodont)



