### Name: BIC.logLik
### Title: BIC of a logLik Object
### Aliases: BIC.logLik
### Keywords: models

### ** Examples

fm1 <- lm(distance ~ age, data = Orthodont) 
BIC(logLik(fm1))



