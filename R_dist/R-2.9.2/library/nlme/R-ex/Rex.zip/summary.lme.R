### Name: summary.lme
### Title: Summarize an lme Object
### Aliases: summary.lme
### Keywords: models

### ** Examples

fm1 <- lme(distance ~ age, Orthodont, random = ~ age | Subject)
summary(fm1)



