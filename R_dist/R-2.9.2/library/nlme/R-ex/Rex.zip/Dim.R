### Name: Dim
### Title: Extract Dimensions from an Object
### Aliases: Dim Dim.default
### Keywords: models

### ** Examples

## see the method function documentation



