### Name: getData
### Title: Extract Data from an Object
### Aliases: getData
### Keywords: models

### ** Examples

## see the method function documentation



