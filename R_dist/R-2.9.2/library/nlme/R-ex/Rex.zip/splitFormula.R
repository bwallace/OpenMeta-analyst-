### Name: splitFormula
### Title: Split a Formula
### Aliases: splitFormula
### Keywords: models

### ** Examples

splitFormula(~ g1/g2/g3)



