### Name: intervals
### Title: Confidence Intervals on Coefficients
### Aliases: intervals
### Keywords: models

### ** Examples

## see the method documentation



