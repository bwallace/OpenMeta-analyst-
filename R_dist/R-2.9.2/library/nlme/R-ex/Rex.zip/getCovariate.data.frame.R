### Name: getCovariate.data.frame
### Title: Extract Data Frame Covariate
### Aliases: getCovariate.data.frame
### Keywords: models

### ** Examples

getCovariate(Orthodont)



