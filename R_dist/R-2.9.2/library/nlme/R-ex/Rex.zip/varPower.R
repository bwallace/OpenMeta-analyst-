### Name: varPower
### Title: Power Variance Function
### Aliases: varPower
### Keywords: models

### ** Examples

vf1 <- varPower(0.2, form = ~age|Sex)



