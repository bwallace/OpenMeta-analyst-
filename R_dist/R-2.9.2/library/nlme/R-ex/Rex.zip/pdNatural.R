### Name: pdNatural
### Title: General Positive-Definite Matrix in Natural Parametrization
### Aliases: pdNatural
### Keywords: models

### ** Examples

pdNatural(diag(1:3))



