### Name: fixed.effects
### Title: Extract Fixed Effects
### Aliases: fixed.effects fixef
### Keywords: models

### ** Examples

## see the method function documentation



