### Name: cluster
### Title: Identify clusters.
### Aliases: cluster
### Keywords: survival

### ** Examples

marginal.model <- coxph(Surv(time, status) ~ rx + cluster(litter), rats)
frailty.model  <- coxph(Surv(time, status) ~ rx + frailty(litter), rats)



