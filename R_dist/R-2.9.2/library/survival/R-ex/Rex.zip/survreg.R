### Name: survreg
### Title: Regression for a Parametric Survival Model
### Aliases: survreg model.frame.survreg labels.survreg print.survreg.penal
###   print.summary.survreg survReg anova.survreg vcov.survreg
###   anova.survreglist
### Keywords: survival

### ** Examples

# Fit an exponential model: these are all the same
survreg(Surv(futime, fustat) ~ ecog.ps + rx, ovarian, dist='weibull',scale=1)
survreg(Surv(futime, fustat) ~ ecog.ps + rx, ovarian,
        dist="exponential")

# There are multiple ways to parameterize a Weibull distribution. The survreg 
# function imbeds it in a general location-scale familiy, which is a 
# different parameterization than the rweibull function, and often leads
# to confusion.
#   survreg's scale  =    1/(rweibull shape)
#   survreg's intercept = log(rweibull scale)
#   For the log-likelihood all parameterizations lead to the same value.
y <- rweibull(1000, shape=2, scale=5)
survreg(Surv(y)~1, dist="weibull")

# Economists fit a model called `tobit regression', which is a standard
# linear regression with Gaussian errors, but with left censored data.
tobinfit <- survreg(Surv(durable, durable>0, type='left') ~ age + quant,
                    data=tobin, dist='gaussian')



