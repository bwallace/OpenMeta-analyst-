### Name: survexp
### Title: Compute Expected Survival
### Aliases: survexp print.survexp
### Keywords: survival

### ** Examples

# 
# Stanford heart transplant data
# Estimate of conditional survival  
survexp(futime ~ ratetable(sex="male", year=accept.dt,   
          age=(accept.dt-birth.dt)), conditional=TRUE, data=jasa) 
# Estimate of conditional survival stratified by prior surgery 
survexp(futime ~ surgery + ratetable(sex="male", year=accept.dt,  
        age=(accept.dt-birth.dt)), conditional=TRUE, data=jasa) 

## Compare the survival curves for the Mayo PBC data to Cox model fit
## 
pfit <-coxph(Surv(time,status>0) ~ trt + log(bili) + log(protime) + age +
                platelet, data=pbc)
plot(survfit(Surv(time, status>0) ~ trt, data=pbc))
lines(survexp( ~ trt, ratetable=pfit, data=pbc), col='purple')



