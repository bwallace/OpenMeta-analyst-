### Name: ratetable
### Title: Ratetable reference in formula
### Aliases: ratetable [.ratetable [.ratetable2 print.ratetable
###   is.na.ratetable summary.ratetable
### Keywords: survival

### ** Examples


fit <- survfit(Surv(time, status) ~ sex, pbc,subset=1:312)

# The data set does not have entry date, use the midpoint of the study
efit <- survexp(~ ratetable(sex=sex,age=age*365.35,year=as.Date('1979/1/1')) +
            sex, data=pbc,  times=(0:24)*182)
## Not run: 
##D plot(fit, mark.time=F, xscale=365.25, xlab="Years post diagnosis",
##D         ylab="Survival")
##D lines(efit, col=2, xscale=365.25) # Add the expected survival line
## End(Not run)



