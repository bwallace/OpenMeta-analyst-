### Name: survConcordance
### Title: Compute a concordance measure.
### Aliases: survConcordance
### Keywords: survival

### ** Examples

survConcordance(Surv(time, status) ~age, data=lung)
## Not run: 
##D   n= 228 
##D Concordance= 0.5501899 , Gamma= 0.1034234 
##D  agree disagree tied.x tied.time incomparable 
##D  10717     8708    589        28         5836
## End(Not run)

options(na.action=na.exclude)
fit <- coxph(Surv(time, status) ~ ph.ecog + age + sex, lung)
survConcordance(Surv(time, status) ~predict(fit), lung)
## Not run: 
##D   n=227 (1 observations deleted due to missing values)
##D Concordance= 0.6371102 , Gamma= 0.2759638 
##D  agree disagree tied.x tied.time incomparable 
##D  12544     7118    125        28         5836
## End(Not run)


