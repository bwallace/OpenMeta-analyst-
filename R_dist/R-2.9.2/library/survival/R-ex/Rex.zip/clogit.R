### Name: clogit
### Title: Conditional logistic regression
### Aliases: clogit
### Keywords: survival models

### ** Examples

## Not run: clogit(case~spontaneous+induced+strata(stratum),data=infert)



