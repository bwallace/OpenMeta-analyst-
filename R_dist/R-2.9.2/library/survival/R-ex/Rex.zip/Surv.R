### Name: Surv
### Title: Create a Survival Object
### Aliases: Surv is.Surv print.Surv Math.Surv Summary.Surv [.Surv
###   format.Surv as.data.frame.Surv as.character.Surv as.matrix.Surv
###   is.na.Surv Ops.Surv
### Keywords: survival

### ** Examples

with(lung, Surv(time, status))
Surv(heart$start, heart$stop, heart$event) 



