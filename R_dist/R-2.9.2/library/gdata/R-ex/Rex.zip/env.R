### Name: env
### Title: Display Information about All Loaded Environments
### Aliases: env
### Keywords: data environment utilities

### ** Examples

## Not run: 
##D env()
## End(Not run)



