### Name: humanReadable
### Title: Print byte size in human readable format
### Aliases: humanReadable
### Keywords: misc

### ** Examples


baseSI <- 10
powerSI <- seq(from=3, to=27, by=3)
SI0 <- (baseSI)^powerSI
k <- length(SI0) - 1
SI1 <- SI0 - SI0 / c(2, runif(n=k, min=1.01, max=5.99))
SI2 <- SI0 + SI0 / c(2, runif(n=k, min=1.01, max=5.99))

baseIEC <- 2
powerIEC <- seq(from=10, to=90, by=10)
IEC0 <- (baseIEC)^powerIEC
IEC1 <- IEC0 - IEC0 / c(2, runif(n=k, min=1.01, max=5.99))
IEC2 <- IEC0 + IEC0 / c(2, runif(n=k, min=1.01, max=5.99))

cbind(humanReadable(x=SI1, width=NULL, digits=3),
      humanReadable(x=SI0, width=NULL, digits=2),
      humanReadable(x=SI2, width=NULL, digits=1),
      humanReadable(x=IEC1, standard="IEC", width=7, digits=3),
      humanReadable(x=IEC0, standard="IEC", width=7, digits=2),
      humanReadable(x=IEC2, standard="IEC", width=7, digits=1))



