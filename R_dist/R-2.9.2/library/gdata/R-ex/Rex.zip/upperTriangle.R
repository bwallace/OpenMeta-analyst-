### Name: upperTriangle
### Title: Extract or replace the upper/lower triangular portion of a
###   matrix
### Aliases: upperTriangle upperTriangle<- lowerTriangle lowerTriangle<-
### Keywords: array

### ** Examples

  x <- matrix( 1:25, nrow=5, ncol=5)
  x
  upperTriangle(x)
  upperTriangle(x, diag=TRUE)

  lowerTriangle(x)
  lowerTriangle(x, diag=TRUE)

  upperTriangle(x) <- NA
  x

  upperTriangle(x, diag=TRUE) <- 1:15
  x

  lowerTriangle(x) <- NA
  x

  lowerTriangle(x, diag=TRUE) <- 1:15
  x




