### Name: object.size
### Title: Report the Space Allocated for an Object
### Aliases: object.size print.object_size c.object_size as.object_size
###   is.object_size
### Keywords: utilities

### ** Examples

object.size(letters)
object.size(ls)
## find the 10 largest objects in the base package
z <- sapply(ls("package:base"), function(x)
            object.size(get(x, envir = baseenv())))
(tmp <- as.matrix(rev(sort(z))[1:10]))

as.object_size(14567567)
options(humanReadable=TRUE)
(z <- object.size(letters, c(letters, letters), rep(letters, 100), rep(letters, 10000)))
is.object_size(z)
as.object_size(14567567)



