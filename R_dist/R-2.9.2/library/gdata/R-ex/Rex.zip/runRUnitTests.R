### Name: .runRUnitTestsGdata
### Title: Run RUnit tests for the gdata package
### Aliases: .runRUnitTestsGdata
### Keywords: misc

### ** Examples

  ## Basic testing
  .runRUnitTestsGdata()



