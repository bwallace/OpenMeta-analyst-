### Name: read.xls
### Title: Read Excel files
### Aliases: read.xls xls2csv xls2tab xls2sep
### Keywords: file

### ** Examples


   # iris.xls is included in the gregmisc package for use as an example
   xlsfile <- file.path(.path.package('gdata'),'xls','iris.xls')
   xlsfile

   iris <- read.xls(xlsfile) # defaults to csv format
   iris <- read.xls(xlsfile,method="csv") # specify csv format
   iris <- read.xls(xlsfile,method="tab") # specify tab format

   head(iris)  # look at the top few rows

   ## Don't show: 
   iris.1 <- read.xls(xlsfile) # defaults to csv format
   iris.2 <- read.xls(xlsfile,method="csv") # specify csv format
   iris.3 <- read.xls(xlsfile,method="tab") # specify tab format

   stopifnot(all.equal(iris.1, iris.2))
   stopifnot(all.equal(iris.1, iris.3))
   ## End Don't show

  ## Not run: 
##D    # Example specifying exact Perl path for default MS-Windows install of
##D    # ActiveState perl
##D    iris <- read.xls(xlsfile, perl="C:/perl/bin/perl.exe")
##D 
##D    # Example specifying exact Perl path for Unix systems
##D    iris <- read.xls(xlsfile, perl="/usr/bin/perl")
##D 
##D    # read xls file from net
##D    nba.url <- "http://lcb1.uoregon.edu/sergiok/DSC330HSP04/week5/NBA.xls"
##D    nba <- read.xls(nba.url)
##D 
##D    # read xls file ignoring all lines prior to first containing State
##D    crime.url <- "http://www.jrsainfo.org/jabg/state_data2/Tribal_Data00.xls"
##D    crime <- read.xls(crime.url, pattern = "State")
##D 
##D    # use of xls2csv - open con, print two lines, close con
##D    con <- xls2csv(nba.url)
##D    print(readLines(con, 2)) 
##D    file.remove(summary(con)$description)
##D    
##D    
## End(Not run)



