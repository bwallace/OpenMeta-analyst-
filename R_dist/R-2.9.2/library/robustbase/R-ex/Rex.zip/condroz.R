### Encoding: latin1

### Name: condroz
### Title: Condroz Data
### Aliases: condroz
### Keywords: datasets

### ** Examples

  adjbox(condroz$Ca)



