### Name: possumDiv
### Title: Possum Diversity Data
### Aliases: possumDiv possum.mat
### Keywords: datasets

### ** Examples

data(possumDiv)
head(possum.mat)

str(possumDiv)
## summarize all variables as multilevel factors:
summary(as.data.frame(lapply(possumDiv, function(v)
                             if(is.integer(v)) factor(v) else v)))



