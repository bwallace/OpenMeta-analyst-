### Name: milk
### Title: Daudin's Milk Composition Data
### Aliases: milk
### Keywords: datasets

### ** Examples

data(milk)
covMcd(milk)



