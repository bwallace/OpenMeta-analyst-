### Name: psi_func-class
### Title: Class of "Psi Functions" for M-Estimation
### Aliases: psi_func-class
### Keywords: classes robust

### ** Examples

str(huberPsi, give.attr = FALSE)



