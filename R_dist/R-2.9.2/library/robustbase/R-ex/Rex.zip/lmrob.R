### Name: lmrob
### Title: MM-Estimators for Linear Regression
### Aliases: lmrob
### Keywords: robust regression

### ** Examples

data(coleman)
summary( m1 <- lmrob(Y ~ ., data=coleman) )

data(starsCYG, package = "robustbase")
## Plot simple data and fitted lines
plot(starsCYG)
 lmST <-    lm(log.light ~ log.Te, data = starsCYG)
(RlmST <- lmrob(log.light ~ log.Te, data = starsCYG))
abline(lmST, col = "red")
abline(RlmST, col = "blue")
summary(RlmST)
vcov(RlmST)
stopifnot(all.equal(fitted(RlmST),
                    predict(RlmST, newdata = starsCYG),
                    tol = 1e-14))



