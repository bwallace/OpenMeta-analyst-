### Name: lmrob.S
### Title: S-regression estimators
### Aliases: lmrob.S
### Keywords: robust regression

### ** Examples

set.seed(33)
x1 <- sort(rnorm(30)); x2 <- sort(rnorm(30)); x3 <- sort(rnorm(30))
X. <- cbind(x1, x2, x3)
y <-  10 + X. %*% (10*(2:4)) + rnorm(30)/10
y[1] <- 500   # a moderate outlier
X.[2,1] <- 20 # an X outlier
X1  <- cbind(1, X.)

(m.lm <- lm(y ~ X.))
set.seed(12)
m.lmS <- lmrob.S(x=X1, y=y,
                    control = lmrob.control(nRes = 20), trace.lev=1)
m.lmS[c("coef","scale")]
stopifnot(all.equal(m.lmS$coef,
                    10 * (1:4),        tol = 0.005),
          all.equal(m.lmS$scale, 1/10, tol = 0.09))



