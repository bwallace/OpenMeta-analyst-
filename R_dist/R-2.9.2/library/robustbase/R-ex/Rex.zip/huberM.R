### Name: huberM
### Title: Safe (generalized) Huber M-Estimator of Location
### Aliases: huberM
### Keywords: univar robust

### ** Examples

huberM(c(1:9, 1000))
mad  (c(1:9, 1000))
mad  (rep(9, 100))
huberM(rep(9, 100))

## When you have "binned" aka replicated observations:
set.seed(7)
x <- c(round(rnorm(1000),1), round(rnorm(50, m=10, sd = 10)))
t.x <- table(x) # -> unique values and multiplicities
x.uniq <- as.numeric(names(t.x)) ## == sort(unique(x))
x.mult <- unname(t.x)
str(Hx  <- huberM(x.uniq, weights = x.mult), digits = 7)
str(Hx. <- huberM(x, s = Hx$s), digits = 7) ## should be ~= Hx
stopifnot(all.equal(Hx, Hx.))
str(Hx2 <- huberM(x), digits = 7)## somewhat different, since 's' differs



