### Name: pilot
### Title: Pilot-Plant Data
### Aliases: pilot
### Keywords: datasets

### ** Examples

data(pilot)
summary(lm.pilot <- lm(Y ~.,data=pilot))



