### Name: chgDefaults-methods
### Title: Methods for Function chgDefaults() in Package `robustbase'
### Aliases: chgDefaults chgDefaults-methods chgDefaults,ANY-method
###   chgDefaults,psi_func-method
### Keywords: methods

### ** Examples

## FIXME -- add one 



