### Name: radarImage
### Title: Satellite Radar Image Data from near Munich
### Aliases: radarImage
### Keywords: datasets

### ** Examples

data(radarImage)
plot(Y.coord ~ X.coord, data = radarImage)
## see outliers
pairs(radarImage[, 3:5], main = "radarImage (n = 1573)")



