### Name: lmrob.control
### Title: Tuning parameters for lmrob
### Aliases: lmrob.control
### Keywords: robust regression

### ** Examples

## Show the default settings:
str(lmrob.control())



