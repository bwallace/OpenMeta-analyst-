### Name: alcohol
### Title: Alcohol Solubility in Water Data
### Aliases: alcohol
### Keywords: datasets

### ** Examples

data(alcohol)
## version of data set with trivial names, as
s.alcohol <- alcohol
names(s.alcohol) <- paste("Col", 1:7, sep='')



