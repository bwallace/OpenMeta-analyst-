### Name: scaleTau2
### Title: Robust Tau-Estimate of Scale
### Aliases: scaleTau2
### Keywords: robust univar

### ** Examples

x <- c(1:7, 1000)
sd(x) # non-robust std.deviation
scaleTau2(x)
scaleTau2(x, mu.too = TRUE)



