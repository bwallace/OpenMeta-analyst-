### Name: cloud
### Title: Cloud point of a Liquid
### Aliases: cloud
### Keywords: datasets

### ** Examples

data(cloud)
summary(lm.cloud <- lm(CloudPoint ~., data=cloud))



