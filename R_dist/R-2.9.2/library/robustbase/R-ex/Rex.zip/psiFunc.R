### Name: psiFunc
### Title: Constructor for Objects "Psi Function" Class
### Aliases: psiFunc huberPsi
### Keywords: classes robust

### ** Examples

## classical {trivial, not interesting}:
F1 <- function(x) rep.int(1, length(x))
cPsi <- psiFunc(rho = function(x) x^2 / 2, psi = function(x) x,
                wgt = F1, Dpsi = F1,
                Erho = function(x) rep.int(1/2, length(x)),
                Epsi2 = F1, EDpsi = F1)



