### Name: adjboxStats
### Title: Statistics for Skewness-adjusted Boxplots
### Aliases: adjboxStats
### Keywords: robust univar

### ** Examples

data(condroz)
astat <- adjboxStats(condroz[,"Ca"])
astat



