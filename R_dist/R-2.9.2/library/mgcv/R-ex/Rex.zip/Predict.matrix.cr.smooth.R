### Name: Predict.matrix.cr.smooth
### Title: Predict matrix method functions
### Aliases: Predict.matrix.cr.smooth Predict.matrix.cs.smooth
###   Predict.matrix.cyclic.smooth Predict.matrix.pspline.smooth
###   Predict.matrix.tensor.smooth Predict.matrix.tprs.smooth
###   Predict.matrix.ts.smooth
### Keywords: models regression

### ** Examples

## see smooth.construct
 




