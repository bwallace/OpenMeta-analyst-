### Name: smooth.construct.tensor.smooth.spec
### Title: Tensor product smoothing constructor
### Aliases: smooth.construct.tensor.smooth.spec
### Keywords: models regression

### ** Examples

## see ?gam




