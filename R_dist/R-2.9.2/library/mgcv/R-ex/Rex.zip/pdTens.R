### Name: pdTens
### Title: Functions implementing a pdMat class for tensor product smooths
### Aliases: pdTens pdConstruct.pdTens pdFactor.pdTens pdMatrix.pdTens
###   coef.pdTens summary.pdTens
### Keywords: models smooth regression

### ** Examples

# see gamm



