### Name: gamSim
### Title: Simulate example data for GAMs
### Aliases: gamSim
### Keywords: models smooth regression

### ** Examples

## see ?gam



