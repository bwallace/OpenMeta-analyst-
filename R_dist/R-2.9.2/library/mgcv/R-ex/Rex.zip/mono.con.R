### Name: mono.con
### Title: Monotonicity constraints for a cubic regression spline
### Aliases: mono.con
### Keywords: models smooth regression

### ** Examples

## see ?pcls



