### Name: smooth.construct.tp.smooth.spec
### Title: Penalized thin plate regression splines in GAMs
### Aliases: smooth.construct.tp.smooth.spec
###   smooth.construct.ts.smooth.spec tprs
### Keywords: models regression

### ** Examples

## see ?gam



