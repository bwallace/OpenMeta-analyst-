### Name: Tweedie
### Title: GAM Tweedie family
### Aliases: Tweedie
### Keywords: models regression

### ** Examples

library(mgcv)
set.seed(3)
n<-400
## Simulate data (really Poisson with log-link)
dat <- gamSim(1,n=n,dist="poisson",scale=.2)

## Fit a `nearby' Tweedie...
b <- gam(y~s(x0)+s(x1)+s(x2)+s(x3),family=Tweedie(1.1,power(.1)),
         data=dat)
plot(b,pages=1)
print(b)

## Same by approximate REML...
b1 <- gam(y~s(x0)+s(x1)+s(x2)+s(x3),family=Tweedie(1.1,power(.1)),
          data=dat,method="REML")
plot(b1,pages=1)
print(b1)

rm(dat)



