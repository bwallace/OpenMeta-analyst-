### Name: Predict.matrix
### Title: Prediction methods for smooth terms in a GAM
### Aliases: Predict.matrix Predict.matrix2
### Keywords: models smooth regression

### ** Examples
# See smooth.construct examples



