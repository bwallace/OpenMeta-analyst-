### Name: null.space.dimension
### Title: The basis of the space of un-penalized functions for a TPRS
### Aliases: null.space.dimension
### Keywords: models regression

### ** Examples

null.space.dimension(2,0)



