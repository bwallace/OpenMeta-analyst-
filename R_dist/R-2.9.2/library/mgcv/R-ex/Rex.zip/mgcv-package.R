### Name: mgcv-package
### Title: GAMs with GCV/AIC/REML smoothness estimation and GAMMs by
###   REML/PQL
### Aliases: mgcv-package
### Keywords: package models smooth regression

### ** Examples

## see examples for gam and gamm



