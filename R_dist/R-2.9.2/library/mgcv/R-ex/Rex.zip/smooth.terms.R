### Name: smooth.terms
### Title: Smooth terms in GAM
### Aliases: smooth.terms
### Keywords: regression

### ** Examples

## see examples for gam and gamm



