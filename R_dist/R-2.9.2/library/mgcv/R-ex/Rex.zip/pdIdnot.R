### Name: pdIdnot
### Title: Overflow proof pdMat class for multiples of the identity matrix
### Aliases: pdIdnot pdConstruct.pdIdnot pdFactor.pdIdnot pdMatrix.pdIdnot
###   coef.pdIdnot corMatrix.pdIdnot Dim.pdIdnot logDet.pdIdnot
###   solve.pdIdnot summary.pdIdnot
### Keywords: models smooth regression

### ** Examples

# see gamm



