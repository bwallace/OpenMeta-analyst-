### Name: gray
### Title: Gray Level Specification
### Aliases: gray grey
### Keywords: color

### ** Examples

gray(0:8 / 8)



