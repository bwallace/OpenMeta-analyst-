### Name: png
### Title: BMP, JPEG, PNG and TIFF graphics devices
### Aliases: bmp png jpeg tiff
### Keywords: device

### ** Examples

## copy current plot to a (large) PNG file
## Not run: dev.print(png, file="myplot.png", width=1024, height=768)
##D 
##D png(file="myplot.png", bg="transparent")
##D plot(1:10)
##D rect(1, 5, 3, 7, col="white")
##D dev.off()
##D 
##D jpeg(file="myplot.jpeg")
##D example(rect)
##D dev.off()
## End(Not run)


