### Name: contourLines
### Title: Calculate Contour Lines
### Aliases: contourLines
### Keywords: dplot

### ** Examples

x <- 10*1:nrow(volcano)
y <- 10*1:ncol(volcano)
contourLines(x, y, volcano)



