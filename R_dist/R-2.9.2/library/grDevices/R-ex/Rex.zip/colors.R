### Name: colors
### Title: Color Names
### Aliases: colors colours
### Keywords: color dplot sysdata

### ** Examples

cl <- colors()
length(cl); cl[1:20]



