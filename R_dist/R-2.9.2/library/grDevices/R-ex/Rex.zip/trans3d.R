### Name: trans3d
### Title: 3D to 2D Transformation for Perspective Plots
### Aliases: trans3d
### Keywords: dplot

### ** Examples

## See  help(persp) {after attaching the 'graphics' package}
##      -----------



