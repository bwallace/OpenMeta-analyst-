### Name: Devices
### Title: List of Graphical Devices
### Aliases: Devices device
### Keywords: device

### ** Examples
## Not run: 
##D ## open the default screen device on this platform if no device is
##D ## open
##D if(dev.cur() == 1) dev.new()
## End(Not run)


