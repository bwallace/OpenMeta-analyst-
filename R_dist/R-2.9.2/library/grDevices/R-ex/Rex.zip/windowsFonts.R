### Name: windowsFonts
### Title: Windows Fonts
### Aliases: windowsFont windowsFonts
### Keywords: device

### ** Examples

windowsFonts()
windowsFonts("mono")

## Not run: 
##D ## set up for Japanese: needs the fonts installed
##D windows()  # make sure we have the right device type
##D Sys.setlocale("LC_ALL", "ja")
##D windowsFonts(JP1 = windowsFont("MS Mincho"),
##D              JP2 = windowsFont("MS Gothic"),
##D              JP3 = windowsFont("Arial Unicode MS"))
##D plot(1:10)
##D text(5, 2, "\u{4E10}\u{4E00}\u{4E01}", family = "JP1")
##D text(7, 2, "\u{4E10}\u{4E00}\u{4E01}", family = "JP1", font=2)
##D text(5, 1.5, "\u{4E10}\u{4E00}\u{4E01}", family = "JP2")
##D text(9, 2, "\u{5100}", family = "JP3")
## End(Not run)


