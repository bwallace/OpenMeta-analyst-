### Name: dev.size
### Title: Find Size of Device Surface
### Aliases: dev.size
### Keywords: dplot

### ** Examples

dev.size("cm")



