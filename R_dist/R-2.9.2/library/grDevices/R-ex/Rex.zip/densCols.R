### Name: densCols
### Title: Colors for Smooth Density Plots
### Aliases: densCols blues9
### Keywords: dplot

### ** Examples

x1  <- matrix(rnorm(1e3), ncol=2)
x2  <- matrix(rnorm(1e3, mean=3, sd=1.5), ncol=2)
x   <- rbind(x1,x2)

dcols <- densCols(x)
graphics::plot(x, col = dcols, pch=20, main = "n = 1000")



