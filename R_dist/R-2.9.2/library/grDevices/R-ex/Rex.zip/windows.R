### Name: windows
### Title: Windows graphics devices
### Aliases: windows win.graph win.metafile win.print x11 X11
###   print.SavedPlots [.SavedPlots
### Keywords: device

### ** Examples
## Not run: 
##D ## A series of plots written to a sequence of metafiles
##D win.metafile("Rplot%02d.wmf", pointsize = 10)
## End(Not run)


