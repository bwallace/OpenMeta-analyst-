### Name: cm
### Title: Unit Transformation
### Aliases: cm
### Keywords: dplot

### ** Examples

cm(1)# = 2.54

## Translate *from* cm *to* inches:

10 / cm(1) # -> 10cm  are 3.937 inches



