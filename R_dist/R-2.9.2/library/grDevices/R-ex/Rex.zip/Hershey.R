### Name: Hershey
### Title: Hershey Vector Fonts in R
### Aliases: Hershey
### Keywords: aplot

### ** Examples

Hershey

## for tables of examples, see demo(Hershey)



