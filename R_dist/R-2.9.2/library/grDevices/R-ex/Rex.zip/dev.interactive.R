### Name: dev.interactive
### Title: Is the Current Graphics Device Interactive ?
### Aliases: dev.interactive deviceIsInteractive
### Keywords: device

### ** Examples

dev.interactive()
print(deviceIsInteractive(NULL))



